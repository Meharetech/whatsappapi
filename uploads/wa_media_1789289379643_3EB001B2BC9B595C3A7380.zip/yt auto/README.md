# 🍉 Cocolemon - YouTube Kids Script & Audio Automation Pipeline

A fully automated, end-to-end Python pipeline designed for the kids' YouTube channel **Cocolemon**. It tracks live releases from CoComelon via YouTube's official RSS XML feed, uses Groq's high-speed LPU inference engine to generate 2-minute toddler nursery rhyme scripts with rich sound effects cues, and automatically synthesizes high-quality voiceover audio via ElevenLabs TTS.

---

## 🚀 Features

- **📡 Live YouTube RSS Ingestion**: Automatically parses CoComelon's official RSS feed (`UCbCmjCuTUZos6Inko4u57UQ`) to capture latest video titles, themes, and descriptions.
- **⚡ High-Speed Script Generation**: Leverages Groq's LPU with prompt engineering tailored for 1-4 year old toddlers (100-115 BPM rhythm, AABB/ABAB meter, repetitive choruses).
- **🔊 Rich Sound & Action Cues**: Injects bracketed cues such as `[clap, clap]`, `[beep, beep]`, `[giggle]`, `[jump, jump]`, `[peek-a-boo]`, and `[spin around]`.
- **🎙️ ElevenLabs Voiceover Synthesis**: Automatically converts generated scripts into clean studio-quality audio (`voiceover.mp3`) using ElevenLabs TTS.
- **📂 Local Asset Management**: Automatically creates and writes outputs to `cocolemon_output/`:
  - `script.txt`: The production-ready nursery rhyme script.
  - `voiceover.mp3`: Synthesized vocal / narrator track.
  - `metadata.json`: Full execution lineage, model parameters, audio metrics, and source metadata.
  - `execution.log`: Detailed runtime logs.
- **🛡️ Multi-Tier Fallback Protection**: Gracefully falls back to curated toddler themes if the RSS feed is down or network timeouts occur.

---

## 📁 Project Structure

```
yt auto/
├── run.bat                   # 1-Click interactive Windows launcher
├── .env                      # API keys (Groq & ElevenLabs)
├── .env.example              # Template for API keys
├── .gitignore                # Git ignore for keys and local logs
├── requirements.txt          # Python dependencies
├── config.py                 # Central configurations & default themes
├── trend_scraper.py          # CoComelon RSS parser with error fallbacks
├── script_generator.py       # Groq script generation with fallback models
├── audio_generator.py        # ElevenLabs TTS voiceover synthesis
├── main.py                   # Master CLI pipeline orchestrator
├── README.md                 # Project documentation
└── cocolemon_output/         # Generated output folder
    ├── script.txt            # Latest generated toddler script
    ├── voiceover.mp3         # ElevenLabs synthesized voiceover audio
    ├── metadata.json         # Lineage and generation metadata
    └── execution.log         # Timestamped run logs
```

---

## 🛠️ Quickstart Installation

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure API Keys in `.env`
```env
GROQ_API_KEY=your_groq_api_key
ELEVENLABS_API_KEY=your_elevenlabs_api_key
```

---

## 🎬 Running the Pipeline

### 🖱️ Option A: 1-Click Batch File (Easiest)
Simply double-click **`run.bat`** in Windows Explorer. It opens an interactive menu:
1. **Full Pipeline** (Live RSS + Groq Script + ElevenLabs Audio)
2. **Custom Topic** (Type your own topic)
3. **Script Only** (Skip audio to save credits)
4. **Open Output Folder** (`cocolemon_output/`)

---

### 💻 Option B: Command Line (CLI)

#### Full Pipeline (RSS + Groq Script + ElevenLabs Audio)
```bash
python main.py
```

#### Script Only (Skip Audio Generation)
```bash
python main.py --skip-audio
```

#### Custom Topic Override
```bash
python main.py --topic "Splish Splash Dinosaur Bath Time"
```

#### Force Curated Fallback Mode
```bash
python main.py --force-fallback
```

---

## 📄 Output Artifacts

After running, check `cocolemon_output/`:
1. **`cocolemon_output/script.txt`**: Formatted with `[INTRO]`, `[VERSE 1]`, `[CHORUS]`, `[VERSE 2]`, `[CHORUS]`, `[OUTRO]`, and sound effect cues.
2. **`cocolemon_output/voiceover.mp3`**: Studio-quality voice track synthesized by ElevenLabs.
3. **`cocolemon_output/metadata.json`**: Structured JSON data containing source info, model usage, runtime, audio metadata, and timestamp.
