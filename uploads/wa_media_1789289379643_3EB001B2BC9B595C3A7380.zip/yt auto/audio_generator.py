import os
import re
import logging
import requests
from pathlib import Path
from typing import Dict, Any, Tuple, Optional
import config

logger = logging.getLogger("cocolemon_pipeline")

def extract_spoken_lyrics(script_text: str) -> str:
    """
    Cleans the raw script text to extract ONLY the pure spoken / sung lyrics:
    - Stops immediately before any storyboard JSON or code blocks.
    - Strips stage directions, music descriptions (e.g. *Music starts with piano...*), scene cues (*Scene: Sunny meadow*).
    - Strips bracketed sound effect cues [clap, clap], [giggle], [stomp], [twinkle].
    - Strips parenthetical cues (SFX: ...), (sign), (repeat), (pause), etc.
    - Strips speaker labels (JJ:, Bella:, All:, Mom & Dad:, etc.).
    """
    if "--- STORYBOARD_JSON ---" in script_text:
        script_text = script_text.split("--- STORYBOARD_JSON ---")[0]
    if "```json" in script_text:
        script_text = script_text.split("```json")[0]

    lines = script_text.splitlines()
    spoken_lines = []

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        # Ignore delimiter lines or metadata
        if stripped.startswith("---") or stripped.startswith("===") or stripped.startswith("```"):
            continue
        if any(stripped.upper().startswith(k) for k in ["TITLE:", "**SCRIPT", "THEME:", "TARGET AUDIENCE:", "ESTIMATED RUNTIME:", "BPM:", "TEMPO", "CHARACTERS:", "ANIMATION CUES:", "SCENE_NAME", "VISUAL_PROMPT"]):
            continue

        # Ignore stage directions starting with * (like *Music starts with...*, *Scene: Sunny...*, *[sparkle chime]*)
        if (stripped.startswith("*") and stripped.endswith("*")) or stripped.startswith("*Music") or stripped.startswith("*Scene") or stripped.startswith("*["):
            continue

        # Ignore lines that are purely section headers like [INTRO], [VERSE 1], [CHORUS], [OUTRO], **[INTRO]**
        cleaned_sec = re.sub(r"[\*\_#]", "", stripped).strip()
        if re.match(r"^\[\s*(INTRO|VERSE|CHORUS|BRIDGE|OUTRO|FINALE).*?\]$", cleaned_sec, re.IGNORECASE):
            continue

        # Remove parenthetical stage notes: (SFX: ...), (sign), (repeat), (fades out), etc.
        cleaned = re.sub(r"\([^\)]*?\)", "", stripped)

        # Remove bracketed cues like [clap, clap], [giggle], [twinkle, twinkle], [hand wave], [stomp, stomp]
        cleaned = re.sub(r"\[[^\]]*?\]", "", cleaned)

        # Remove stage direction asterisks, quotes and markdown formatting symbols
        cleaned = re.sub(r"[\*\_#\"“”]", "", cleaned)

        # Remove character speaker names (e.g. "JJ:", "Bella & JJ:", "ALL:", "Mom & Dad:")
        cleaned = re.sub(r"^[A-Za-z0-9\s&/\-\.,]+:\s*", "", cleaned)
        cleaned = cleaned.strip()

        # Filter out lines that are just sound descriptions or stage artifacts
        if not cleaned or len(cleaned) < 2:
            continue
        if any(cleaned.lower().startswith(s) for s in ["scene:", "music:", "sfx:", "visual:", "action:"]):
            continue

        spoken_lines.append(cleaned)

    result = "\n".join(spoken_lines).strip()
    return result

def _detect_best_edge_voice(text: str) -> str:
    """Detects script language and picks the most natural edge-tts voice."""
    # Check for Devanagari Hindi characters
    has_devanagari = bool(re.search(r"[\u0900-\u097F]", text))
    if has_devanagari:
        return "hi-IN-MadhurNeural"
    
    # Check for common Hinglish terms
    hinglish_words = ["bhai", "yaar", "karo", "gully", "cricket", "namaste", "dosto", "desi", "arre", "acha", "mast", "paisa"]
    lower_text = text.lower()
    if any(w in lower_text for w in hinglish_words):
        return "hi-IN-MadhurNeural"
    
    # Default high-energy animated narrator
    return "en-US-ChristopherNeural"

def generate_edge_tts_voiceover(
    script_text: str,
    output_path: Path = config.AUDIO_OUTPUT_FILE,
    voice: Optional[str] = None,
    rate: str = "+0%",
    pitch: str = "+0Hz"
) -> Tuple[bool, Dict[str, Any]]:
    """
    Generates 100% FREE high-quality neural voiceover using Microsoft Edge TTS.
    Requires NO API keys, has NO character limits, and produces crystal clear audio.
    """
    import asyncio
    try:
        import edge_tts
    except ImportError:
        logger.error("edge-tts library not installed. Run 'pip install edge-tts'.")
        return False, {"status": "failed", "error": "edge-tts module not installed"}

    spoken_text = extract_spoken_lyrics(script_text)
    if not spoken_text:
        logger.warning("No speakable text extracted from script.")
        return False, {"status": "error", "reason": "Empty spoken text"}

    chosen_voice = voice or _detect_best_edge_voice(spoken_text)
    logger.info(f"🎙️ Generating 100% FREE Voiceover via edge-tts (Voice: {chosen_voice}, Rate: {rate})...")

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    async def _run_edge_tts():
        communicate = edge_tts.Communicate(
            text=spoken_text,
            voice=chosen_voice,
            rate=rate,
            pitch=pitch
        )
        await communicate.save(str(output_path))

    try:
        try:
            asyncio.run(_run_edge_tts())
        except RuntimeError:
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                executor.submit(lambda: asyncio.run(_run_edge_tts())).result()

        if output_path.exists() and output_path.stat().st_size > 500:
            file_size_kb = round(output_path.stat().st_size / 1024, 2)
            logger.info(f"-> Free edge-tts audio saved to: {output_path} ({file_size_kb} KB)")
            return True, {
                "status": "success",
                "engine": "edge-tts (Microsoft Neural)",
                "voice": chosen_voice,
                "file_path": str(output_path),
                "file_size_kb": file_size_kb,
                "spoken_characters": len(spoken_text)
            }
        else:
            return False, {"status": "failed", "error": "Generated audio file empty or missing"}
    except Exception as exc:
        logger.error(f"Exception during edge-tts synthesis: {exc}")
        return False, {"status": "exception", "error": str(exc)}

def generate_voiceover_audio(
    script_text: str,
    output_path: Path = config.AUDIO_OUTPUT_FILE,
    voice_id: str = config.ELEVENLABS_VOICE_ID,
    api_key: str = None,
    engine: str = "auto",
    edge_voice: Optional[str] = None
) -> Tuple[bool, Dict[str, Any]]:
    """
    Generates voiceover audio using either free edge-tts or ElevenLabs TTS.
    Engine options: 'edge-tts' / 'edge', 'elevenlabs', or 'auto' (preferred).
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # If edge-tts explicitly requested or default in python-movie mode
    if engine.lower() in ("edge-tts", "edge", "free"):
        return generate_edge_tts_voiceover(script_text, output_path=output_path, voice=edge_voice)

    # Check ElevenLabs Key
    key = api_key or os.getenv("ELEVENLABS_API_KEY") or config.ELEVENLABS_API_KEY
    if not key or key.strip() == "" or key == "your_elevenlabs_api_key_here":
        logger.info("ℹ️ No ElevenLabs key found. Using 100% Free edge-tts neural voiceover.")
        return generate_edge_tts_voiceover(script_text, output_path=output_path, voice=edge_voice)

    spoken_text = extract_spoken_lyrics(script_text)
    if not spoken_text:
        logger.warning("No speakable text extracted from script.")
        return False, {
            "status": "error",
            "reason": "Empty spoken text"
        }

    logger.info(f"Generating voiceover via ElevenLabs (Voice: {voice_id}, Model: {config.ELEVENLABS_MODEL_ID})...")
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"

    headers = {
        "xi-api-key": key,
        "Content-Type": "application/json",
        "Accept": "audio/mpeg"
    }

    payload = {
        "text": spoken_text,
        "model_id": config.ELEVENLABS_MODEL_ID,
        "voice_settings": {
            "stability": 0.50,
            "similarity_boost": 0.75,
            "style": 0.35,
            "use_speaker_boost": True
        }
    }

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=45)
        if response.status_code == 200:
            with open(output_path, "wb") as f:
                f.write(response.content)

            file_size_kb = round(len(response.content) / 1024, 2)
            logger.info(f"-> Audio successfully saved to: {output_path} ({file_size_kb} KB)")

            return True, {
                "status": "success",
                "engine": "ElevenLabs TTS",
                "voice_id": voice_id,
                "model_id": config.ELEVENLABS_MODEL_ID,
                "file_path": str(output_path),
                "file_size_kb": file_size_kb,
                "spoken_characters": len(spoken_text)
            }
        else:
            err_msg = response.text[:300]
            logger.warning(f"ElevenLabs TTS returned HTTP {response.status_code}. Automatically falling back to free edge-tts...")
            return generate_edge_tts_voiceover(script_text, output_path=output_path, voice=edge_voice)
    except Exception as exc:
        logger.warning(f"ElevenLabs exception ({exc}). Automatically falling back to free edge-tts...")
        return generate_edge_tts_voiceover(script_text, output_path=output_path, voice=edge_voice)

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    sample_text = (
        "Namaste dosto! Aaj hum dekhenge ki hostel life aur gully cricket me kya kya dhamaka hota hai. "
        "Like karein, share karein aur subscribe karna mat bhoolna!"
    )
    success, meta = generate_edge_tts_voiceover(sample_text)
    print("Success:", success)
    print("Metadata:", meta)
