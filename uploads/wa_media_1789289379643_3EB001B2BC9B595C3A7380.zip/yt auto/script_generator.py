import os
import sys
import json
import logging
import re
from typing import Dict, Any, Tuple, List, Optional
import config

logger = logging.getLogger("cocolemon_pipeline")

def generate_animated_video_script(
    title: Any = "",
    theme: str = "",
    raw_summary: str = "",
    custom_keywords: list = None,
    narrative_context: Dict[str, Any] = None,
    topic_override: str = "",
    **kwargs
) -> Tuple[str, Dict[str, Any]]:
    """
    Generates a dynamic 2-minute comedic animated storytelling script AND a synchronized
    6-scene visual storyboard using Groq's API, strictly grounded in the scraped video's
    actual transcripts, dialogue, and narrative sequence.
    """
    # Handle dictionary passed as first argument
    if isinstance(title, dict):
        trend_dict = title
        title = trend_dict.get("title", "")
        theme = theme or trend_dict.get("theme", "")
        raw_summary = raw_summary or trend_dict.get("raw_summary", "")
        custom_keywords = custom_keywords or trend_dict.get("keywords", None)
        narrative_context = narrative_context or trend_dict.get("narrative_context", None)

    if topic_override:
        title = topic_override
        theme = f"Comedic animated story about '{topic_override}'"

    api_key = os.getenv("GROQ_API_KEY") or config.GROQ_API_KEY
    channel_name = getattr(config, "TARGET_CHANNEL_NAME", "NOT YOUR TYPE")

    # Format transcript & narrative cues
    transcript_summary = ""
    scene_cues_formatted = ""
    key_dialogues_str = ""

    if narrative_context:
        transcript_summary = narrative_context.get("full_transcript_summary", "")
        scene_cues_formatted = narrative_context.get("formatted_scene_cues", "")
        key_dialogues_str = ", ".join(narrative_context.get("key_dialogues", []))
    elif raw_summary:
        transcript_summary = raw_summary

    system_prompt = (
        f"You are the Lead Creative Director and Comedic Scriptwriter for the animated storytelling channel '{channel_name}'.\n"
        "Your mission is to write a hilarious, high-energy 2-minute animated video script AND a complete 6-scene visual storyboard "
        "THAT IS DIRECTLY, UNIQUELY, AND FAITHFULLY INSPIRED BY THE SCRAPED SOURCE VIDEO'S ACTUAL DIALOGUE, STORYLINE, AND TRANSCRIPTS.\n\n"
        "CORE INSTRUCTIONS:\n"
        "1. STORYLINE & DIALOGUE RELEVANCE: Recreate and adapt the relatable humor, funny situations, character banter, and narrative beats provided in the SCRAPED SOURCE TRANSCRIPT and SCENE CUES. The generated script MUST feel directly inspired by the scraped source video.\n"
        "2. EXACT 6-SCENE STORYBOARD PROGRESSION: Create exactly 6 chronological scene beats:\n"
        "   - Beat 1 (INTRO): Establish the relatable theme/setting with humorous opening hook.\n"
        "   - Beat 2 (SCENE_1): Rising action, relatable dialogue banter and character interactions.\n"
        "   - Beat 3 (SCENE_2): Core comedic highlight, high-energy activity or challenge.\n"
        "   - Beat 4 (SCENE_3): Comedic twist, unexpected escalation or hilarious obstacle.\n"
        "   - Beat 5 (SCENE_4): Climax, celebration, triumph, or epic funny conclusion.\n"
        "   - Beat 6 (OUTRO): Memorable sign-off, relatable takeaway, call-to-action & waving goodbye.\n"
        "3. HIGHLY DESCRIPTIVE VISUAL PROMPTS: In the storyboard JSON, write vivid, cinematic visual_prompt descriptions detailing the environment, background, character expressions, lighting, and dynamic action for each scene beat so an AI image renderer can render exact 3D visual artwork.\n"
        "4. DYNAMIC ANIMATION & MOTION: Assign appropriate animation_pattern (e.g. comedy_vlog, street_adventure, sports_action, dance_party, food_munch, dramatic_standoff, educational_focus) and camera_motion (e.g. bounce_zoom, pan_and_track, focal_zoom, sweep_reveal, stage_pulse, float_sway).\n"
        "5. ACTION SOUND EFFECTS: Embed bracketed sound cues like [laugh], [gasp], [shout], [cheer], [whoosh], [applause], [horn], [sizzle], [creak].\n\n"
        "OUTPUT FORMAT REQUIREMENTS:\n"
        "You MUST format your output with two clear sections:\n"
        "--- SCRIPT ---\n"
        "[Full formatted script with section markers, character dialogues, and bracketed sound cues]\n"
        "--- STORYBOARD_JSON ---\n"
        "```json\n"
        "[\n"
        "  {\"section\": \"INTRO\", \"scene_name\": \"[descriptive_scene_name]\", \"theme_category\": \"[genre]\", \"animation_pattern\": \"[...]\", \"camera_motion\": \"[...]\", \"visual_prompt\": \"[Vivid visual scene description of setting and characters]\", \"lyrics\": \"[Dialogue/Voiceover for this scene beat]\", \"sfx\": \"[sound_cue]\", \"action\": \"[action_type]\"},\n"
        "  {\"section\": \"SCENE_1\", \"scene_name\": \"[...]\", \"theme_category\": \"[...]\", \"animation_pattern\": \"[...]\", \"camera_motion\": \"[...]\", \"visual_prompt\": \"[...]\", \"lyrics\": \"[...]\", \"sfx\": \"[...]\", \"action\": \"[...]\"},\n"
        "  {\"section\": \"SCENE_2\", \"scene_name\": \"[...]\", \"theme_category\": \"[...]\", \"animation_pattern\": \"[...]\", \"camera_motion\": \"[...]\", \"visual_prompt\": \"[...]\", \"lyrics\": \"[...]\", \"sfx\": \"[...]\", \"action\": \"[...]\"},\n"
        "  {\"section\": \"SCENE_3\", \"scene_name\": \"[...]\", \"theme_category\": \"[...]\", \"animation_pattern\": \"[...]\", \"camera_motion\": \"[...]\", \"visual_prompt\": \"[...]\", \"lyrics\": \"[...]\", \"sfx\": \"[...]\", \"action\": \"[...]\"},\n"
        "  {\"section\": \"SCENE_4\", \"scene_name\": \"[...]\", \"theme_category\": \"[...]\", \"animation_pattern\": \"[...]\", \"camera_motion\": \"[...]\", \"visual_prompt\": \"[...]\", \"lyrics\": \"[...]\", \"sfx\": \"[...]\", \"action\": \"[...]\"},\n"
        "  {\"section\": \"OUTRO\", \"scene_name\": \"[...]\", \"theme_category\": \"[...]\", \"animation_pattern\": \"[...]\", \"camera_motion\": \"[...]\", \"visual_prompt\": \"[...]\", \"lyrics\": \"[...]\", \"sfx\": \"[...]\", \"action\": \"waving\"}\n"
        "]\n"
        "```"
    )

    user_prompt = (
        f"Create an original 6-scene animation storyboard and storytelling script specifically based on this scraped video release.\n\n"
        f"SOURCE VIDEO TITLE: {title}\n"
        f"THEME / GENRE: {theme}\n"
    )
    if custom_keywords:
        user_prompt += f"CORE KEYWORDS & TAGS: {', '.join(custom_keywords)}\n"
    if scene_cues_formatted:
        user_prompt += f"\nACTUAL SCRAPED CHRONOLOGICAL SCENE CUES:\n{scene_cues_formatted}\n"
    if transcript_summary:
        user_prompt += f"\nSCRAPED TRANSCRIPT SUMMARY & DIALOGUE SNIPPETS:\n{transcript_summary[:1200]}\n"
    if key_dialogues_str:
        user_prompt += f"\nKEY DIALOGUE MOMENTS TO FEATURE:\n{key_dialogues_str[:300]}\n"

    if not api_key or api_key.strip() == "" or api_key == "your_groq_api_key_here":
        logger.warning("GROQ_API_KEY is not set. Generating dynamic procedural script from scraped narrative context.")
        return _generate_local_fallback_script(title, theme, narrative_context)

    try:
        from groq import Groq
        client = Groq(api_key=api_key)

        models_to_try = [config.GROQ_MODEL] + [m for m in config.GROQ_FALLBACK_MODELS if m != config.GROQ_MODEL]
        last_error = None

        for model_candidate in models_to_try:
            try:
                logger.info(f"Invoking Groq API with model '{model_candidate}'...")
                completion = client.chat.completions.create(
                    model=model_candidate,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    temperature=0.75,
                    max_tokens=3000,
                    top_p=0.9,
                )

                raw_output = completion.choices[0].message.content
                logger.info(f"Successfully generated script & storyboard using '{model_candidate}'.")

                # Extract script and storyboard
                script_text, storyboard = _parse_script_and_storyboard(raw_output, title, theme, narrative_context)

                meta = {
                    "generator": "Groq LPU",
                    "model": model_candidate,
                    "prompt_tokens": completion.usage.prompt_tokens if hasattr(completion, "usage") else None,
                    "completion_tokens": completion.usage.completion_tokens if hasattr(completion, "usage") else None,
                    "total_tokens": completion.usage.total_tokens if hasattr(completion, "usage") else None,
                    "script_length_words": len(script_text.split()),
                    "storyboard_scenes": len(storyboard),
                    "storyboard": storyboard,
                    "estimated_runtime": "2:00 (120s)",
                    "status": "success"
                }
                return script_text, meta

            except Exception as model_err:
                err_str = str(model_err)
                if "model_not_found" in err_str or "does not exist" in err_str:
                    logger.warning(f"Model '{model_candidate}' not accessible. Trying next...")
                    last_error = model_err
                    continue
                else:
                    raise model_err

        if last_error:
            raise last_error

    except Exception as e:
        logger.error(f"Error calling Groq API: {e}. Generating dynamic fallback script.")
        fallback_script, meta = _generate_local_fallback_script(title, theme, narrative_context)
        meta["groq_error"] = str(e)
        return fallback_script, meta

# Backward compatibility alias
generate_nursery_rhyme_script = generate_animated_video_script

def _parse_script_and_storyboard(raw_output: str, title: str, theme: str, narrative_context: dict = None) -> Tuple[str, List[Dict[str, Any]]]:
    """Extracts the readable script text and the JSON storyboard array with resilient fallback repair."""
    script_text = raw_output
    storyboard = []

    if "--- STORYBOARD_JSON ---" in raw_output:
        parts = raw_output.split("--- STORYBOARD_JSON ---")
        script_part = parts[0].replace("--- SCRIPT ---", "").strip()
        json_part = parts[1].strip()

        # Clean markdown code blocks
        if "```json" in json_part:
            json_part = json_part.split("```json")[1].split("```")[0].strip()
        elif "```" in json_part:
            json_part = json_part.split("```")[1].split("```")[0].strip()

        # Attempt direct parse
        try:
            storyboard = json.loads(json_part)
            script_text = script_part
        except Exception:
            # Resilient extraction
            try:
                obj_matches = re.findall(r'\{[^{}]*?"section"[^{}]*?\}', json_part, re.DOTALL)
                if obj_matches:
                    recovered = []
                    for m in obj_matches:
                        try:
                            item = json.loads(m)
                            recovered.append(item)
                        except Exception:
                            pass
                    if recovered:
                        storyboard = recovered
                        script_text = script_part
            except Exception:
                pass

            if not storyboard:
                logger.info("Using default structured storyboard customized to scraped narrative context.")
                storyboard = _generate_default_storyboard(title, theme, narrative_context)
                script_text = script_part
    else:
        storyboard = _generate_default_storyboard(title, theme, narrative_context)

    return script_text, storyboard

def _generate_default_storyboard(title: str, theme: str = "", narrative_context: dict = None) -> List[Dict[str, Any]]:
    """Generates a dynamic 6-scene storyboard specifically customized to the scraped video topic and sub-themes."""
    text = (title + " " + theme).lower()
    clean_topic = title.replace("| NOT YOUR TYPE", "").replace("|", "-").split("-")[0].strip()

    # If rich transcript chunks are present, build visual prompts and dialogues directly from them
    chunks = narrative_context.get("scene_chunks", []) if narrative_context else []
    if chunks and len(chunks) >= 6:
        sections = ["INTRO", "SCENE_1", "SCENE_2", "SCENE_3", "SCENE_4", "OUTRO"]
        patterns = ["street_adventure", "comedy_vlog", "sports_action", "comedy_vlog", "dance_party", "street_adventure"]
        motions = ["pan_and_track", "bounce_zoom", "stage_pulse", "focal_zoom", "sweep_reveal", "sweep_reveal"]
        sfx_list = ["[cheer]", "[laugh]", "[swish, cheer]", "[gasp, giggle]", "[applause, cheer]", "[cheer]"]
        
        storyboard = []
        for i in range(6):
            chunk_snippet = chunks[i].get("dialogue_snippet", clean_topic)
            scene_name = f"beat_{i+1}_{re.sub(r'[^a-zA-Z0-9_]', '_', clean_topic[:15]).lower()}"
            storyboard.append({
                "section": sections[i],
                "scene_name": scene_name,
                "theme_category": "comedy",
                "animation_pattern": patterns[i],
                "camera_motion": motions[i],
                "visual_prompt": f"Vibrant 3D animated scene representing {clean_topic}, lively environment, characters reacting humorously: {chunk_snippet[:120]}",
                "lyrics": chunk_snippet[:200],
                "sfx": sfx_list[i],
                "action": "acting" if i < 5 else "waving"
            })
        return storyboard

    # 1. Multi-segment Indian Schools + Gully Cricket + Summer Holidays
    if ("school" in text or "class" in text) and ("cricket" in text or "gully" in text):
        return [
            {"section": "INTRO", "scene_name": "indian_school_morning_bell", "theme_category": "school", "animation_pattern": "educational_focus", "camera_motion": "focal_zoom", "visual_prompt": f"Bustling Indian school classroom in the morning, wooden desks, green blackboard, students chatting excitedly - {clean_topic}", "lyrics": "Morning school bell rings as everyone rushes inside with bags!", "sfx": "[bell_ring]", "action": "entering_class"},
            {"section": "SCENE_1", "scene_name": "recess_lunchbox_rush", "theme_category": "comedy", "animation_pattern": "comedy_vlog", "camera_motion": "bounce_zoom", "visual_prompt": "Recess bell rings, students rushing out to the school courtyard sharing lunchboxes and laughing", "lyrics": "Recess time! Sharing lunchboxes, cracking jokes, and planning the ultimate match.", "sfx": "[cheer, laugh]", "action": "sharing_food"},
            {"section": "SCENE_2", "scene_name": "gully_cricket_match_begins", "theme_category": "sports", "animation_pattern": "street_adventure", "camera_motion": "pan_and_track", "visual_prompt": "Sunny Indian street alley setup for gully cricket, brick wickets, wooden bat, bowler charging in", "lyrics": "Gully cricket begins under the scorching summer sun with brick wickets!", "sfx": "[swish, cheer]", "action": "batting"},
            {"section": "SCENE_3", "scene_name": "huge_sixer_broken_pot", "theme_category": "comedy", "animation_pattern": "sports_action", "camera_motion": "bounce_zoom", "visual_prompt": "Tennis ball hit high over terrace roofs, landing near neighbor's balcony, kids giving funny shocked expressions", "lyrics": "Massive six over the roof! And... there goes the neighbor's flower pot. Run!", "sfx": "[gasp, giggle]", "action": "running"},
            {"section": "SCENE_4", "scene_name": "summer_holidays_mango_orchard", "theme_category": "adventure", "animation_pattern": "dance_party", "camera_motion": "stage_pulse", "visual_prompt": "Summer vacation begins, kids under big lush mango tree eating ripe mangoes and riding bicycles happily", "lyrics": "Summer holidays are here! Ripe mangoes, bicycle races, and absolute freedom.", "sfx": "[yay, cheer]", "action": "celebrating"},
            {"section": "OUTRO", "scene_name": "summer_sunset_memories", "theme_category": "celebration", "animation_pattern": "street_adventure", "camera_motion": "sweep_reveal", "visual_prompt": "Golden hour sunset over colorful street, friends sitting together on boundary wall drinking cold drinks, waving goodbye", "lyrics": "Nothing beats summer memories with best friends. See you in the next video!", "sfx": "[cheer]", "action": "waving"}
        ]

    # 2. Mom & Sabzi Bazar / Street Food
    elif any(k in text for k in ["mom", "sabzi", "bazar", "bazaar", "market", "vegetable"]):
        return [
            {"section": "INTRO", "scene_name": "sabzi_mandi_crowd_arrival", "theme_category": "travel", "animation_pattern": "street_adventure", "camera_motion": "pan_and_track", "visual_prompt": f"Vibrant crowded Indian vegetable market (Sabzi Mandi) with colorful fresh produce stalls and lively crowds - {clean_topic}", "lyrics": "Stepping into the bustling vegetable market with mom on a shopping mission!", "sfx": "[traffic_horn]", "action": "walking"},
            {"section": "SCENE_1", "scene_name": "mom_bargaining_masterclass", "theme_category": "comedy", "animation_pattern": "comedy_vlog", "camera_motion": "focal_zoom", "visual_prompt": "Mom expertly bargaining with smiling vegetable vendor over fresh tomatoes and potatoes, asking for free coriander (Dhaniya)", "lyrics": "Witnessing the legendary bargaining masterclass and demanding free dhaniya!", "sfx": "[laugh, chirp]", "action": "bargaining"},
            {"section": "SCENE_2", "scene_name": "street_food_panipuri_stall", "theme_category": "celebration", "animation_pattern": "dance_party", "camera_motion": "stage_pulse", "visual_prompt": "Exciting street food corner stall with spicy crispy panipuri (golgappe) and sizzling chaat, kids cheering", "lyrics": "Stopping by the spicy panipuri and chaat stall for the ultimate crispy treat.", "sfx": "[sizzle, yum]", "action": "eating"},
            {"section": "SCENE_3", "scene_name": "heavy_shopping_bags_comedy", "theme_category": "comedy", "animation_pattern": "comedy_vlog", "camera_motion": "bounce_zoom", "visual_prompt": "Carrying overflowing colorful cloth bags full of vegetables and fruits through the bustling street", "lyrics": "Carrying five heavy bags while mom looks for yet another vegetable stall.", "sfx": "[pant, giggle]", "action": "carrying"},
            {"section": "SCENE_4", "scene_name": "home_cooked_feast_party", "theme_category": "celebration", "animation_pattern": "dance_party", "camera_motion": "sweep_reveal", "visual_prompt": "Warm home kitchen with mom serving steaming hot pakoras and tea to the happy cheering family", "lyrics": "Back home to hot crispy snacks, steaming chai, and family laughs.", "sfx": "[cheer, clap]", "action": "dancing"},
            {"section": "OUTRO", "scene_name": "market_sunset_farewell", "theme_category": "celebration", "animation_pattern": "street_adventure", "camera_motion": "sweep_reveal", "visual_prompt": "Cozy sunset evening on the family balcony, enjoying evening snacks and waving goodbye with big smiles", "lyrics": "Another successful bazaar day in the books! Like and subscribe!", "sfx": "[cheer]", "action": "waving"}
        ]

    # 3. Siblings / Childhood Memories / Boarding School
    elif any(k in text for k in ["sibling", "childhood", "boarding", "brother", "sister", "memories"]):
        return [
            {"section": "INTRO", "scene_name": "living_room_tv_remote_fight", "theme_category": "comedy", "animation_pattern": "comedy_vlog", "camera_motion": "bounce_zoom", "visual_prompt": f"Cozy childhood living room with brother and sister wrestling humorously over the TV remote control - {clean_topic}", "lyrics": "The eternal sibling war begins over who controls the TV remote!", "sfx": "[shout, laugh]", "action": "fighting"},
            {"section": "SCENE_1", "scene_name": "secret_kitchen_snack_raid", "theme_category": "comedy", "animation_pattern": "comedy_vlog", "camera_motion": "focal_zoom", "visual_prompt": "Siblings tiptoeing into the kitchen at midnight to secretly open the biscuit jar and hide sweets", "lyrics": "Midnight mission to raid the snack jar without waking up mom.", "sfx": "[whisper, munch]", "action": "tiptoeing"},
            {"section": "SCENE_2", "scene_name": "boarding_school_dorm_fun", "theme_category": "school", "animation_pattern": "dance_party", "camera_motion": "stage_pulse", "visual_prompt": "Hostel dorm room with bunks, epic pillow fight with flying feathers and friends laughing together", "lyrics": "Hostel dorm life: epic pillow fights and endless late-night stories.", "sfx": "[cheer, shout]", "action": "pillow_fight"},
            {"section": "SCENE_3", "scene_name": "street_hide_and_seek_game", "theme_category": "adventure", "animation_pattern": "street_adventure", "camera_motion": "pan_and_track", "visual_prompt": "Neighborhood street courtyard playing childhood games like hide and seek, hopscotch and cycle race", "lyrics": "Playing hide-and-seek till the evening street lights turn on.", "sfx": "[yay, laugh]", "action": "running"},
            {"section": "SCENE_4", "scene_name": "childhood_photo_nostalgia_dance", "theme_category": "celebration", "animation_pattern": "dance_party", "camera_motion": "sweep_reveal", "visual_prompt": "Looking at colorful childhood photo album together with family, laughing and dancing in celebration", "lyrics": "Laughing at funny old childhood photos and celebrating the memories.", "sfx": "[applause, cheer]", "action": "dancing"},
            {"section": "OUTRO", "scene_name": "rooftop_sunset_siblings_hug", "theme_category": "celebration", "animation_pattern": "street_adventure", "camera_motion": "sweep_reveal", "visual_prompt": "Golden sunset rooftop terrace, siblings sharing a high-five and waving goodbye to the camera", "lyrics": "Siblings fight, but they're always best friends forever. Catch you in the next one!", "sfx": "[cheer]", "action": "waving"}
        ]

    # 4. College / Hostel Stories / Relationships
    elif any(k in text for k in ["college", "hostel", "relationship", "canteen", "campus", "crush"]):
        return [
            {"section": "INTRO", "scene_name": "college_campus_main_gate", "theme_category": "school", "animation_pattern": "educational_focus", "camera_motion": "pan_and_track", "visual_prompt": f"Grand colorful college campus entrance gates with backpack students walking in excitedly - {clean_topic}", "lyrics": "Walking through the college gates where every day is a comedy show.", "sfx": "[bell_ring]", "action": "entering"},
            {"section": "SCENE_1", "scene_name": "hostel_room_midnight_maggi", "theme_category": "comedy", "animation_pattern": "comedy_vlog", "camera_motion": "focal_zoom", "visual_prompt": "Hostel room with friends gathered around an electric kettle cooking midnight 2-minute Maggi noodles and sharing stories", "lyrics": "Midnight 2-minute Maggi in the electric kettle—the fuel of engineers!", "sfx": "[slurp, laugh]", "action": "eating"},
            {"section": "SCENE_2", "scene_name": "college_canteen_chai_session", "theme_category": "celebration", "animation_pattern": "dance_party", "camera_motion": "stage_pulse", "visual_prompt": "Lively college canteen with cutting chai cups, samosas, someone playing guitar and friends singing along", "lyrics": "Canteen chai sessions with friends, loud gossip, and acoustic jams.", "sfx": "[music, cheer]", "action": "singing"},
            {"section": "SCENE_3", "scene_name": "exam_night_cramming_panic", "theme_category": "comedy", "animation_pattern": "comedy_vlog", "camera_motion": "bounce_zoom", "visual_prompt": "Hilarious night-before-exam study room with messy books, notes flying everywhere and friends teaching each other", "lyrics": "One night before exams: 10 chapters in 3 hours. Pure panic and genius!", "sfx": "[gasp, scribble]", "action": "studying"},
            {"section": "SCENE_4", "scene_name": "college_fest_dj_night", "theme_category": "celebration", "animation_pattern": "dance_party", "camera_motion": "sweep_reveal", "visual_prompt": "Electrifying college cultural fest stage with glowing neon DJ lights, laser beams and huge crowd dancing", "lyrics": "Annual fest DJ night explodes with music, lights, and dancing crowds!", "sfx": "[music, cheer]", "action": "dancing"},
            {"section": "OUTRO", "scene_name": "campus_sunset_farewell_circle", "theme_category": "celebration", "animation_pattern": "street_adventure", "camera_motion": "sweep_reveal", "visual_prompt": "Golden hour sunset on college stadium steps, best friends posing for a group picture and waving goodbye", "lyrics": "College days fade fast, but the memories stay forever. See you next time!", "sfx": "[cheer]", "action": "waving"}
        ]

    # 5. Superstitions & Family / Andhwishvas
    elif any(k in text for k in ["andhwishvas", "superstition", "nimbu", "totka", "nazar", "billi", "cat"]):
        return [
            {"section": "INTRO", "scene_name": "home_doorway_nimbu_mirchi", "theme_category": "comedy", "animation_pattern": "street_adventure", "camera_motion": "focal_zoom", "visual_prompt": f"Traditional colorful home doorway with fresh green chillies and lemon (Nimbu Mirchi) hanging to ward off bad luck - {clean_topic}", "lyrics": "Every Indian home entrance starts with the legendary Nimbu-Mirchi shield!", "sfx": "[wind_chime]", "action": "introducing"},
            {"section": "SCENE_1", "scene_name": "black_cat_road_crossing_freeze", "theme_category": "comedy", "animation_pattern": "comedy_vlog", "camera_motion": "bounce_zoom", "visual_prompt": "Cute black cartoon cat crosses the street and everyone instantly freezes like statues with funny shocked eyes", "lyrics": "Black cat crosses the road! Everyone freezes and waits for someone else to walk first.", "sfx": "[meow, gasp]", "action": "freezing"},
            {"section": "SCENE_2", "scene_name": "sweet_dahi_cheeni_blessing", "theme_category": "celebration", "animation_pattern": "dance_party", "camera_motion": "stage_pulse", "visual_prompt": "Grandmother feeding sweet curd and sugar (Dahi Cheeni) for good luck, surrounded by sparkling cartoon stars and cheers", "lyrics": "Sweet Dahi-Cheeni spoonful before any big test or game for 100% luck!", "sfx": "[cheer, yum]", "action": "eating"},
            {"section": "SCENE_3", "scene_name": "lucky_shirt_inside_out_comedy", "theme_category": "comedy", "animation_pattern": "comedy_vlog", "camera_motion": "focal_zoom", "visual_prompt": "Wearing a lucky bright shirt inside-out and checking funny daily horoscope signs with friends", "lyrics": "Wearing the lucky inside-out shirt and checking the daily horoscope.", "sfx": "[giggle, laugh]", "action": "reacting"},
            {"section": "SCENE_4", "scene_name": "grand_lucky_victory_dance", "theme_category": "celebration", "animation_pattern": "dance_party", "camera_motion": "sweep_reveal", "visual_prompt": "Triumphant victory party with colorful confetti and dancing, proving belief and hard work create magic", "lyrics": "Hard work and a little sweet luck lead to ultimate victory!", "sfx": "[applause, cheer]", "action": "dancing"},
            {"section": "OUTRO", "scene_name": "peaceful_sunset_blessings", "theme_category": "celebration", "animation_pattern": "street_adventure", "camera_motion": "sweep_reveal", "visual_prompt": "Golden sunset lighting up the peaceful family balcony with warm diya lamps, smiling and waving goodbye", "lyrics": "Believe in yourself and your hustle! Like, share, and stay blessed!", "sfx": "[cheer]", "action": "waving"}
        ]

    # 6. Kolkata / City Travel / Road Trip
    elif any(k in text for k in ["kolkata", "delhi", "mumbai", "trip", "travel", "tour", "train", "flight", "mountain", "beach"]):
        return [
            {"section": "INTRO", "scene_name": "city_arrival_yellow_taxis", "theme_category": "travel", "animation_pattern": "vehicle_cruising", "camera_motion": "pan_and_track", "visual_prompt": f"Iconic city landmark with bustling streets, classic bright yellow taxis, street tea stalls and crowds - {clean_topic}", "lyrics": "Arriving in the vibrant city with iconic yellow taxis and bustling streets!", "sfx": "[traffic_horn]", "action": "arriving"},
            {"section": "SCENE_1", "scene_name": "street_food_kathi_rolls_bazaar", "theme_category": "travel", "animation_pattern": "food_munch", "camera_motion": "focal_zoom", "visual_prompt": "Vibrant street food lane with sizzling kathi rolls, sweet jalebis and excited friends tasting hot snacks", "lyrics": "Savoring hot kathi rolls, sweet roshogolla, and steaming street snacks.", "sfx": "[sizzle, yum]", "action": "eating"},
            {"section": "SCENE_2", "scene_name": "howrah_bridge_river_cruise", "theme_category": "travel", "animation_pattern": "vehicle_cruising", "camera_motion": "bounce_zoom", "visual_prompt": "Cruising down the river under the majestic iconic steel bridge with boats, seagulls and cheerful tourists", "lyrics": "River cruising beneath the monumental steel bridge with cool breezes!", "sfx": "[cheer, horn]", "action": "sightseeing"},
            {"section": "SCENE_3", "scene_name": "monument_selfie_session", "theme_category": "travel", "animation_pattern": "comedy_vlog", "camera_motion": "focal_zoom", "visual_prompt": "Taking funny group selfies and poses in front of grand historical white marble monument gardens", "lyrics": "Striking dramatic poses for group selfies at historical monuments.", "sfx": "[camera_click]", "action": "posing"},
            {"section": "SCENE_4", "scene_name": "city_night_lights_puja_party", "theme_category": "celebration", "animation_pattern": "dance_party", "camera_motion": "stage_pulse", "visual_prompt": "Illuminated festive city street with glowing carnival light arches, traditional drums (Dhak) and dancing crowds", "lyrics": "Festive night lights, rhythmic beats, and electric celebration energy!", "sfx": "[music, cheer]", "action": "dancing"},
            {"section": "OUTRO", "scene_name": "river_sunset_skyline_farewell", "theme_category": "travel", "animation_pattern": "street_adventure", "camera_motion": "sweep_reveal", "visual_prompt": "Dramatic golden sunset over the river skyline, friends looking at travel photos, smiling and waving goodbye", "lyrics": "What an unforgettable journey! Drop your city in the comments below!", "sfx": "[cheer]", "action": "waving"}
        ]

    # 7. Horror / Spooky Comedy
    elif any(k in text for k in ["horror", "ghost", "bhoot", "spooky", "haunted", "night", "dark"]):
        return [
            {"section": "INTRO", "scene_name": "spooky_old_mansion", "theme_category": "horror", "animation_pattern": "bedtime_sway", "camera_motion": "float_sway", "visual_prompt": f"Misty dark night with ancient haunted haveli mansion, flickering lanterns and giant full moon - {clean_topic}", "lyrics": "Midnight at the spooky old haveli with a full glowing moon and howling winds.", "sfx": "[wind_howl]", "action": "tiptoeing"},
            {"section": "SCENE_1", "scene_name": "creaking_door_mystery", "theme_category": "horror", "animation_pattern": "comedy_vlog", "camera_motion": "focal_zoom", "visual_prompt": "Creaking wooden door opening slowly, mysterious glowing green footprints on dusty floor", "lyrics": "The door creaks open... mysterious glowing footprints on the floor!", "sfx": "[creak]", "action": "peeking"},
            {"section": "SCENE_2", "scene_name": "funny_ghost_reveal", "theme_category": "comedy", "animation_pattern": "dance_party", "camera_motion": "bounce_zoom", "visual_prompt": "Friendly funny cartoon ghost wearing cool sunglasses pops out and starts breakdancing", "lyrics": "The ghost pops out wearing sunglasses and starts breakdancing!", "sfx": "[boo, laugh]", "action": "dancing"},
            {"section": "SCENE_3", "scene_name": "haunted_kitchen_snack", "theme_category": "comedy", "animation_pattern": "food_munch", "camera_motion": "focal_zoom", "visual_prompt": "Ghost and friends making midnight snacks together in spooky glowing kitchen", "lyrics": "Sharing midnight snacks with our friendly neighborhood ghost.", "sfx": "[munch, chuckle]", "action": "eating"},
            {"section": "SCENE_4", "scene_name": "monster_disco_dance", "theme_category": "celebration", "animation_pattern": "dance_party", "camera_motion": "stage_pulse", "visual_prompt": "Spooky monster disco party with colorful party lights, floating glowing pumpkins and cheering crowd", "lyrics": "Epic monster disco party under the glowing lanterns!", "sfx": "[cheer, dance]", "action": "dancing"},
            {"section": "OUTRO", "scene_name": "sunrise_clears_the_fog", "theme_category": "celebration", "animation_pattern": "street_adventure", "camera_motion": "sweep_reveal", "visual_prompt": "Golden sunrise over the peaceful haveli, friendly ghost waving goodbye from window", "lyrics": "Sunrise clears the spooky fog. Sleep well and don't look under the bed!", "sfx": "[cheer]", "action": "waving"}
        ]

    # 8. Single Topic Cricket / Sports
    elif any(k in text for k in ["cricket", "gully", "match", "ball", "bat", "wicket", "sixer"]):
        return [
            {"section": "INTRO", "scene_name": "gully_cricket_street", "theme_category": "sports", "animation_pattern": "street_adventure", "camera_motion": "pan_and_track", "visual_prompt": f"Vibrant sunny Indian street alley setup for gully cricket, brick wickets, wooden bat, friends excited - {clean_topic}", "lyrics": "Match day on the street! Brick wickets ready, toss is up!", "sfx": "[cheer]", "action": "getting_ready"},
            {"section": "SCENE_1", "scene_name": "bowling_and_batting", "theme_category": "sports", "animation_pattern": "sports_action", "camera_motion": "bounce_zoom", "visual_prompt": "Bowler running in fast down the narrow street and batsman swinging wooden bat with intense focus", "lyrics": "Bowler charges in fast, batsman eyes the ball with razor focus!", "sfx": "[swish]", "action": "batting"},
            {"section": "SCENE_2", "scene_name": "huge_sixer_over_roof", "theme_category": "sports", "animation_pattern": "dance_party", "camera_motion": "sweep_reveal", "visual_prompt": "Tennis ball flying high into the blue sky over neighborhood terrace roofs, crowd cheering wildly", "lyrics": "Smacked hard! The ball sails high over the neighborhood roofs!", "sfx": "[whistle, cheer]", "action": "celebrating"},
            {"section": "SCENE_3", "scene_name": "broken_window_comedy", "theme_category": "comedy", "animation_pattern": "comedy_vlog", "camera_motion": "focal_zoom", "visual_prompt": "Ball landing near neighbor's balcony, kids giving funny shocked expressions and tiptoeing", "lyrics": "Ball lands in uncle's balcony... who's brave enough to ask for it back?", "sfx": "[gasp, giggle]", "action": "running"},
            {"section": "SCENE_4", "scene_name": "championship_trophy_street", "theme_category": "sports", "animation_pattern": "dance_party", "camera_motion": "stage_pulse", "visual_prompt": "Winning team dancing with homemade wooden trophy in the middle of street with colored powder and celebration", "lyrics": "Champions of the street! Raising the trophy with colored celebrations!", "sfx": "[clap, cheer]", "action": "dancing"},
            {"section": "OUTRO", "scene_name": "sunset_gully_memories", "theme_category": "celebration", "animation_pattern": "street_adventure", "camera_motion": "sweep_reveal", "visual_prompt": "Golden hour sunset over colorful street, friends sitting on boundary wall drinking cold drinks, waving goodbye", "lyrics": "Sunset wraps up the best game ever. Hit that subscribe button for more matches!", "sfx": "[cheer]", "action": "waving"}
        ]

    # 9. General / Any custom video topic
    else:
        return [
            {"section": "INTRO", "scene_name": "story_setting_intro", "theme_category": "adventure", "animation_pattern": "street_adventure", "camera_motion": "sweep_reveal", "visual_prompt": f"Vibrant 3D animated cinematic opening scene establishing the lively world of '{clean_topic}' with detailed props and colorful environment", "lyrics": f"Welcome to the wild and hilarious story of {clean_topic}!", "sfx": "[whoosh]", "action": "introducing"},
            {"section": "SCENE_1", "scene_name": "story_activity_begins", "theme_category": "adventure", "animation_pattern": "bounce_zoom", "camera_motion": "focal_zoom", "visual_prompt": f"Characters diving into the main energetic action and relatable fun moments of '{clean_topic}'", "lyrics": f"Getting straight into the chaotic and relatable action of {clean_topic}.", "sfx": "[laugh]", "action": "acting"},
            {"section": "SCENE_2", "scene_name": "high_energy_climax", "theme_category": "celebration", "animation_pattern": "dance_party", "camera_motion": "stage_pulse", "visual_prompt": f"Explosive, colorful, high-energy party and celebration themed around '{clean_topic}' with expressive animated characters", "lyrics": "Energy hits the roof as the whole gang joins the celebration!", "sfx": "[cheer, shout]", "action": "dancing"},
            {"section": "SCENE_3", "scene_name": "comedy_adventure_twist", "theme_category": "comedy", "animation_pattern": "comedy_vlog", "camera_motion": "pan_and_track", "visual_prompt": f"Hilarious unexpected comedic twist and relatable story moment relating to '{clean_topic}'", "lyrics": "An unexpected twist turns everything completely upside down!", "sfx": "[gasp, laugh]", "action": "reacting"},
            {"section": "SCENE_4", "scene_name": "grand_group_action", "theme_category": "celebration", "animation_pattern": "dance_party", "camera_motion": "stage_pulse", "visual_prompt": f"Grand triumphant group celebration and dancing with all friends cheering for '{clean_topic}'", "lyrics": "Coming together for the grand victorious celebration!", "sfx": "[applause, cheer]", "action": "celebrating"},
            {"section": "OUTRO", "scene_name": "cinematic_sunset_finale", "theme_category": "celebration", "animation_pattern": "street_adventure", "camera_motion": "sweep_reveal", "visual_prompt": f"Beautiful cinematic golden hour sunset finale scene for '{clean_topic}', characters smiling and waving goodbye", "lyrics": "That wraps up today's story! Comment your favorite moment and subscribe!", "sfx": "[cheer]", "action": "waving"}
        ]

def _generate_local_fallback_script(title: str, theme: str, narrative_context: dict = None) -> Tuple[str, Dict[str, Any]]:
    """Generates a dynamic comedic animated storytelling script using extracted transcript dialogue."""
    storyboard = _generate_default_storyboard(title, theme, narrative_context)
    channel_name = getattr(config, "TARGET_CHANNEL_NAME", "NOT YOUR TYPE")

    lines = [
        "================================================================================",
        f"{channel_name.upper()} - ANIMATED STORYTELLING SCRIPT",
        "================================================================================",
        f"TITLE: {title}",
        f"THEME: {theme}",
        "GENRE: Relatable Comedic Animated Story",
        "ESTIMATED RUNTIME: 2:00 Minutes\n"
    ]

    for idx, beat in enumerate(storyboard):
        sec = beat.get("section", f"BEAT_{idx+1}")
        name = beat.get("scene_name", f"Scene {idx+1}")
        dialogue = beat.get("lyrics", "Exciting story moments unfold with hilarious character dialogue.")
        sfx = beat.get("sfx", "[laugh]")
        action = beat.get("action", "talking")
        
        lines.append(f"[{sec}: {name.upper()}] ({action})")
        lines.append(f"Narrator: {dialogue} {sfx}\n")

    lines.append("================================================================================")
    script = "\n".join(lines)

    meta = {
        "generator": "Dynamic Narrative Storyboard Engine",
        "model": "scraped-transcript-adaptive",
        "script_length_words": len(script.split()),
        "storyboard_scenes": len(storyboard),
        "storyboard": storyboard,
        "estimated_runtime": "2:00 (120s)",
        "status": "adaptive_template_success"
    }
    return script, meta

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    script, metadata = generate_animated_video_script(
        title="Indian Schools , Gully Cricket & Summer Holidays",
        theme="Desi childhood memories and gully cricket"
    )
    print("\n--- SCRIPT PREVIEW ---")
    print(script[:400] + "...\n")
    print("--- STORYBOARD SCENES ---")
    print(json.dumps(metadata.get("storyboard", []), indent=2))
