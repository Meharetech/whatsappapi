@echo off
title NOT YOUR TYPE - Autonomous Video Production Studio GUI
echo ========================================================
echo  NOT YOUR TYPE - Autonomous Video Studio (CustomTkinter)
echo ========================================================
echo Launching GUI Application...
echo.

python gui_app.py

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo GUI stopped with error code %ERRORLEVEL%.
    pause
)
