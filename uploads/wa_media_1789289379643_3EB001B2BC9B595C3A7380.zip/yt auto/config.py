import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env if present
load_dotenv()

# Base Workspace Paths
BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "cocolemon_output"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

SCRIPT_OUTPUT_FILE = OUTPUT_DIR / "script.txt"
METADATA_OUTPUT_FILE = OUTPUT_DIR / "metadata.json"
AUDIO_OUTPUT_FILE = OUTPUT_DIR / "voiceover.mp3"
THUMBNAIL_OUTPUT_FILE = OUTPUT_DIR / "thumbnail.png"
VIDEO_OUTPUT_FILE = OUTPUT_DIR / "video.mp4"
LOG_OUTPUT_FILE = OUTPUT_DIR / "execution.log"

# Target YouTube Channel RSS Configuration (@NOTYOURTYPE)
TARGET_CHANNEL_ID = os.getenv("TARGET_CHANNEL_ID", "UCKnNrlSJF_hWoBSz1lY_D7g")
TARGET_CHANNEL_HANDLE = "@NOTYOURTYPE"
TARGET_CHANNEL_NAME = "NOT YOUR TYPE"
CHANNEL_URL = f"https://www.youtube.com/{TARGET_CHANNEL_HANDLE}"
COCOMELON_CHANNEL_ID = TARGET_CHANNEL_ID # Backward compatibility alias
YOUTUBE_RSS_URL = f"https://www.youtube.com/feeds/videos.xml?channel_id={TARGET_CHANNEL_ID}"
REQUEST_TIMEOUT_SECONDS = 10

# Groq API Configuration
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")
GROQ_FALLBACK_MODELS = [
    "llama-3.3-70b-versatile",
    "qwen/qwen3.8-27b",
    "groq/compound",
    "openai/gpt-oss-20b"
]

# ElevenLabs TTS Configuration
ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY", "")
ELEVENLABS_VOICE_ID = os.getenv("ELEVENLABS_VOICE_ID", "Xb7hH8MSUJpSbSDYk0k2")
ELEVENLABS_MODEL_ID = os.getenv("ELEVENLABS_MODEL_ID", "eleven_flash_v2_5")

# Video Rendering Configuration
VIDEO_WIDTH = 1920
VIDEO_HEIGHT = 1080
VIDEO_FPS = 24

# Pollinations AI Configuration (100% Free AI 3D Image & Scene Generation)
USE_POLLINATIONS_AI = os.getenv("USE_POLLINATIONS_AI", "true").lower() == "true"
POLLINATIONS_MODEL = os.getenv("POLLINATIONS_MODEL", "flux") # 'flux', 'turbo'
POLLINATIONS_TIMEOUT_SECONDS = int(os.getenv("POLLINATIONS_TIMEOUT_SECONDS", "30"))


# YouTube API & OAuth Configuration
CLIENT_SECRETS_FILE = BASE_DIR / "client_secrets.json"
YOUTUBE_TOKEN_FILE = BASE_DIR / "token.json"
YOUTUBE_SCOPES = [
    "https://www.googleapis.com/auth/youtube.upload",
    "https://www.googleapis.com/auth/youtube"
]
# Default Visibility: PUBLIC
DEFAULT_YOUTUBE_PRIVACY = os.getenv("YOUTUBE_PRIVACY", "public") # 'public', 'unlisted', or 'private'
DEFAULT_YOUTUBE_CATEGORY_ID = "24" # 24 = Entertainment, 27 = Education, 10 = Music

# Default Fallback Themes for Toddler Content
DEFAULT_FALLBACK_THEMES = [
    {
        "title": "Wheels on the Bus & Animal Friends",
        "topic": "Vehicles, sounds, and friendly animals going around town",
        "keywords": ["bus", "beep beep", "animals", "wheels", "vroom"]
    },
    {
        "title": "The Clean Up Song & Toy Sorting Fun",
        "topic": "Cleaning up toys happily, putting blocks in boxes",
        "keywords": ["clean up", "tidy", "toys", "put away", "clap clap"]
    },
    {
        "title": "Yummy Healthy Fruits & Veggies Song",
        "topic": "Eating crunchy apples, bananas, and colorful veggies with joy",
        "keywords": ["yum yum", "fruits", "veggies", "healthy", "crunch"]
    },
    {
        "title": "Bedtime Sleepy Stars & Goodnight Rhyme",
        "topic": "Brushing teeth, putting on pajamas, hugging teddy bear, and counting stars",
        "keywords": ["goodnight", "stars", "sleepy", "twinkle", "hush"]
    },
    {
        "title": "Sharing is Caring with JJ & Friends",
        "topic": "Sharing crayons, balls, and taking turns at the playground",
        "keywords": ["share", "friends", "together", "taking turns", "yay"]
    }
]
