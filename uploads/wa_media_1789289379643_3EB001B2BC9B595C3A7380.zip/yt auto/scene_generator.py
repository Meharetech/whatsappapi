import os
import io
import math
import logging
import urllib.parse
import requests
from pathlib import Path
from typing import Dict, Any, List, Optional
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
import config

logger = logging.getLogger("cocolemon_pipeline")

SCENES_DIR = config.OUTPUT_DIR / "scenes"
SCENES_DIR.mkdir(parents=True, exist_ok=True)

import time

def fetch_pollinations_scene_image(
    prompt: str,
    width: int = config.VIDEO_WIDTH,
    height: int = config.VIDEO_HEIGHT,
    seed: Optional[int] = None
) -> Optional[Image.Image]:
    """
    Fetches a photorealistic 3D cartoon/Pixar style background from Pollinations AI (100% Free Flux/Turbo model).
    Returns a PIL Image on success, or None on failure/timeout.
    """
    # Try preferred model first, then fast turbo fallback
    models = [config.POLLINATIONS_MODEL, "turbo"] if config.POLLINATIONS_MODEL != "turbo" else ["turbo"]

    for model_name in models:
        try:
            full_prompt = (
                f"3D stylized animation render, highly detailed cinematic cartoon scene, vibrant colors, "
                f"dynamic studio lighting, expressive environment, 8k render, {prompt}"
            )
            encoded_prompt = urllib.parse.quote(full_prompt)
            seed_param = f"&seed={seed}" if seed is not None else ""
            url = (
                f"https://image.pollinations.ai/prompt/{encoded_prompt}"
                f"?width={width}&height={height}&model={model_name}&nologo=true&enhance=true{seed_param}"
            )

            logger.info(f"-> Requesting Pollinations AI 3D scene ({model_name}) for: '{prompt[:50]}...'")
            resp = requests.get(url, timeout=config.POLLINATIONS_TIMEOUT_SECONDS)

            if resp.status_code == 200 and resp.content:
                img = Image.open(io.BytesIO(resp.content)).convert("RGBA")
                if img.size != (width, height):
                    img = img.resize((width, height), Image.Resampling.LANCZOS)
                logger.info(f"-> Successfully downloaded Pollinations AI 3D scene ({width}x{height})")
                return img
            elif resp.status_code == 429:
                logger.warning(f"Pollinations AI {model_name} rate-limited (429). Trying fallback model...")
                time.sleep(1.0)
                continue
            else:
                logger.warning(f"Pollinations AI {model_name} returned HTTP {resp.status_code}. Trying fallback...")
                continue
        except Exception as e:
            logger.warning(f"Pollinations AI {model_name} request failed ({e}). Trying fallback...")
            continue

    logger.warning("Pollinations AI models unavailable. Smoothly rendering with procedural engine.")
    return None

def generate_scene_artworks(
    storyboard: List[Dict[str, Any]],
    width: int = config.VIDEO_WIDTH,
    height: int = config.VIDEO_HEIGHT,
    use_ai: bool = config.USE_POLLINATIONS_AI,
    use_pollinations: Optional[bool] = None,
    **kwargs
) -> List[Path]:
    """
    Renders and caches high-resolution 1080p cartoon scene backgrounds for each
    storyboard beat in the video using Pollinations AI (with procedural fallback).
    Cleans up old scene files to guarantee that every scrape gets 100% fresh, accurate scenes.
    """
    if use_pollinations is not None:
        use_ai = use_pollinations

    SCENES_DIR.mkdir(parents=True, exist_ok=True)

    # Clean existing scene files to avoid reusing or mixing old scenes
    try:
        for old_scene in SCENES_DIR.glob("scene_*.png"):
            try:
                old_scene.unlink()
            except Exception:
                pass
    except Exception:
        pass

    scene_paths = []

    for idx, scene in enumerate(storyboard):
        scene_name = scene.get("scene_name", f"scene_{idx}")
        output_file = SCENES_DIR / f"scene_{idx}_{scene_name}.png"
        visual_prompt = scene.get("visual_prompt", scene.get("scene_name", "vibrant cartoon scene"))

        img = None
        if use_ai:
            if idx > 0:
                time.sleep(1.2) # Small delay to avoid API rate-limiting
            img = fetch_pollinations_scene_image(visual_prompt, width=width, height=height)

        # If AI generation is disabled or fails, render with rich procedural engine
        if img is None:
            img = _render_scene_artwork(idx, scene, width, height)

        img.save(output_file, "PNG", quality=95)
        
        # Mirror to output root for direct gallery access (scene_1.png ... scene_6.png)
        try:
            root_scene_file = config.OUTPUT_DIR / f"scene_{idx+1}.png"
            img.save(root_scene_file, "PNG", quality=95)
        except Exception:
            pass

        scene_paths.append(output_file)
        logger.info(f"-> Cached storyboard scene {idx+1}/{len(storyboard)}: {output_file.name}")

    return scene_paths

def _render_scene_artwork(idx: int, scene: dict, w: int, h: int) -> Image.Image:
    """Renders rich 3D cartoon styled environments with lighting and depth matching the storyboard beat."""
    scene_name = scene.get("scene_name", "").lower()
    prompt = scene.get("visual_prompt", "").lower()
    category = scene.get("theme_category", "").lower()
    combined = f"{scene_name} {prompt} {category}"

    img = Image.new("RGBA", (w, h), (255, 255, 255, 255))
    draw = ImageDraw.Draw(img)

    # 1. Cricket / Gully / Match / Sports
    if any(k in combined for k in ["cricket", "gully", "match", "bat", "ball", "wicket", "sixer", "pitch"]):
        _draw_gully_cricket_environment(draw, w, h)
    # 2. Sabzi Mandi / Market / Bargaining / Street Food
    elif any(k in combined for k in ["sabzi", "mandi", "bazar", "bazaar", "market", "panipuri", "chaat", "vegetable"]):
        _draw_sabzi_market_environment(draw, w, h)
    # 3. College / Hostel / Campus / Canteen / Dorm
    elif any(k in combined for k in ["college", "hostel", "canteen", "dorm", "fest"]):
        _draw_college_campus_environment(draw, w, h)
    # 4. Siblings / Living Room / TV / Home Interior
    elif any(k in combined for k in ["sibling", "living_room", "tv_remote", "couch", "sofa", "pillow_fight"]):
        _draw_childhood_living_room_environment(draw, w, h)
    # 5. Superstition / Doorway / Nimbu Mirchi / Dahi Cheeni
    elif any(k in combined for k in ["nimbu", "mirchi", "andhwishvas", "superstition", "totka", "dahi", "doorway"]):
        _draw_superstition_home_environment(draw, w, h)
    # 6. School / Classroom / Desks / Blackboard
    elif any(k in combined for k in ["school", "classroom", "chalkboard", "bench", "desk", "exam", "recess", "bell_ring"]):
        _draw_school_campus_environment(draw, w, h)
    # 7. Summer / Holidays / Mango Tree / Orchard
    elif any(k in combined for k in ["summer", "holiday", "vacation", "mango", "orchard", "tree", "garden"]):
        _draw_summer_holiday_environment(draw, w, h)
    # 8. Horror / Spooky / Haunted Mansion / Night
    elif any(k in combined for k in ["horror", "ghost", "bhoot", "spooky", "haunted", "mansion", "haveli"]):
        _draw_spooky_mansion_environment(draw, w, h)
    # 9. Travel / City Road / Street / Vehicles / Kolkata / Taxi
    elif any(k in combined for k in ["city", "road", "vehicle", "bus", "taxi", "kolkata", "trip", "travel", "howrah", "monument"]):
        _draw_city_and_road_environment(draw, w, h)
    # 10. Bathroom / Bubbles / Bath Time
    elif any(k in combined for k in ["bath", "bubble", "soap", "tub", "wash", "shampoo"]):
        _draw_bathroom_bubbles_environment(draw, w, h)
    # 11. Bedtime / Night / Stars / Moon / Lullaby
    elif any(k in combined for k in ["bedtime", "bedroom", "night", "moon", "star", "lullaby", "dream"]):
        _draw_bedtime_starlight_environment(draw, w, h)
    # 12. Underwater / Ocean / Beach / Shark
    elif any(k in combined for k in ["ocean", "underwater", "coral", "sea", "shark", "beach", "whale"]):
        _draw_underwater_ocean_environment(draw, w, h)
    # 13. Kitchen / Food / Cooking
    elif any(k in combined for k in ["kitchen", "food", "fruit", "veggie", "yummy", "eat", "cook"]):
        _draw_kitchen_food_environment(draw, w, h)
    # 14. Jungle / Dinosaur
    elif any(k in combined for k in ["dino", "dinosaur", "jungle", "volcano"]):
        _draw_jungle_dinosaur_environment(draw, w, h)
    # 15. Rainbow / Celebration / Outro / Party
    elif any(k in combined for k in ["rainbow", "celebration", "outro", "sunset", "party", "fireworks", "win"]):
        _draw_rainbow_sunset_environment(draw, w, h)
    # 16. Default Dynamic Stage
    else:
        _draw_outdoor_stage_environment(draw, w, h)

    # Ambient depth lighting & soft glow overlay
    enhancer = ImageEnhance.Color(img)
    img = enhancer.enhance(1.15)
    return img.convert("RGB")

# -----------------------------------------------------------------------------
# 0. GULLY CRICKET / INDIAN STREET ENVIRONMENT
# -----------------------------------------------------------------------------
def _draw_gully_cricket_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws sun-soaked colorful Indian alley street with brick wickets and rooftop kites."""
    # Warm Sky
    for y in range(0, int(h * 0.55), 8):
        draw.rectangle([(0, y), (w, y + 8)], fill=(255, int(210 - y * 0.1), int(120 + y * 0.1), 255))
    # Big Bright Sun
    draw.ellipse([w - 240, 50, w - 100, 190], fill=(255, 230, 40), outline=(255, 245, 140), width=6)

    # Colorful Street Houses on Left & Right
    houses = [
        (20, 200, 220, (255, 120, 90)), (240, 240, 180, (255, 215, 80)),
        (w - 440, 230, 200, (80, 200, 240)), (w - 240, 190, 220, (255, 140, 180))
    ]
    for hx, hy, hw, hcol in houses:
        draw.rectangle([(hx, hy), (hx + hw, int(h * 0.65))], fill=hcol, outline=(255, 255, 255), width=4)
        for wy in range(hy + 30, int(h * 0.60), 55):
            draw.rectangle([(hx + 25, wy), (hx + hw - 25, wy + 35)], fill=(185, 235, 255), outline=(255, 255, 255), width=3)

    # Street Alley Floor
    draw.rectangle([(0, int(h * 0.65)), (w, h)], fill=(215, 175, 125))
    # Cricket Pitch Stripe
    draw.polygon([(int(w * 0.38), int(h * 0.65)), (int(w * 0.62), int(h * 0.65)), (int(w * 0.75), h), (int(w * 0.25), h)], fill=(235, 195, 145))

    # 3 Red Brick / Wooden Wickets in Center
    stump_x = w // 2
    stump_y = int(h * 0.72)
    for sx in [stump_x - 22, stump_x, stump_x + 22]:
        draw.rectangle([(sx - 4, stump_y - 70), (sx + 4, stump_y)], fill=(240, 210, 80), outline=(170, 120, 30), width=2)
    # Bail on top
    draw.rectangle([(stump_x - 26, stump_y - 74), (stump_x + 26, stump_y - 68)], fill=(240, 210, 80), outline=(170, 120, 30), width=2)

    # Red Cricket Tennis Ball in foreground
    ball_x, ball_y = int(w * 0.32), int(h * 0.82)
    draw.ellipse([ball_x - 24, ball_y - 24, ball_x + 24, ball_y + 24], fill=(255, 45, 45), outline=(255, 255, 255), width=3)
    draw.arc([ball_x - 20, ball_y - 20, ball_x + 20, ball_y + 20], 30, 210, fill=(255, 255, 255), width=2)

# -----------------------------------------------------------------------------
# 0.1 SCHOOL CAMPUS & COURTYARD ENVIRONMENT
# -----------------------------------------------------------------------------
def _draw_school_campus_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws cheerful school campus building with red brick walls, courtyard, clock tower, and trees."""
    for y in range(0, int(h * 0.55), 8):
        draw.rectangle([(0, y), (w, y + 8)], fill=(130 + int(y * 0.15), 215, 255, 255))
    draw.ellipse([80, 50, 200, 170], fill=(255, 225, 40), outline=(255, 245, 140), width=6)

    # School Main Building in background
    bx1, bx2 = int(w * 0.15), int(w * 0.85)
    by1, by2 = int(h * 0.28), int(h * 0.65)
    draw.rectangle([(bx1, by1), (bx2, by2)], fill=(215, 80, 75), outline=(160, 45, 40), width=6)

    # Clock Tower in center
    tw_x = w // 2
    draw.rectangle([(tw_x - 65, by1 - 90), (tw_x + 65, by1)], fill=(215, 80, 75), outline=(160, 45, 40), width=5)
    draw.polygon([(tw_x - 80, by1 - 90), (tw_x, by1 - 160), (tw_x + 80, by1 - 90)], fill=(255, 215, 80), outline=(190, 150, 40), width=4)
    # Clock Circle
    draw.ellipse([tw_x - 30, by1 - 75, tw_x + 30, by1 - 15], fill=(255, 255, 255), outline=(40, 40, 40), width=3)
    draw.line([(tw_x, by1 - 45), (tw_x, by1 - 65)], fill=(40, 40, 40), width=3)
    draw.line([(tw_x, by1 - 45), (tw_x + 14, by1 - 45)], fill=(40, 40, 40), width=3)

    # School Windows
    for wx in range(bx1 + 35, bx2 - 35, 95):
        draw.rounded_rectangle([wx, by1 + 30, wx + 55, by1 + 80], radius=8, fill=(185, 235, 255), outline=(255, 255, 255), width=3)
        draw.rounded_rectangle([wx, by1 + 110, wx + 55, by1 + 160], radius=8, fill=(185, 235, 255), outline=(255, 255, 255), width=3)

    # Courtyard Green Lawn
    draw.rectangle([(0, by2), (w, h)], fill=(105, 205, 80))
    draw.ellipse([int(w * 0.20), int(h * 0.70), int(w * 0.80), int(h * 0.95)], fill=(130, 225, 95))

# -----------------------------------------------------------------------------
# 0.2 SUMMER HOLIDAY & MANGO ORCHARD ENVIRONMENT
# -----------------------------------------------------------------------------
def _draw_summer_holiday_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws lush sunny summer landscape with lush green mango trees and picnic lawn."""
    for y in range(0, int(h * 0.55), 8):
        draw.rectangle([(0, y), (w, y + 8)], fill=(255, int(220 - y * 0.1), 140, 255))
    draw.ellipse([w - 200, 40, w - 80, 160], fill=(255, 220, 30), outline=(255, 245, 140), width=6)

    # Rolling Green Hills
    draw.ellipse([-150, int(h * 0.40), int(w * 0.65), int(h * 1.1)], fill=(90, 195, 75))
    draw.ellipse([int(w * 0.35), int(h * 0.38), w + 150, int(h * 1.1)], fill=(120, 215, 90))
    draw.rectangle([(0, int(h * 0.65)), (w, h)], fill=(105, 210, 80))

    # Big Lush Green Trees
    for tx in [140, w - 180]:
        draw.rectangle([(tx - 25, int(h * 0.45)), (tx + 25, int(h * 0.70))], fill=(135, 85, 45))
        draw.ellipse([tx - 110, int(h * 0.25), tx + 110, int(h * 0.55)], fill=(55, 175, 60))
        draw.ellipse([tx - 80, int(h * 0.18), tx + 80, int(h * 0.45)], fill=(75, 195, 75))
        # Ripe Golden Mangoes on Tree
        for mx, my in [(tx - 40, int(h * 0.35)), (tx + 30, int(h * 0.32)), (tx, int(h * 0.42))]:
            draw.ellipse([mx - 12, my - 16, mx + 12, my + 16], fill=(255, 195, 30))

# -----------------------------------------------------------------------------
# 0.3 SPOOKY HAUNTED MANSION ENVIRONMENT
# -----------------------------------------------------------------------------
def _draw_spooky_mansion_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws spooky nighttime mystery with full glowing moon, haunted castle silhouettes and mist."""
    for y in range(0, int(h * 0.70), 8):
        draw.rectangle([(0, y), (w, y + 8)], fill=(15 + int(y * 0.05), 18 + int(y * 0.05), 45 + int(y * 0.1), 255))

    # Giant Glowing Full Moon
    draw.ellipse([w // 2 - 120, 60, w // 2 + 120, 300], fill=(255, 245, 180), outline=(255, 255, 220), width=8)

    # Spooky Castle Silhouette in background
    cx = w // 2
    draw.rectangle([(cx - 180, 220), (cx + 180, int(h * 0.70))], fill=(25, 20, 45))
    draw.polygon([(cx - 190, 220), (cx - 120, 130), (cx - 50, 220)], fill=(25, 20, 45))
    draw.polygon([(cx + 50, 220), (cx + 120, 130), (cx + 190, 220)], fill=(25, 20, 45))
    # Glowing Yellow Windows
    draw.rectangle([(cx - 80, 260), (cx - 40, 310)], fill=(255, 220, 60))
    draw.rectangle([(cx + 40, 260), (cx + 80, 310)], fill=(255, 220, 60))

    # Dark Ground & Mist
    draw.rectangle([(0, int(h * 0.70)), (w, h)], fill=(20, 15, 35))
    for my in range(int(h * 0.66), h, 30):
        draw.ellipse([-50, my, w + 50, my + 60], fill=(80, 75, 110, 40))

# -----------------------------------------------------------------------------
# 0.4 SABZI MANDI / INDIAN VEGETABLE MARKET & STREET FOOD ENVIRONMENT
# -----------------------------------------------------------------------------
def _draw_sabzi_market_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws bustling colorful Indian vegetable bazaar with umbrella canopies, crates of tomatoes, potatoes and chaat stall."""
    # Warm Evening Bazaar Sky
    for y in range(0, int(h * 0.55), 8):
        draw.rectangle([(0, y), (w, y + 8)], fill=(255, int(210 - y * 0.08), 130, 255))
    draw.ellipse([w - 220, 50, w - 100, 170], fill=(255, 230, 40))

    # Colorful Striped Market Canopies / Umbrellas
    canopies = [
        (40, int(h * 0.35), 240, (255, 75, 95)),
        (300, int(h * 0.32), 260, (255, 215, 30)),
        (580, int(h * 0.36), 280, (45, 185, 255)),
        (880, int(h * 0.33), 250, (75, 210, 85)),
        (1150, int(h * 0.35), 260, (255, 140, 40))
    ]
    for cx, cy, cw, ccol in canopies:
        draw.polygon([(cx, cy + 60), (cx + cw // 2, cy), (cx + cw, cy + 60)], fill=ccol, outline=(255, 255, 255), width=4)
        draw.line([(cx + cw // 2, cy + 60), (cx + cw // 2, int(h * 0.70))], fill=(110, 75, 45), width=5)

    # Market Floor
    draw.rectangle([(0, int(h * 0.65)), (w, h)], fill=(200, 160, 115))

    # Wooden Vegetable Crates in Foreground
    crate_x = 120
    for cx in range(120, w - 200, 260):
        draw.rectangle([(cx, int(h * 0.68)), (cx + 180, int(h * 0.85))], fill=(185, 125, 70), outline=(135, 85, 40), width=4)
        draw.line([(cx, int(h * 0.74)), (cx + 180, int(h * 0.74))], fill=(135, 85, 40), width=3)
        draw.line([(cx, int(h * 0.80)), (cx + 180, int(h * 0.80))], fill=(135, 85, 40), width=3)
        # Fresh Vegetables in Crate
        for vx in range(cx + 20, cx + 160, 28):
            v_col = (255, 55, 65) if (cx // 260) % 3 == 0 else ((65, 195, 75) if (cx // 260) % 3 == 1 else (255, 190, 40))
            draw.ellipse([vx - 14, int(h * 0.66), vx + 14, int(h * 0.72)], fill=v_col)

# -----------------------------------------------------------------------------
# 0.5 COLLEGE CAMPUS & CANTEEN ENVIRONMENT
# -----------------------------------------------------------------------------
def _draw_college_campus_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws stylish modern college campus building with brick arches, trees, and student cafeteria tables."""
    for y in range(0, int(h * 0.55), 8):
        draw.rectangle([(0, y), (w, y + 8)], fill=(120 + int(y * 0.1), 195, 255, 255))
    draw.ellipse([80, 50, 200, 170], fill=(255, 230, 40))

    # Grand College Building with Columns
    bx1, bx2 = int(w * 0.12), int(w * 0.88)
    by1, by2 = int(h * 0.25), int(h * 0.65)
    draw.rectangle([(bx1, by1), (bx2, by2)], fill=(230, 110, 80), outline=(175, 65, 45), width=6)
    # White Triangular Pediment
    draw.polygon([(bx1, by1), (w // 2, by1 - 90), (bx2, by1)], fill=(250, 245, 240), outline=(190, 185, 180), width=5)
    # White Columns
    for col_x in range(bx1 + 60, bx2 - 40, 130):
        draw.rectangle([(col_x - 14, by1), (col_x + 14, by2)], fill=(255, 255, 255), outline=(210, 210, 210), width=3)

    # Campus Green Lawn & Pavers
    draw.rectangle([(0, by2), (w, h)], fill=(110, 205, 85))
    draw.polygon([(int(w * 0.40), by2), (int(w * 0.60), by2), (int(w * 0.75), h), (int(w * 0.25), h)], fill=(225, 210, 180))

# -----------------------------------------------------------------------------
# 0.6 CHILDHOOD LIVING ROOM & SIBLINGS ENVIRONMENT
# -----------------------------------------------------------------------------
def _draw_childhood_living_room_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws warm Indian home living room with cozy sofa, family wall clock, television and rugs."""
    # Warm Peach Wall
    for y in range(0, int(h * 0.68), 8):
        draw.rectangle([(0, y), (w, y + 8)], fill=(255, 235 - int(y * 0.04), 205, 255))
    # Wooden Tile Floor
    draw.rectangle([(0, int(h * 0.68)), (w, h)], fill=(215, 160, 105))
    # Colorful Round Rug
    draw.ellipse([int(w * 0.20), int(h * 0.72), int(w * 0.80), int(h * 0.96)], fill=(255, 105, 135), outline=(255, 235, 100), width=8)

    # Big Cozy Sofa in center
    sofa_x1, sofa_y1 = int(w * 0.22), int(h * 0.45)
    sofa_x2, sofa_y2 = int(w * 0.78), int(h * 0.75)
    draw.rounded_rectangle([sofa_x1, sofa_y1, sofa_x2, sofa_y2], radius=40, fill=(75, 170, 230), outline=(45, 120, 180), width=6)
    # Cushions
    draw.ellipse([sofa_x1 + 40, sofa_y1 + 20, sofa_x1 + 160, sofa_y1 + 130], fill=(255, 215, 60))
    draw.ellipse([sofa_x2 - 160, sofa_y1 + 20, sofa_x2 - 40, sofa_y1 + 130], fill=(255, 120, 80))

    # Framed Wall Photos
    for fx in [int(w * 0.15), int(w * 0.85)]:
        draw.rectangle([(fx - 60, 110), (fx + 60, 230)], fill=(255, 255, 255), outline=(150, 95, 45), width=6)
        draw.rectangle([(fx - 45, 125), (fx + 45, 215)], fill=(255, 210, 120))

# -----------------------------------------------------------------------------
# 0.7 SUPERSTITIONS & TRADITIONAL HOME ENVIRONMENT (ANDHWISHVAS)
# -----------------------------------------------------------------------------
def _draw_superstition_home_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws traditional Indian home entrance with auspicious arch, hanging Nimbu-Mirchi, and glowing diya lamps."""
    # Warm Festive Wall
    for y in range(0, int(h * 0.65), 8):
        draw.rectangle([(0, y), (w, y + 8)], fill=(255, 225 - int(y * 0.05), 180, 255))
    draw.rectangle([(0, int(h * 0.65)), (w, h)], fill=(225, 155, 95))

    # Wooden Door Archway in Center
    dw_x1, dw_y1 = int(w * 0.28), 90
    dw_x2, dw_y2 = int(w * 0.72), int(h * 0.65)
    draw.rounded_rectangle([dw_x1, dw_y1, dw_x2, dw_y2], radius=60, fill=(160, 95, 45), outline=(255, 215, 80), width=8)
    draw.rounded_rectangle([dw_x1 + 30, dw_y1 + 30, dw_x2 - 30, dw_y2], radius=40, fill=(110, 60, 25), outline=(255, 255, 255), width=4)

    # Hanging Nimbu-Mirchi (Lemon & 7 Green Chillies) in Door Center
    nm_x, nm_y = w // 2, dw_y1 + 10
    draw.line([(nm_x, nm_y), (nm_x, nm_y + 90)], fill=(40, 40, 40), width=3)
    # 7 Green Chillies
    for ci in range(7):
        cy = nm_y + 15 + ci * 8
        draw.ellipse([nm_x - 5, cy, nm_x + 5, cy + 12], fill=(55, 185, 65))
    # Big Bright Yellow Lemon at Bottom
    draw.ellipse([nm_x - 16, nm_y + 75, nm_x + 16, nm_y + 105], fill=(255, 225, 30), outline=(210, 175, 10), width=2)

# -----------------------------------------------------------------------------
# 1. CLASSROOM / LEARNING / ABCs & 123s
# -----------------------------------------------------------------------------
def _draw_classroom_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws cozy kindergarten classroom with green chalkboard, ABC bunting, desks and sunlit window."""
    # Warm Pastel Yellow Wall
    for y in range(0, int(h * 0.70), 8):
        draw.rectangle([(0, y), (w, y + 8)], fill=(255, 245 - int(y * 0.03), 205 + int(y * 0.04), 255))

    # Polished Wooden Floor
    draw.rectangle([(0, int(h * 0.70)), (w, h)], fill=(225, 170, 110))
    for py in range(int(h * 0.70), h, 35):
        draw.line([(0, py), (w, py)], fill=(195, 140, 85), width=3)
    # White Baseboard
    draw.rectangle([(0, int(h * 0.68)), (w, int(h * 0.70))], fill=(255, 255, 255))

    # Giant Green Chalkboard in center
    cb_x1, cb_y1 = int(w * 0.22), 80
    cb_x2, cb_y2 = int(w * 0.78), int(h * 0.58)
    # Wooden Frame
    draw.rounded_rectangle([cb_x1 - 18, cb_y1 - 18, cb_x2 + 18, cb_y2 + 18], radius=16, fill=(185, 125, 65), outline=(145, 90, 40), width=6)
    # Slate Board
    draw.rounded_rectangle([cb_x1, cb_y1, cb_x2, cb_y2], radius=10, fill=(35, 95, 65))

    # Chalkboard Text & ABC Drawings
    try:
        cb_font_lg = ImageFont.truetype("arialbd.ttf", 68)
        cb_font_sm = ImageFont.truetype("arialbd.ttf", 36)
    except Exception:
        cb_font_lg = ImageFont.load_default()
        cb_font_sm = ImageFont.load_default()

    draw.text(((cb_x1 + cb_x2) // 2, cb_y1 + 75), "A  B  C  D  E", font=cb_font_lg, fill=(255, 255, 255), anchor="mm")
    draw.text(((cb_x1 + cb_x2) // 2, cb_y1 + 175), "1  2  3  4  5", font=cb_font_lg, fill=(255, 235, 100), anchor="mm")
    draw.text(((cb_x1 + cb_x2) // 2, cb_y2 - 60), "Let's Learn & Play Together! 🍎", font=cb_font_sm, fill=(180, 245, 210), anchor="mm")

    # Chalk Tray with Colored Chalks
    draw.rectangle([cb_x1 + 30, cb_y2 + 4, cb_x2 - 30, cb_y2 + 16], fill=(160, 105, 55))
    draw.rectangle([cb_x1 + 60, cb_y2 - 4, cb_x1 + 95, cb_y2 + 4], fill=(255, 255, 255))
    draw.rectangle([cb_x1 + 105, cb_y2 - 4, cb_x1 + 140, cb_y2 + 4], fill=(255, 100, 130))
    draw.rectangle([cb_x1 + 150, cb_y2 - 4, cb_x1 + 185, cb_y2 + 4], fill=(100, 210, 255))

    # Top Bunting Flags across ceiling
    flag_colors = [(255, 75, 110), (255, 215, 0), (60, 195, 255), (100, 230, 85), (255, 145, 40), (190, 100, 245)]
    for idx, fx in enumerate(range(30, w - 30, 115)):
        col = flag_colors[idx % len(flag_colors)]
        draw.polygon([(fx, 0), (fx + 95, 0), (fx + 47, 65)], fill=col)
    draw.line([(0, 0), (w, 0)], fill=(255, 255, 255), width=5)

    # Big Sunny Window on Left
    draw.rounded_rectangle([40, 120, 260, 380], radius=24, fill=(185, 235, 255), outline=(255, 255, 255), width=10)
    draw.line([(150, 120), (150, 380)], fill=(255, 255, 255), width=8)
    draw.line([(40, 250), (260, 250)], fill=(255, 255, 255), width=8)
    draw.ellipse([60, 140, 140, 220], fill=(255, 220, 30))

    # Bookshelf on Right
    bs_x = int(w * 0.82)
    draw.rectangle([bs_x, 150, bs_x + 240, int(h * 0.68)], fill=(225, 160, 95), outline=(175, 110, 50), width=6)
    for sy in [250, 370, 490, 610]:
        draw.line([(bs_x, sy), (bs_x + 240, sy)], fill=(175, 110, 50), width=6)
        for bx in range(bs_x + 20, bs_x + 210, 30):
            b_col = flag_colors[(bx // 30) % len(flag_colors)]
            draw.rectangle([(bx, sy - 85), (bx + 22, sy)], fill=b_col, outline=(255, 255, 255), width=1)

# -----------------------------------------------------------------------------
# 2. BATHROOM / BUBBLES / HYGIENE
# -----------------------------------------------------------------------------
def _draw_bathroom_bubbles_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws bright sparkling bathroom with ceramic tile wall, large bathtub and soap bubbles."""
    for y in range(0, int(h * 0.65), 50):
        for x in range(0, w, 50):
            tile_col = (195 + (x + y) % 30, 235, 255)
            draw.rectangle([(x, y), (x + 48, y + 48)], fill=tile_col, outline=(255, 255, 255), width=2)

    draw.rectangle([(0, int(h * 0.65)), (w, h)], fill=(120, 215, 245))
    draw.ellipse([int(w * 0.25), int(h * 0.76), int(w * 0.75), int(h * 0.96)], fill=(255, 140, 185), outline=(255, 255, 255), width=6)

    tub_x1, tub_y1 = int(w * 0.18), int(h * 0.46)
    tub_x2, tub_y2 = int(w * 0.82), int(h * 0.78)
    draw.rounded_rectangle([tub_x1, tub_y1, tub_x2, tub_y2], radius=60, fill=(255, 255, 255), outline=(190, 220, 235), width=8)
    draw.ellipse([tub_x1 + 35, tub_y1 + 10, tub_x2 - 35, tub_y1 + 110], fill=(70, 190, 255), outline=(255, 255, 255), width=4)

    foam_centers = [
        (tub_x1 + 90, tub_y1 + 25, 45), (tub_x1 + 160, tub_y1 + 15, 55),
        (tub_x1 + 250, tub_y1 + 10, 65), (tub_x1 + 350, tub_y1 + 5, 70),
        (tub_x2 - 320, tub_y1 + 5, 70), (tub_x2 - 220, tub_y1 + 15, 60),
        (tub_x2 - 130, tub_y1 + 20, 50), (tub_x2 - 70, tub_y1 + 35, 40)
    ]
    for fx, fy, fr in foam_centers:
        draw.ellipse([fx - fr, fy - fr, fx + fr, fy + fr], fill=(255, 255, 255, 230), outline=(215, 245, 255), width=3)

    bubble_spots = [
        (180, 180, 48), (320, 120, 36), (w - 280, 160, 55),
        (w - 150, 260, 42), (w // 2, 140, 60), (450, 260, 32)
    ]
    for bx, by, br in bubble_spots:
        draw.ellipse([bx - br, by - br, bx + br, by + br], fill=(255, 255, 255, 90), outline=(255, 255, 255, 200), width=4)
        draw.ellipse([bx - br // 2, by - br // 2, bx - br // 4, by - br // 4], fill=(255, 255, 255, 240))

# -----------------------------------------------------------------------------
# 3. BEDTIME / NIGHT / STARLIGHT / MOON
# -----------------------------------------------------------------------------
def _draw_bedtime_starlight_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws peaceful nighttime bedroom with glowing crescent moon, stars, and cozy window."""
    for y in range(0, int(h * 0.72), 8):
        ratio = y / (h * 0.72)
        r = int(20 + ratio * 25)
        g = int(25 + ratio * 35)
        b = int(70 + ratio * 60)
        draw.rectangle([(0, y), (w, y + 8)], fill=(r, g, b, 255))

    draw.rectangle([(0, int(h * 0.72)), (w, h)], fill=(75, 55, 95))
    draw.ellipse([int(w * 0.15), int(h * 0.78), int(w * 0.85), int(h * 0.98)], fill=(115, 85, 145), outline=(155, 120, 185), width=5)

    win_cx, win_cy = w // 2, 280
    win_w, win_h = 440, 340
    draw.rounded_rectangle([win_cx - win_w // 2, win_cy - win_h // 2, win_cx + win_w // 2, win_cy + win_h // 2], radius=120, fill=(10, 15, 45), outline=(255, 235, 180), width=10)

    moon_x, moon_y = win_cx + 80, win_cy - 60
    draw.ellipse([moon_x - 70, moon_y - 70, moon_x + 70, moon_y + 70], fill=(255, 235, 60))
    draw.ellipse([moon_x - 40, moon_y - 85, moon_x + 80, moon_y + 55], fill=(10, 15, 45))

    stars = [
        (win_cx - 130, win_cy - 90, 16), (win_cx - 70, win_cy - 120, 20),
        (win_cx - 140, win_cy + 20, 14), (win_cx - 40, win_cy - 20, 18),
        (win_cx + 120, win_cy + 50, 15), (120, 100, 24), (220, 160, 18),
        (w - 180, 120, 22), (w - 100, 220, 16), (w - 240, 260, 20)
    ]
    for sx, sy, sr in stars:
        draw.polygon([
            (sx, sy - sr), (sx + sr // 3, sy - sr // 3),
            (sx + sr, sy), (sx + sr // 3, sy + sr // 3),
            (sx, sy + sr), (sx - sr // 3, sy + sr // 3),
            (sx - sr, sy), (sx - sr // 3, sy - sr // 3)
        ], fill=(255, 245, 140))

    draw.arc([-50, -40, w + 50, 160], 0, 180, fill=(255, 255, 255, 150), width=3)
    for idx, lx in enumerate(range(80, w - 60, 90)):
        ly = int(45 + math.sin(idx * 0.8) * 20)
        col = [(255, 235, 100), (255, 140, 180), (120, 220, 255), (140, 255, 140)][idx % 4]
        draw.ellipse([lx - 12, ly - 12, lx + 12, ly + 12], fill=col)

# -----------------------------------------------------------------------------
# 4. UNDERWATER / OCEAN / BEACH
# -----------------------------------------------------------------------------
def _draw_underwater_ocean_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws vibrant deep turquoise ocean with light rays, coral reefs and seaweed."""
    for y in range(0, int(h * 0.78), 8):
        ratio = y / (h * 0.78)
        r = int(25 + ratio * 30)
        g = int(140 + ratio * 40)
        b = int(235 - ratio * 40)
        draw.rectangle([(0, y), (w, y + 8)], fill=(r, g, b, 255))

    draw.rectangle([(0, int(h * 0.78)), (w, h)], fill=(245, 215, 130))
    draw.ellipse([-100, int(h * 0.74), w + 100, int(h * 0.88)], fill=(235, 200, 110))

    for rx in range(120, w, 320):
        draw.polygon([(rx, 0), (rx + 80, 0), (rx + 220, int(h * 0.75)), (rx + 100, int(h * 0.75))], fill=(255, 255, 255, 28))

    draw.ellipse([20, int(h * 0.62), 160, int(h * 0.82)], fill=(255, 110, 130))
    draw.ellipse([100, int(h * 0.58), 240, int(h * 0.80)], fill=(255, 160, 60))
    draw.ellipse([180, int(h * 0.66), 280, int(h * 0.82)], fill=(255, 95, 150))

    draw.ellipse([w - 280, int(h * 0.62), w - 160, int(h * 0.82)], fill=(255, 140, 50))
    draw.ellipse([w - 200, int(h * 0.56), w - 80, int(h * 0.80)], fill=(255, 105, 140))
    draw.ellipse([w - 120, int(h * 0.64), w - 20, int(h * 0.82)], fill=(255, 195, 45))

    for sw_x in [320, 360, w - 380, w - 340]:
        draw.arc([sw_x - 30, int(h * 0.52), sw_x + 30, int(h * 0.80)], 270, 90, fill=(35, 175, 75), width=14)
        draw.arc([sw_x - 30, int(h * 0.40), sw_x + 30, int(h * 0.65)], 90, 270, fill=(45, 195, 85), width=14)

    for i in range(12):
        bx = (i * 165 + 75) % w
        by = int(h * 0.72 - ((i * 75) % int(h * 0.65)))
        br = 12 + (i % 4) * 6
        draw.ellipse([bx - br, by - br, bx + br, by + br], fill=(255, 255, 255, 110), outline=(255, 255, 255, 220), width=3)

# -----------------------------------------------------------------------------
# 5. CITY ROAD / VEHICLES / TOWN
# -----------------------------------------------------------------------------
def _draw_city_and_road_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws sunny modern cartoon city with skyscrapers, zebra crosswalk, and wide roadway."""
    for y in range(0, int(h * 0.55), 8):
        draw.rectangle([(0, y), (w, y + 8)], fill=(120 + int(y * 0.15), 205 + int(y * 0.08), 255, 255))

    draw.ellipse([w - 220, 60, w - 80, 200], fill=(255, 220, 30), outline=(255, 245, 140), width=8)

    building_data = [
        (40, 320, 180, (255, 135, 150)), (240, 240, 200, (135, 215, 255)),
        (460, 280, 190, (255, 225, 110)), (670, 200, 220, (170, 140, 255)),
        (910, 260, 200, (120, 230, 150)), (1130, 220, 210, (255, 160, 90)),
        (1360, 300, 190, (140, 210, 255)), (1570, 240, 220, (255, 130, 180)),
        (1810, 290, 180, (255, 215, 80))
    ]
    for bx, by, bw, bcol in building_data:
        draw.rectangle([(bx, by), (bx + bw, int(h * 0.58))], fill=bcol, outline=(255, 255, 255), width=4)
        for wy in range(by + 30, int(h * 0.55), 45):
            for wx in range(bx + 20, bx + bw - 20, 35):
                draw.rectangle([(wx, wy), (wx + 20, wy + 25)], fill=(255, 255, 255, 220))

    draw.rectangle([(0, int(h * 0.55)), (w, int(h * 0.62))], fill=(110, 215, 85))
    draw.rectangle([(0, int(h * 0.60)), (w, int(h * 0.63))], fill=(210, 215, 220))

    road_y1, road_y2 = int(h * 0.63), h
    draw.rectangle([(0, road_y1), (w, road_y2)], fill=(75, 80, 90))

    for zx in range(120, 420, 60):
        draw.polygon([(zx, road_y1 + 10), (zx + 35, road_y1 + 10), (zx + 15, road_y2 - 20), (zx - 20, road_y2 - 20)], fill=(255, 255, 255))

    mid_road_y = int((road_y1 + road_y2) / 2)
    for dx in range(460, w, 120):
        draw.rectangle([(dx, mid_road_y - 8), (dx + 65, mid_road_y + 8)], fill=(255, 220, 30))

# -----------------------------------------------------------------------------
# 6. KITCHEN / FOOD / PICNIC
# -----------------------------------------------------------------------------
def _draw_kitchen_food_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws cheerful kitchen with checkered tiles, fruit basket and cooking counters."""
    for y in range(0, int(h * 0.65), 8):
        draw.rectangle([(0, y), (w, y + 8)], fill=(255, 235 - int(y * 0.04), 215, 255))

    for y in range(int(h * 0.65), h, 40):
        for x in range(0, w, 40):
            col = (255, 255, 255) if ((x + y) // 40) % 2 == 0 else (255, 120, 140)
            draw.rectangle([(x, y), (x + 40, y + 40)], fill=col)

    draw.rectangle([(0, int(h * 0.48)), (w, int(h * 0.66))], fill=(130, 215, 240), outline=(90, 175, 200), width=6)
    draw.rectangle([(0, int(h * 0.46)), (w, int(h * 0.50))], fill=(255, 255, 255))

    win_x, win_y = w // 2, 170
    draw.rounded_rectangle([win_x - 180, win_y - 120, win_x + 180, win_y + 120], radius=24, fill=(180, 235, 255), outline=(255, 255, 255), width=8)
    draw.line([(win_x, win_y - 120), (win_x, win_y + 120)], fill=(255, 255, 255), width=6)
    draw.line([(win_x - 180, win_y), (win_x + 180, win_y)], fill=(255, 255, 255), width=6)

    fb_x, fb_y = int(w * 0.22), int(h * 0.44)
    draw.ellipse([fb_x - 100, fb_y - 30, fb_x + 100, fb_y + 40], fill=(215, 150, 90), outline=(165, 105, 50), width=5)
    draw.ellipse([fb_x - 60, fb_y - 65, fb_x - 10, fb_y - 15], fill=(255, 55, 65), outline=(190, 20, 30), width=3)
    draw.ellipse([fb_x, fb_y - 70, fb_x + 50, fb_y - 20], fill=(255, 55, 65), outline=(190, 20, 30), width=3)
    draw.ellipse([fb_x - 20, fb_y - 50, fb_x + 25, fb_y - 5], fill=(255, 160, 30), outline=(210, 120, 10), width=3)

# -----------------------------------------------------------------------------
# 7. JUNGLE / DINOSAUR
# -----------------------------------------------------------------------------
def _draw_jungle_dinosaur_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws lush tropical dinosaur jungle with giant palm leaves and distant volcano."""
    for y in range(0, int(h * 0.55), 8):
        ratio = y / (h * 0.55)
        draw.rectangle([(0, y), (w, y + 8)], fill=(255, int(180 + ratio * 40), int(100 + ratio * 60), 255))

    vc_x = int(w * 0.75)
    draw.polygon([(vc_x - 240, int(h * 0.55)), (vc_x, 150), (vc_x + 240, int(h * 0.55))], fill=(145, 95, 80), outline=(115, 65, 55), width=5)
    draw.ellipse([vc_x - 35, 140, vc_x + 35, 165], fill=(255, 100, 40))
    draw.ellipse([vc_x - 20, 80, vc_x + 40, 130], fill=(255, 255, 255, 180))

    draw.ellipse([-200, int(h * 0.45), int(w * 0.70), int(h * 1.1)], fill=(70, 175, 60))
    draw.ellipse([int(w * 0.30), int(h * 0.48), w + 200, int(h * 1.1)], fill=(95, 205, 80))
    draw.rectangle([(0, int(h * 0.65)), (w, h)], fill=(80, 190, 70))

    for lx in range(40, 320, 70):
        draw.arc([lx - 120, -50, lx + 120, 260], 30, 150, fill=(35, 150, 50), width=18)
    for rx in range(w - 320, w - 40, 70):
        draw.arc([rx - 120, -50, rx + 120, 260], 30, 150, fill=(35, 150, 50), width=18)

# -----------------------------------------------------------------------------
# 8. DOCTOR / CLINIC
# -----------------------------------------------------------------------------
def _draw_doctor_clinic_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    """Draws clean friendly medical clinic with height chart and first-aid badges."""
    for y in range(0, int(h * 0.68), 8):
        draw.rectangle([(0, y), (w, y + 8)], fill=(225, 250 - int(y * 0.03), 240, 255))

    draw.rectangle([(0, int(h * 0.68)), (w, h)], fill=(150, 215, 235))
    draw.rectangle([(0, int(h * 0.66)), (w, int(h * 0.68))], fill=(255, 255, 255))

    cx, cy = w // 2, 170
    draw.ellipse([cx - 90, cy - 90, cx + 90, cy + 90], fill=(255, 255, 255), outline=(235, 75, 95), width=6)
    draw.rectangle([cx - 18, cy - 55, cx + 18, cy + 55], fill=(235, 75, 95))
    draw.rectangle([cx - 55, cy - 18, cx + 55, cy + 18], fill=(235, 75, 95))

    hc_x = 120
    draw.rectangle([hc_x, 80, hc_x + 80, int(h * 0.66)], fill=(255, 255, 255), outline=(200, 200, 200), width=4)
    hc_colors = [(255, 75, 95), (255, 180, 40), (255, 230, 40), (80, 210, 95), (60, 180, 255)]
    for i, col in enumerate(hc_colors):
        draw.rectangle([hc_x + 5, 100 + i * 85, hc_x + 75, 170 + i * 85], fill=col)

# -----------------------------------------------------------------------------
# 9-14. OTHER CLASSIC ENVIRONMENTS
# -----------------------------------------------------------------------------
def _draw_playroom_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    for y in range(0, int(h * 0.70), 8):
        ratio = y / (h * 0.70)
        draw.rectangle([(0, y), (w, y + 8)], fill=(int(255 - ratio * 15), int(245 - ratio * 20), int(210 + ratio * 35), 255))
    draw.rectangle([(0, int(h * 0.70)), (w, h)], fill=(110, 195, 240))
    draw.rectangle([(0, int(h * 0.68)), (w, int(h * 0.70))], fill=(255, 255, 255))

    win_x, win_y = int(w * 0.75), 140
    draw.rounded_rectangle([win_x - 140, win_y - 100, win_x + 140, win_y + 140], radius=30, fill=(180, 235, 255), outline=(255, 255, 255), width=10)
    draw.line([(win_x, win_y - 100), (win_x, win_y + 140)], fill=(255, 255, 255), width=8)
    draw.line([(win_x - 140, win_y + 20), (win_x + 140, win_y + 20)], fill=(255, 255, 255), width=8)
    draw.ellipse([win_x + 30, win_y - 70, win_x + 110, win_y + 10], fill=(255, 225, 40))

    shelf_x = int(w * 0.15)
    draw.rectangle([shelf_x - 120, int(h * 0.40), shelf_x + 120, int(h * 0.68)], fill=(245, 185, 120), outline=(210, 140, 70), width=6)
    draw.rounded_rectangle([shelf_x - 90, int(h * 0.44), shelf_x - 30, int(h * 0.52)], radius=10, fill=(255, 90, 110))
    draw.rounded_rectangle([shelf_x - 20, int(h * 0.44), shelf_x + 40, int(h * 0.52)], radius=10, fill=(255, 215, 30))
    draw.rounded_rectangle([shelf_x + 50, int(h * 0.44), shelf_x + 100, int(h * 0.52)], radius=10, fill=(70, 200, 120))
    draw.ellipse([shelf_x - 60, int(h * 0.56), shelf_x + 10, int(h * 0.65)], fill=(255, 140, 50), outline=(255, 255, 255), width=4)

def _draw_farm_meadow_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    for y in range(0, int(h * 0.60), 8):
        ratio = y / (h * 0.60)
        draw.rectangle([(0, y), (w, y + 8)], fill=(int(115 + ratio * 60), int(195 + ratio * 45), 255, 255))
    sun_x, sun_y = w - 220, 160
    draw.ellipse([sun_x - 80, sun_y - 80, sun_x + 80, sun_y + 80], fill=(255, 220, 30), outline=(255, 245, 140), width=8)
    draw.ellipse([-250, int(h * 0.42), int(w * 0.75), int(h * 1.15)], fill=(90, 205, 75))
    draw.ellipse([int(w * 0.35), int(h * 0.38), int(w * 1.35), int(h * 1.20)], fill=(125, 225, 95))
    draw.rectangle([(0, int(h * 0.65)), (w, h)], fill=(105, 215, 80))

    bx, by = int(w * 0.14), int(h * 0.35)
    draw.rectangle([bx, by, bx + 220, by + 160], fill=(225, 45, 45), outline=(170, 20, 20), width=5)
    draw.polygon([(bx - 20, by), (bx + 110, by - 80), (bx + 240, by)], fill=(250, 250, 250), outline=(200, 200, 200), width=5)
    draw.rectangle([bx + 75, by + 50, bx + 145, by + 160], fill=(255, 255, 255))
    draw.line([(bx + 75, by + 50), (bx + 145, by + 160)], fill=(200, 30, 30), width=4)
    draw.line([(bx + 145, by + 50), (bx + 75, by + 160)], fill=(200, 30, 30), width=4)

    for fx in range(int(w * 0.45), int(w * 0.95), 85):
        draw.rectangle([(fx, int(h * 0.58)), (fx + 18, int(h * 0.68))], fill=(255, 255, 255), outline=(210, 210, 210), width=2)
    draw.rectangle([(int(w * 0.45), int(h * 0.60)), (int(w * 0.95), int(h * 0.62))], fill=(255, 255, 255))
    draw.rectangle([(int(w * 0.45), int(h * 0.65)), (int(w * 0.95), int(h * 0.67))], fill=(255, 255, 255))

def _draw_pond_and_mud_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    for y in range(0, int(h * 0.55), 8):
        draw.rectangle([(0, y), (w, y + 8)], fill=(130, 210, 255, 255))
    draw.rectangle([(0, int(h * 0.50)), (w, h)], fill=(105, 215, 85))

    mud_x, mud_y = int(w * 0.28), int(h * 0.72)
    draw.ellipse([mud_x - 260, mud_y - 110, mud_x + 260, mud_y + 110], fill=(145, 95, 60), outline=(115, 65, 35), width=7)

    p_x, p_y = int(w * 0.74), int(h * 0.72)
    draw.ellipse([p_x - 320, p_y - 130, p_x + 320, p_y + 130], fill=(70, 185, 245), outline=(255, 255, 255), width=6)
    draw.ellipse([p_x - 140, p_y - 30, p_x - 70, p_y + 15], fill=(55, 175, 75))
    draw.ellipse([p_x + 80, p_y + 10, p_x + 150, p_y + 55], fill=(55, 175, 75))
    draw.ellipse([p_x + 105, p_y + 15, p_x + 125, p_y + 35], fill=(255, 120, 180))

def _draw_tractor_road_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    for y in range(0, int(h * 0.52), 8):
        draw.rectangle([(0, y), (w, y + 8)], fill=(115, 200, 255, 255))
    draw.rectangle([(0, int(h * 0.48)), (w, h)], fill=(100, 210, 80))

    road_y1, road_y2 = int(h * 0.64), int(h * 0.95)
    draw.rectangle([(0, road_y1), (w, road_y2)], fill=(80, 85, 95))
    draw.line([(0, road_y1), (w, road_y1)], fill=(255, 255, 255), width=5)
    draw.line([(0, road_y2), (w, road_y2)], fill=(255, 255, 255), width=5)
    for dx in range(0, w, 110):
        draw.rectangle([(dx, int((road_y1 + road_y2) / 2 - 6)), (dx + 55, int((road_y1 + road_y2) / 2 + 6))], fill=(255, 220, 30))

def _draw_outdoor_stage_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    for y in range(0, int(h * 0.55), 8):
        ratio = y / (h * 0.55)
        draw.rectangle([(0, y), (w, y + 8)], fill=(int(255 - ratio * 40), int(150 + ratio * 60), int(220), 255))
    colors = [(255, 60, 100), (255, 220, 0), (60, 200, 255), (120, 235, 80), (255, 140, 40)]
    for idx, fx in enumerate(range(60, w - 60, 100)):
        col = colors[idx % len(colors)]
        draw.polygon([(fx, 90), (fx + 80, 90), (fx + 40, 160)], fill=col)
    draw.line([(0, 90), (w, 90)], fill=(255, 255, 255), width=4)

    stage_y = int(h * 0.62)
    draw.rectangle([(0, stage_y), (w, h)], fill=(215, 155, 95))
    for py in range(stage_y, h, 40):
        draw.line([(0, py), (w, py)], fill=(175, 115, 65), width=3)

def _draw_rainbow_sunset_environment(draw: ImageDraw.ImageDraw, w: int, h: int):
    for y in range(0, h, 8):
        ratio = y / h
        draw.rectangle([(0, y), (w, y + 8)], fill=(int(255 - ratio * 30), int(140 + ratio * 80), int(200 - ratio * 80), 255))

    rb_cx, rb_cy = w // 2, h + 200
    rb_colors = [(255, 75, 95), (255, 160, 40), (255, 230, 40), (75, 215, 95), (60, 185, 255), (170, 90, 235)]
    for i, col in enumerate(rb_colors):
        radius = 750 - i * 26
        draw.arc([rb_cx - radius, rb_cy - radius, rb_cx + radius, rb_cy + radius], 180, 360, fill=col, width=28)

    draw.ellipse([-200, int(h * 0.72), w + 200, int(h * 1.3)], fill=(90, 195, 75))

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    storyboard = [
        {"scene_name": "classroom_chalkboard", "theme_category": "classroom", "visual_prompt": "Classroom chalkboard with ABCs"},
        {"scene_name": "yellow_bus_moving", "theme_category": "vehicles", "visual_prompt": "Yellow school bus moving down road"},
        {"scene_name": "bubble_tub_splash", "theme_category": "bath", "visual_prompt": "Bubbly bathtub with rubber duck"},
        {"scene_name": "starlight_twinkle", "theme_category": "bedtime", "visual_prompt": "Night sky with moon and stars"},
        {"scene_name": "baby_shark_dance", "theme_category": "ocean", "visual_prompt": "Deep blue ocean coral reef"},
        {"scene_name": "rainbow_celebration", "theme_category": "party", "visual_prompt": "Rainbow sunset celebration"}
    ]
    paths = generate_scene_artworks(storyboard)
    print(f"Generated {len(paths)} scenes successfully.")
