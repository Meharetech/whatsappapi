import os
import sys
import json
import logging
from pathlib import Path
from typing import Dict, Any, Tuple, Optional

# Ensure UTF-8 output on Windows
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

import config

logger = logging.getLogger("cocolemon_pipeline")

def get_authenticated_youtube_service():
    """
    Authenticates and returns the Google YouTube Data API v3 service client.
    Handles token caching in token.json and initial OAuth2 flow via client_secrets.json.
    """
    try:
        from googleapiclient.discovery import build
        from google_auth_oauthlib.flow import InstalledAppFlow
        from google.auth.transport.requests import Request
        from google.oauth2.credentials import Credentials
    except ImportError as e:
        logger.error(f"Missing Google API libraries: {e}")
        return None

    creds = None
    # 1. Check for cached token.json
    if config.YOUTUBE_TOKEN_FILE.exists():
        try:
            creds = Credentials.from_authorized_user_file(str(config.YOUTUBE_TOKEN_FILE), config.YOUTUBE_SCOPES)
            if creds and creds.valid:
                logger.info("Loaded valid cached credentials from token.json")
                return build("youtube", "v3", credentials=creds)
        except Exception as e:
            logger.warning(f"Could not load cached token.json: {e}")
            creds = None

    # 2. Refresh or authenticate
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            logger.info("Refreshing expired YouTube OAuth credentials...")
            try:
                creds.refresh(Request())
                with open(config.YOUTUBE_TOKEN_FILE, "w", encoding="utf-8") as token:
                    token.write(creds.to_json())
                return build("youtube", "v3", credentials=creds)
            except Exception as e:
                logger.warning(f"Token refresh failed: {e}. Re-authenticating...")
                creds = None

        if not creds:
            if not config.CLIENT_SECRETS_FILE.exists():
                logger.warning(f"client_secrets.json not found at {config.CLIENT_SECRETS_FILE}")
                return None

            print("\n" + "=" * 70)
            print("         GOOGLE YOUTUBE 1-TIME AUTHORIZATION")
            print("=" * 70)
            print("Opening your browser to authorize your YouTube channel...")
            print("If the browser does not open automatically, check the link below.")
            print("=" * 70 + "\n")

            flow = InstalledAppFlow.from_client_secrets_file(
                str(config.CLIENT_SECRETS_FILE),
                config.YOUTUBE_SCOPES
            )

            # Try fixed port 8080 (standard for Web clients) then fallback to port 0
            try:
                creds = flow.run_local_server(
                    host="localhost",
                    port=8080,
                    open_browser=True,
                    prompt="consent",
                    authorization_prompt_message="Please visit this URL in your browser to authorize YouTube:\n{url}"
                )
            except Exception as port_err:
                logger.warning(f"Port 8080 attempt: {port_err}. Retrying with dynamic port...")
                creds = flow.run_local_server(
                    port=0,
                    open_browser=True,
                    prompt="consent",
                    authorization_prompt_message="Please visit this URL in your browser to authorize YouTube:\n{url}"
                )

        # Save credentials for subsequent autonomous runs
        try:
            with open(config.YOUTUBE_TOKEN_FILE, "w", encoding="utf-8") as token:
                token.write(creds.to_json())
            logger.info(f"-> Saved authenticated session token to: {config.YOUTUBE_TOKEN_FILE}")
            print("\n[+] YouTube authorization successful! Token saved to token.json.\n")
        except Exception as save_err:
            logger.warning(f"Could not save token.json: {save_err}")

    return build("youtube", "v3", credentials=creds)

def upload_video_to_youtube(
    video_path: Path = config.VIDEO_OUTPUT_FILE,
    thumbnail_path: Optional[Path] = config.THUMBNAIL_OUTPUT_FILE,
    title: str = "Fun Nursery Rhymes for Kids | Cocolemon",
    description: str = "",
    tags: list = None,
    privacy_status: str = config.DEFAULT_YOUTUBE_PRIVACY,
    dry_run: bool = False
) -> Tuple[bool, Dict[str, Any]]:
    """
    Uploads a video to YouTube with custom thumbnail, SEO tags, and Made For Kids declaration.
    """
    if dry_run:
        logger.info("[Dry Run] Simulating YouTube video upload...")
        video_id = "mock_cocolemon_video_id"
        return True, {
            "status": "mock_success",
            "video_id": video_id,
            "video_url": f"https://youtu.be/{video_id}",
            "privacy_status": privacy_status,
            "made_for_kids": True,
            "note": "Uploaded in dry-run simulation mode."
        }

    if not config.CLIENT_SECRETS_FILE.exists() and not config.YOUTUBE_TOKEN_FILE.exists():
        logger.warning("No client_secrets.json or token.json found. Skipping live upload.")
        return False, {
            "status": "credentials_needed",
            "error": "client_secrets.json not found in project directory."
        }

    if not video_path.exists():
        logger.error(f"Video file not found at: {video_path}")
        return False, {"status": "error", "error": f"Video file not found: {video_path}"}

    youtube = get_authenticated_youtube_service()
    if not youtube:
        logger.error("Could not obtain YouTube API client.")
        return False, {"status": "auth_error", "error": "Failed to authenticate YouTube service."}

    from googleapiclient.http import MediaFileUpload

    # Default tags for kids nursery rhymes
    default_tags = [
        "Cocolemon", "nursery rhymes", "kids songs", "baby songs",
        "toddler songs", "children songs", "sing along", "preschool learning"
    ]
    if tags:
        default_tags = list(set(default_tags + tags))

    # Formulate rich YouTube description
    full_description = description.strip() if description else ""
    if not full_description:
        full_description = (
            f"🍉 Welcome to Cocolemon - Happy Songs & Nursery Rhymes for Toddlers!\n\n"
            f"🎵 Enjoy this 2-minute toddler adventure full of singing, dancing, and cheerful sound effects!\n\n"
            f"🔔 Subscribe to Cocolemon for weekly joyful videos and learning fun!\n\n"
            f"#Cocolemon #NurseryRhymes #KidsSongs #ToddlerSongs #SingAlong"
        )

    # Clean title for YouTube character limit (max 100 chars)
    clean_title = title.strip()
    if len(clean_title) > 95:
        clean_title = clean_title[:92] + "..."

    body = {
        "snippet": {
            "title": clean_title,
            "description": full_description,
            "tags": default_tags,
            "categoryId": config.DEFAULT_YOUTUBE_CATEGORY_ID,
            "defaultLanguage": "en"
        },
        "status": {
            "privacyStatus": privacy_status,
            "selfDeclaredMadeForKids": True # COPPA Compliance for Kids YouTube content
        }
    }

    try:
        logger.info(f"Starting video upload to YouTube: '{clean_title}' (Privacy: {privacy_status})...")
        media = MediaFileUpload(str(video_path), chunksize=-1, resumable=True, mimetype="video/mp4")

        insert_request = youtube.videos().insert(
            part=",".join(body.keys()),
            body=body,
            media_body=media
        )

        response = None
        while response is None:
            status, response = insert_request.next_chunk()
            if status:
                progress = int(status.progress() * 100)
                logger.info(f"Upload progress: {progress}%")

        video_id = response.get("id")
        video_url = f"https://youtu.be/{video_id}"
        logger.info(f"-> Video successfully uploaded to YouTube! Video ID: {video_id}")
        logger.info(f"-> YouTube Video URL: {video_url}")

        # Set Custom Thumbnail if available
        if thumbnail_path and thumbnail_path.exists():
            try:
                logger.info("Uploading custom video thumbnail...")
                youtube.thumbnails().set(
                    videoId=video_id,
                    media_body=MediaFileUpload(str(thumbnail_path), mimetype="image/png")
                ).execute()
                logger.info("-> Custom thumbnail uploaded successfully!")
            except Exception as thumb_err:
                logger.warning(f"Could not upload thumbnail: {thumb_err}")

        return True, {
            "status": "success",
            "video_id": video_id,
            "video_url": video_url,
            "privacy_status": privacy_status,
            "title": clean_title,
            "made_for_kids": True
        }

    except Exception as e:
        logger.error(f"Error during YouTube upload: {e}")
        return False, {"status": "error", "error": str(e)}

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print("Testing YouTube Authentication Service...")
    service = get_authenticated_youtube_service()
    if service:
        print("\n[SUCCESS] Successfully authenticated YouTube API service!")
    else:
        print("\n[PENDING] Authentication pending or error.")
