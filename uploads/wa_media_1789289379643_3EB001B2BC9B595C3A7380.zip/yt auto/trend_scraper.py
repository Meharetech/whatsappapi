import sys
import random
import logging
import requests
import feedparser
from typing import Dict, Any, List, Tuple
import config

# Ensure UTF-8 output support in Windows terminals
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

logger = logging.getLogger("cocolemon_pipeline")

def get_latest_channel_trend(force_fallback: bool = False) -> Dict[str, Any]:
    """
    Scrapes the target YouTube channel (@NOTYOURTYPE) to extract the latest video release:
    - Tier 1: Direct Channel Videos Page HTML Scraping (ytInitialData lockupViewModel & videoRenderer)
    - Tier 2: YouTube Channel RSS Feed XML Ingestion
    - Tier 3: Curated Default Topic Fallback
    """
    if force_fallback:
        logger.info("force_fallback flag is set. Using curated default theme.")
        return _get_fallback_trend("Force fallback requested by user or flag.")

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9"
    }

    # --- TIER 1: Direct Channel Videos Scraping ---
    channel_videos_url = f"https://www.youtube.com/{config.TARGET_CHANNEL_HANDLE}/videos"
    try:
        logger.info(f"Fetching latest releases from {config.TARGET_CHANNEL_NAME} ({channel_videos_url})...")
        resp = requests.get(channel_videos_url, headers=headers, timeout=config.REQUEST_TIMEOUT_SECONDS)
        if resp.status_code == 200:
            import json, re
            match = re.search(r'ytInitialData\s*=\s*({.+?});</script>', resp.text)
            if not match:
                match = re.search(r'ytInitialData\s*=\s*({.+?});', resp.text)

            if match:
                data = json.loads(match.group(1))
                scraped_videos = []

                def _extract_videos(obj):
                    if isinstance(obj, dict):
                        if "lockupViewModel" in obj:
                            lum = obj["lockupViewModel"]
                            meta = lum.get("metadata", {}).get("lockupMetadataViewModel", {})
                            title = meta.get("title", {}).get("content", "").strip()
                            vid_id = lum.get("contentId", "") or lum.get("rendererContext", {}).get("commandContext", {}).get("onTap", {}).get("innertubeCommand", {}).get("watchEndpoint", {}).get("videoId", "")
                            if title and vid_id:
                                scraped_videos.append((title, vid_id))
                        elif "videoRenderer" in obj:
                            vr = obj["videoRenderer"]
                            title = vr.get("title", {}).get("runs", [{}])[0].get("text", "").strip()
                            vid_id = vr.get("videoId", "")
                            if title and vid_id:
                                scraped_videos.append((title, vid_id))
                        for v in obj.values():
                            _extract_videos(v)
                    elif isinstance(obj, list):
                        for item in obj:
                            _extract_videos(item)

                _extract_videos(data)

                if scraped_videos:
                    latest_title, latest_id = scraped_videos[0]
                    video_link = f"https://www.youtube.com/watch?v={latest_id}"
                    logger.info(f"Successfully scraped latest {config.TARGET_CHANNEL_NAME} video: '{latest_title}' ({video_link})")

                    # Extract additional tags and description from watch page if possible
                    tags, description = _fetch_watch_page_details(latest_id, headers)

                    # Extract dynamic transcripts, dialogues, and chronological scene cues
                    from transcript_extractor import extract_video_narrative_context
                    narrative_ctx = extract_video_narrative_context(
                        video_id=latest_id,
                        title=latest_title,
                        raw_summary=description,
                        tags=tags
                    )

                    return {
                        "status": "live_channel_scrape",
                        "title": latest_title,
                        "video_id": latest_id,
                        "theme": _infer_theme_from_title(latest_title),
                        "video_url": video_link,
                        "tags": tags,
                        "description": description,
                        "keywords": tags or _extract_keywords_from_title(latest_title),
                        "narrative_context": narrative_ctx,
                        "published_at": "Latest Video Release",
                        "channel_title": config.TARGET_CHANNEL_NAME,
                        "raw_summary": narrative_ctx.get("full_transcript_summary", f"Latest release from {config.TARGET_CHANNEL_HANDLE}: {latest_title}"),
                        "source": f"Live YouTube Channel Page ({config.TARGET_CHANNEL_HANDLE})"
                    }
    except Exception as e:
        logger.warning(f"Direct channel page scrape failed ({e}). Attempting RSS fallback...")

    # --- TIER 2: YouTube RSS Feed XML ---
    try:
        logger.info(f"Fetching RSS feed from: {config.YOUTUBE_RSS_URL}")
        response = requests.get(config.YOUTUBE_RSS_URL, headers=headers, timeout=config.REQUEST_TIMEOUT_SECONDS)
        if response.status_code == 200:
            feed = feedparser.parse(response.content)
            if feed.entries and len(feed.entries) > 0:
                latest_entry = feed.entries[0]
                video_title = latest_entry.get("title", "").strip()
                video_link = latest_entry.get("link", "")
                published_at = latest_entry.get("published", "")
                author = latest_entry.get("author", config.TARGET_CHANNEL_NAME)
                summary = latest_entry.get("summary", "")

                logger.info(f"Successfully scraped latest {config.TARGET_CHANNEL_NAME} release via RSS: '{video_title}'")
                return {
                    "status": "live_rss",
                    "title": video_title,
                    "theme": _infer_theme_from_title(video_title),
                    "video_url": video_link,
                    "keywords": _extract_keywords_from_title(video_title),
                    "published_at": published_at,
                    "channel_title": author,
                    "raw_summary": summary[:300] + ("..." if len(summary) > 300 else ""),
                    "source": f"Official {config.TARGET_CHANNEL_NAME} RSS ({config.TARGET_CHANNEL_ID})"
                }
    except Exception as e:
        logger.warning(f"RSS fallback failed ({e}). Falling back to curated bank.")

    # --- TIER 3: Curated Bank Fallback ---
    return _get_fallback_trend("All live scraping channels unavailable")

def _fetch_watch_page_details(video_id: str, headers: dict) -> Tuple[List[str], str]:
    """Fetches video tags and description from watch page."""
    import re
    tags = []
    desc = ""
    try:
        watch_url = f"https://www.youtube.com/watch?v={video_id}"
        resp = requests.get(watch_url, headers=headers, timeout=config.REQUEST_TIMEOUT_SECONDS)
        if resp.status_code == 200:
            raw_tags = re.findall(r'<meta\s+property="og:video:tag"\s+content="([^"]+)"', resp.text)
            tags = [t.strip() for t in raw_tags if t.strip() and t.lower() != "not your type"]
            m_desc = re.search(r'<meta\s+name="description"\s+content="([^"]+)"', resp.text)
            if m_desc:
                desc = m_desc.group(1).strip()
    except Exception:
        pass
    return tags, desc

def _extract_keywords_from_title(title: str) -> List[str]:
    """Splits compound title by separators like comma, ampersand, pipe, ft."""
    import re
    cleaned = re.split(r'[,&|\+]|ft\.|\bvs\b', title, flags=re.IGNORECASE)
    keywords = [c.strip() for c in cleaned if c.strip() and len(c.strip()) > 2]
    return keywords

def _infer_theme_from_title(title: str) -> str:
    """Derives an animated story theme context from the scraped video title."""
    clean_title = title.replace("| NOT YOUR TYPE", "").replace("|", "-").strip()
    return f"Creative animated narrative and song inspired by '{clean_title}', featuring relatable fun situations, energetic rhythm, sound effects, and entertaining characters."

# Backward compatibility alias
get_latest_cocomelon_trend = get_latest_channel_trend

def _infer_theme_from_title(title: str) -> str:
    """Derives an animated story/rhyme theme context from the scraped video title."""
    clean_title = title.replace("| NOT YOUR TYPE", "").replace("|", "-").strip()
    return f"Creative animated narrative and song inspired by '{clean_title}', featuring relatable fun situations, energetic rhythm, sound effects, and entertaining characters."

def _get_fallback_trend(reason: str) -> Dict[str, Any]:
    """Provides a guaranteed fallback topic."""
    chosen = random.choice(config.DEFAULT_FALLBACK_THEMES)
    return {
        "status": "fallback",
        "title": chosen["title"],
        "theme": chosen["topic"],
        "keywords": chosen["keywords"],
        "fallback_reason": reason,
        "video_url": f"https://www.youtube.com/{config.TARGET_CHANNEL_HANDLE}",
        "published_at": "Fallback Static Theme",
        "channel_title": config.TARGET_CHANNEL_NAME,
        "source": f"Curated Fallback Bank for {config.TARGET_CHANNEL_NAME}"
    }

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    trend = get_latest_cocomelon_trend()
    print("\n--- Scraped Trend Data ---")
    for k, v in trend.items():
        print(f"{k}: {v}")
