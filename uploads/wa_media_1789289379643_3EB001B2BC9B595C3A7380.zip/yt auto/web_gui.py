import os
import sys
import json
import logging
import threading
import queue
import time
from pathlib import Path
from typing import Dict, Any, List, Optional
from flask import Flask, render_template, request, jsonify, send_from_directory

# Ensure UTF-8 output
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

import config
from trend_scraper import get_latest_channel_trend
from transcript_extractor import extract_video_narrative_context
from script_generator import generate_animated_video_script
from audio_generator import generate_voiceover_audio
from scene_generator import generate_scene_artworks
from thumbnail_generator import create_thumbnail
from video_generator import create_video_animation
from youtube_uploader import upload_video_to_youtube

app = Flask(__name__, template_folder="templates")

# In-Memory State
state = {
    "is_running": False,
    "status_message": "System Ready",
    "trend": None,
    "transcripts": None,
    "script": "",
    "storyboard": [],
    "logs": []
}

class MemoryLogHandler(logging.Handler):
    """Directs logging records to state['logs'] for browser polling."""
    def emit(self, record):
        try:
            msg = self.format(record)
            state["logs"].append(msg)
            if len(state["logs"]) > 500:
                state["logs"].pop(0)
        except Exception:
            pass

# Setup Logger
logger = logging.getLogger("cocolemon_pipeline")
logger.setLevel(logging.INFO)
mem_handler = MemoryLogHandler()
mem_handler.setFormatter(logging.Formatter("[%(asctime)s] %(message)s", "%H:%M:%S"))
logger.addHandler(mem_handler)

def load_initial_state_from_disk():
    """Preloads any existing script or output assets so UI immediately populates."""
    out_dir = Path(config.OUTPUT_DIR)
    script_file = out_dir / "script.txt"
    if script_file.exists():
        try:
            state["script"] = script_file.read_text(encoding="utf-8", errors="replace")
        except Exception:
            pass

load_initial_state_from_disk()

@app.errorhandler(400)
@app.errorhandler(404)
@app.errorhandler(405)
@app.errorhandler(500)
def handle_error(e):
    return jsonify({
        "success": False,
        "error": str(e),
        "message": f"Server error: {e}"
    }), 200

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/output/<path:filename>")
def serve_output_file(filename):
    return send_from_directory(config.OUTPUT_DIR, filename)

@app.route("/api/status", methods=["GET", "POST"])
def get_status():
    logs_to_send = list(state["logs"])
    state["logs"] = [] # consume logs
    return jsonify({
        "is_running": state["is_running"],
        "status_message": state["status_message"],
        "trend": state["trend"],
        "transcripts": state["transcripts"],
        "script": state["script"],
        "storyboard": state["storyboard"],
        "logs": logs_to_send
    })

@app.route("/api/assets", methods=["GET", "POST"])
def get_assets():
    assets = []
    output_dir = Path(config.OUTPUT_DIR)
    
    # Thumbnail
    thumb_path = output_dir / "thumbnail.png"
    if thumb_path.exists():
        assets.append({"title": "📌 Main 1280x720 Thumbnail", "url": "/output/thumbnail.png"})
        
    # Scenes
    for i in range(1, 7):
        scene_p = output_dir / f"scene_{i}.png"
        if scene_p.exists():
            assets.append({"title": f"🎬 Scene {i} Artwork", "url": f"/output/scene_{i}.png"})
            
    return jsonify(assets)

def _execute_pipeline_task(action: str, channel_url: str, topic_override: str, use_pollinations: bool, tts_engine: str = "edge-tts"):
    state["is_running"] = True
    try:
        is_full_or_py_movie = action in ("full", "python_movie")

        if is_full_or_py_movie or action == "scrape":
            state["status_message"] = "Scraping channel & extracting transcripts..."
            logger.info(f"[WebStudio] 🔍 Scraping channel: {channel_url}")
            trend = get_latest_channel_trend(channel_url)
            state["trend"] = trend
            
            # Extract Transcripts
            video_url = trend.get("url", "")
            narrative = extract_video_narrative_context(video_url, topic_override or trend.get("title", ""))
            state["transcripts"] = narrative
            logger.info(f"[WebStudio] ✅ Scraped Video: \"{trend.get('title')}\"")

        if is_full_or_py_movie or action == "script":
            state["status_message"] = "Generating Groq AI Storyboard..."
            trend = state["trend"] or get_latest_channel_trend(channel_url)
            state["trend"] = trend
            
            narrative = state.get("transcripts")
            if not narrative:
                narrative = extract_video_narrative_context(trend.get("url", ""), topic_override or trend.get("title", ""))
                state["transcripts"] = narrative
                
            logger.info(f"[WebStudio] 🧠 Generating comedic script & storyboard using Groq LPU...")
            script_res = generate_animated_video_script(trend, topic_override=topic_override, narrative_context=narrative)
            if isinstance(script_res, tuple):
                script_text, meta = script_res
                storyboard = meta.get("storyboard", [])
            elif isinstance(script_res, dict):
                script_text = script_res.get("full_script", "")
                storyboard = script_res.get("storyboard", [])
            else:
                script_text = str(script_res)
                storyboard = []

            state["script"] = script_text
            state["storyboard"] = storyboard
            logger.info(f"[WebStudio] ✅ Generated {len(state['storyboard'])}-scene storyboard.")

        if is_full_or_py_movie or action == "scene":
            state["status_message"] = "Generating 6-scene artworks..."
            storyboard = state.get("storyboard")
            trend = state.get("trend")
            if not storyboard:
                logger.warning("[WebStudio] No storyboard in state, generating now...")
                trend = trend or get_latest_channel_trend(channel_url)
                narrative = state.get("transcripts") or extract_video_narrative_context(trend.get("url", ""), topic_override or trend.get("title", ""))
                script_res = generate_animated_video_script(trend, topic_override=topic_override, narrative_context=narrative)
                if isinstance(script_res, tuple):
                    script_text, meta = script_res
                    storyboard = meta.get("storyboard", [])
                elif isinstance(script_res, dict):
                    script_text = script_res.get("full_script", "")
                    storyboard = script_res.get("storyboard", [])
                else:
                    script_text = str(script_res)
                    storyboard = []
                state["script"] = script_text
                state["storyboard"] = storyboard
                
            logger.info(f"[WebStudio] 🎨 Generating scene artworks (Pollinations AI: {use_pollinations})...")
            generate_scene_artworks(storyboard, use_ai=use_pollinations, use_pollinations=use_pollinations)
            thumb_title = trend.get("title") if trend else "AI Animated Special"
            create_thumbnail(title=thumb_title, use_ai=use_pollinations)
            logger.info("[WebStudio] ✅ Scene artworks & thumbnail generated.")

        if is_full_or_py_movie or action == "audio":
            state["status_message"] = f"Generating voiceover via {tts_engine}..."
            script_text = state.get("script")
            if not script_text:
                trend = state.get("trend") or get_latest_channel_trend(channel_url)
                narrative = state.get("transcripts") or extract_video_narrative_context(trend.get("url", ""), topic_override or trend.get("title", ""))
                script_res = generate_animated_video_script(trend, topic_override=topic_override, narrative_context=narrative)
                if isinstance(script_res, tuple):
                    script_text, meta = script_res
                    storyboard = meta.get("storyboard", [])
                elif isinstance(script_res, dict):
                    script_text = script_res.get("full_script", "")
                    storyboard = script_res.get("storyboard", [])
                else:
                    script_text = str(script_res)
                    storyboard = []
                state["script"] = script_text
                state["storyboard"] = storyboard
                
            logger.info(f"[WebStudio] 🎙️ Synthesizing voiceover audio ({tts_engine})...")
            generate_voiceover_audio(script_text, engine=tts_engine)
            logger.info("[WebStudio] ✅ Audio generation complete.")

        if is_full_or_py_movie or action == "render":
            state["status_message"] = "Rendering 1080p MP4 Video with MoviePy..."
            storyboard = state.get("storyboard")
            trend = state.get("trend")
            if not storyboard:
                trend = trend or get_latest_channel_trend(channel_url)
                narrative = state.get("transcripts") or extract_video_narrative_context(trend.get("url", ""), topic_override or trend.get("title", ""))
                script_res = generate_animated_video_script(trend, topic_override=topic_override, narrative_context=narrative)
                if isinstance(script_res, tuple):
                    script_text, meta = script_res
                    storyboard = meta.get("storyboard", [])
                elif isinstance(script_res, dict):
                    script_text = script_res.get("full_script", "")
                    storyboard = script_res.get("storyboard", [])
                else:
                    script_text = str(script_res)
                    storyboard = []
                state["script"] = script_text
                state["storyboard"] = storyboard
                
            logger.info(f"[WebStudio] 🎞️ Rendering 1080p 6-scene animation combining audio & subtitles...")
            create_video_animation(
                script_text=state.get("script", ""),
                storyboard=storyboard,
                video_topic=(trend.get("title") if trend else "Animated Special")
            )
            logger.info("[WebStudio] ✅ 1080p Video rendering complete.")

        if action in ("full", "upload"):
            state["status_message"] = "Uploading to YouTube..."
            trend = state.get("trend")
            title = trend.get("title", "AI Animated Comedy Special") if trend else "AI Animated Comedy Special"
            logger.info(f"[WebStudio] 🚀 Uploading video to YouTube: {title}")
            upload_video_to_youtube(video_title=title, description="Generated autonomously with AI.")
            logger.info("[WebStudio] ✅ YouTube upload step finished.")

        state["status_message"] = "Pipeline completed successfully! 🎉"
    except Exception as e:
        logger.error(f"[WebStudio Error] {e}")
        state["status_message"] = f"Error: {e}"
    finally:
        state["is_running"] = False

@app.route("/api/run", methods=["GET", "POST"])
def run_action():
    # Read payload from JSON body, Form data, or Query params safely
    data = request.get_json(force=True, silent=True)
    if not isinstance(data, dict) or not data:
        data = request.form.to_dict() or request.args.to_dict() or {}

    action = data.get("action", "python_movie")
    channel_url = data.get("channel_url", config.CHANNEL_URL) or config.CHANNEL_URL
    topic_override = data.get("topic_override", "")
    tts_engine = data.get("tts_engine", "edge-tts")
    use_pollinations_raw = data.get("use_pollinations", True)
    if isinstance(use_pollinations_raw, str):
        use_pollinations = use_pollinations_raw.lower() in ("true", "1", "yes")
    else:
        use_pollinations = bool(use_pollinations_raw)

    if state["is_running"]:
        return jsonify({
            "success": False,
            "message": "A pipeline task is currently running. Please wait for it to complete."
        }), 200

    threading.Thread(
        target=_execute_pipeline_task,
        args=(action, channel_url, topic_override, use_pollinations, tts_engine),
        daemon=True
    ).start()

    return jsonify({
        "success": True,
        "message": f"Action '{action}' started successfully!"
    }), 200

if __name__ == "__main__":
    port = 5000
    print(f"🚀 NOT YOUR TYPE Web Studio running on http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=False)
