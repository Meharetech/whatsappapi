import os
import sys
import math
import logging
import random
import numpy as np
from pathlib import Path
from typing import Tuple, Dict, Any, List
from PIL import Image, ImageDraw, ImageFont, ImageEnhance

# Ensure UTF-8 output
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

import config
from audio_generator import extract_spoken_lyrics
from scene_generator import generate_scene_artworks

try:
    from moviepy import VideoClip, AudioFileClip
except ImportError:
    from moviepy.video.VideoClip import VideoClip
    from moviepy.audio.io.AudioFileClip import AudioFileClip

logger = logging.getLogger("cocolemon_pipeline")

def create_video_animation(
    script_text: str = "",
    storyboard: List[Dict[str, Any]] = None,
    audio_path: Path = config.AUDIO_OUTPUT_FILE,
    output_video_path: Path = config.VIDEO_OUTPUT_FILE,
    width: int = config.VIDEO_WIDTH,
    height: int = config.VIDEO_HEIGHT,
    fps: int = config.VIDEO_FPS,
    title: str = "Animated Story",
    theme: str = "Animated Story",
    use_ai_scenes: bool = config.USE_POLLINATIONS_AI,
    video_topic: str = "",
    **kwargs
) -> Tuple[bool, Dict[str, Any]]:
    """
    Cinematic 1080p Dynamic Storyboard Animation Studio:
    - Renders dynamic scene backgrounds customized to the scraped video topic (via Pollinations AI or procedural).
    - Applies topic-specific camera motion patterns (bounce zoom, tracking pan, sway, ripple).
    - Synchronizes scene-specific animated characters, costumes & props with voiceover.
    - Features topic-adaptive ambient particles (ABCs, bubbles, stars, confetti, speed lines).
    - Renders action sound bursts and bouncing karaoke subtitles.
    """
    try:
        if not audio_path.exists():
            logger.warning(f"Audio file '{audio_path}' not found. Using default 30s duration.")
            duration = 30.0
            audio_clip = None
        else:
            audio_clip = AudioFileClip(str(audio_path))
            duration = audio_clip.duration
            logger.info(f"Loaded audio track. Duration: {duration:.2f}s")

        # 1. Prepare Dynamic Storyboard & Scene Artwork
        if not storyboard or len(storyboard) == 0:
            from script_generator import _generate_default_storyboard
            storyboard = _generate_default_storyboard(title, theme)

        logger.info(f"Generating {len(storyboard)} high-resolution storyboard scene artworks (AI Scenes: {use_ai_scenes})...")
        scene_art_paths = generate_scene_artworks(storyboard, width=width, height=height, use_ai=use_ai_scenes)

        # Pre-load scene images in memory for fast rendering
        preloaded_scenes = []
        for p in scene_art_paths:
            try:
                img = Image.open(p).convert("RGBA")
                preloaded_scenes.append(img)
            except Exception:
                preloaded_scenes.append(Image.new("RGBA", (width, height), (130, 210, 255, 255)))

        # 2. Build Timed Scene & Lyrics Index
        clean_lyrics = extract_spoken_lyrics(script_text)
        spoken_lines = [l.strip() for l in clean_lyrics.splitlines() if l.strip()]
        if not spoken_lines:
            spoken_lines = ["Sing along with Cocolemon!", "Let's have fun together!"]

        num_scenes = max(len(storyboard), 1)
        time_per_scene = duration / num_scenes
        time_per_line = duration / max(len(spoken_lines), 1)

        # Pre-load Unicode fonts (with Nirmala / Segoe / Arial fallback)
        def _get_font(sz, bold=True):
            for fn in (["NirmalaB.ttf", "segoeuib.ttf", "arialbd.ttf"] if bold else ["Nirmala.ttf", "segoeui.ttf", "arial.ttf"]):
                try:
                    return ImageFont.truetype(fn, sz)
                except Exception:
                    continue
            return ImageFont.load_default()

        subtitle_font = _get_font(46, bold=True)
        badge_font = _get_font(34, bold=True)
        sfx_font = _get_font(42, bold=True)
        prop_font = _get_font(40, bold=True)

        # Confetti & Particle seeds
        confetti_particles = [(random.randint(0, width), random.randint(0, height), random.choice([(255, 60, 120), (255, 220, 0), (60, 200, 255), (150, 255, 80)])) for _ in range(40)]

        # 3. Main Frame Generator Function
        def make_frame(t):
            # Calculate active scene index
            scene_idx = min(int(t / time_per_scene), num_scenes - 1)
            active_scene_meta = storyboard[scene_idx]
            scene_img = preloaded_scenes[scene_idx]

            # Scene Progress (0.0 -> 1.0)
            scene_t_start = scene_idx * time_per_scene
            scene_progress = min(1.0, max(0.0, (t - scene_t_start) / time_per_scene))

            # --- DYNAMIC TOPIC-SPECIFIC CAMERA MOTION PATTERN ---
            cam_motion = active_scene_meta.get("camera_motion", "bounce_zoom")
            anim_pattern = active_scene_meta.get("animation_pattern", "dance_party")
            sfx_text = active_scene_meta.get("sfx", "").strip()

            zoom_scale, pan_x, pan_y, screen_shake_y = _calculate_camera_transform(
                t=t,
                scene_progress=scene_progress,
                scene_idx=scene_idx,
                camera_motion=cam_motion,
                anim_pattern=anim_pattern,
                has_sfx=bool(sfx_text),
                width=width,
                height=height
            )

            crop_w = int(width / zoom_scale)
            crop_h = int(height / zoom_scale)
            crop_x = min(width - crop_w, max(0, (width - crop_w) // 2 + pan_x))
            crop_y = min(height - crop_h, max(0, (height - crop_h) // 2 + pan_y + screen_shake_y))

            cropped = scene_img.crop((crop_x, crop_y, crop_x + crop_w, crop_y + crop_h))
            frame = cropped.resize((width, height), Image.Resampling.BILINEAR)
            draw = ImageDraw.Draw(frame)

            # --- THEME-SPECIFIC ATMOSPHERIC OVERLAYS ---
            _apply_theme_atmosphere(draw, width, height, t, anim_pattern, active_scene_meta.get("theme_category", ""))

            # --- TOPIC-ADAPTIVE FLOATING PARTICLES ---
            _draw_scene_particles(draw, width, height, t, active_scene_meta, confetti_particles, prop_font)

            # --- DYNAMIC SCENE & CHARACTER ANIMATION (in procedural fallback mode) ---
            if not use_ai_scenes:
                _render_storyboard_character(draw, active_scene_meta, width, height, t, prop_font)

            # --- ANIMATED SOUND EFFECT BURSTS ---
            if sfx_text:
                clean_sfx = sfx_text.replace("[", "").replace("]", "").strip().upper()
                _draw_sfx_badge(draw, clean_sfx, width, height, t, sfx_font)

            # --- TOP CHANNEL BADGE ---
            channel_label = getattr(config, "TARGET_CHANNEL_NAME", "ANIMATION STUDIO")
            badge_w = max(240, len(channel_label) * 20 + 50)
            draw.rounded_rectangle([50, 35, 50 + badge_w, 95], radius=18, fill=(255, 65, 125), outline=(255, 255, 255), width=4)
            draw.text((50 + badge_w // 2, 65), channel_label, font=badge_font, fill=(255, 255, 255), anchor="mm")

            # --- KARAOKE SUBTITLE PILL WITH TOPIC HIGHLIGHT COLOR ---
            curr_line_idx = min(int(t / time_per_line), len(spoken_lines) - 1)
            active_lyric = spoken_lines[curr_line_idx]
            _draw_karaoke_pill(draw, active_lyric, width, height, t, subtitle_font, anim_pattern)

            return np.array(frame.convert("RGB"))

        logger.info(f"Rendering multi-scene storyboard animation ({width}x{height} @ {fps}fps, {duration:.1f}s)...")
        try:
            video_clip = VideoClip(frame_function=make_frame, duration=duration)
        except TypeError:
            video_clip = VideoClip(make_frame, duration=duration)

        if audio_clip:
            if hasattr(video_clip, "with_audio"):
                video_clip = video_clip.with_audio(audio_clip)
            else:
                video_clip = video_clip.set_audio(audio_clip)

        output_video_path.parent.mkdir(parents=True, exist_ok=True)

        video_clip.write_videofile(
            str(output_video_path),
            fps=fps,
            codec="libx264",
            audio_codec="aac",
            preset="ultrafast",
            threads=4,
            logger=None
        )

        file_size_mb = round(os.path.getsize(output_video_path) / (1024 * 1024), 2)
        logger.info(f"-> Dynamic cinematic animation video generated: {output_video_path} ({file_size_mb} MB)")

        return True, {
            "status": "success",
            "file_path": str(output_video_path),
            "file_size_mb": file_size_mb,
            "duration_seconds": round(duration, 2),
            "scenes_count": len(storyboard),
            "resolution": f"{width}x{height}",
            "fps": fps
        }

    except Exception as e:
        logger.error(f"Error creating cinematic animation video: {e}")
        return False, {"status": "error", "error": str(e)}

# -----------------------------------------------------------------------------
# DYNAMIC CAMERA TRANSFORM ENGINE
# -----------------------------------------------------------------------------
def _calculate_camera_transform(t: float, scene_progress: float, scene_idx: int, camera_motion: str, anim_pattern: str, has_sfx: bool, width: int, height: int):
    """Calculates distinct camera zoom, pan, drift, and shake tailored to the active scene."""
    pan_x = 0
    pan_y = 0
    zoom_scale = 1.0
    shake_y = 0

    if camera_motion == "pan_and_track" or anim_pattern == "vehicle_cruising":
        # Horizontal Tracking Pan with road vibration
        zoom_scale = 1.04 + (scene_progress * 0.04)
        pan_x = int((scene_progress - 0.5) * 90)
        pan_y = int(math.sin(t * 20.0) * 3)
    elif camera_motion == "float_sway" or anim_pattern == "bedtime_sway":
        # Slow dreamlike pendulum sway
        zoom_scale = 1.02 + math.sin(t * 0.9) * 0.03
        pan_x = int(math.sin(t * 1.3) * 35)
        pan_y = int(math.cos(t * 1.0) * 15)
    elif camera_motion == "focal_zoom" or anim_pattern == "educational_focus":
        # Focused progressive zoom on props/character
        zoom_scale = 1.0 + (scene_progress * 0.10)
        pan_x = int(math.sin(t * 2.0) * 15)
        pan_y = int(scene_progress * 10)
    elif camera_motion == "wave_ripple" or anim_pattern == "aquatic_swim":
        # Sinusoidal aquatic drift
        zoom_scale = 1.03 + math.sin(t * 1.6) * 0.03
        pan_x = int(math.sin(t * 2.2) * 40)
        pan_y = int(math.cos(t * 2.8) * 20)
    elif camera_motion == "sweep_reveal" or anim_pattern == "dino_stomp":
        # Wide sweeping reveal to center
        zoom_scale = 1.0 + (scene_progress * 0.08)
        pan_x = int((1.0 - scene_progress) * 55 if scene_idx % 2 == 0 else (scene_progress - 1.0) * 55)
        pan_y = 0
    else: # "bounce_zoom" or "stage_pulse" or "dance_party"
        # Rhythmic tempo pulse zoom
        beat_pulse = 0.03 * abs(math.sin(t * 8.0))
        zoom_scale = 1.03 + beat_pulse + (scene_progress * 0.05)
        pan_offset = int(scene_progress * 35)
        pan_x = pan_offset if scene_idx % 2 == 0 else -pan_offset
        pan_y = 0

    # Impact screen shake on sound effects / stomps
    if has_sfx and (math.sin(t * 12.0) > 0.75):
        shake_y = int(math.sin(t * 30.0) * 6)

    return zoom_scale, pan_x, pan_y, shake_y

# -----------------------------------------------------------------------------
# ATMOSPHERIC THEME OVERLAYS
# -----------------------------------------------------------------------------
def _apply_theme_atmosphere(draw: ImageDraw.ImageDraw, w: int, h: int, t: float, anim_pattern: str, theme_category: str):
    """Applies subtle theme-specific visual borders and lighting vibes."""
    if anim_pattern == "bedtime_sway" or theme_category == "bedtime":
        # Soft night ambient glow in top corners
        for r in range(120, 0, -20):
            draw.ellipse([w - r * 2, -r, w + r, r * 2], fill=(255, 245, 150, 12))
    elif anim_pattern == "vehicle_cruising" or theme_category == "vehicles":
        # Subtle horizontal motion streaks
        for sy in [int(h * 0.70), int(h * 0.76), int(h * 0.82)]:
            sx = int((t * 600 + sy * 5) % (w + 200)) - 100
            draw.line([(sx, sy), (sx + 80, sy)], fill=(255, 255, 255, 60), width=3)
    elif anim_pattern == "aquatic_swim" or theme_category == "bath" or theme_category == "ocean":
        # Subtle water caustics overlay in corners
        for i in range(4):
            cx = int((i * 350 + math.sin(t * 2 + i) * 60) % w)
            cy = int(h * 0.85 + math.sin(t * 3 + i) * 20)
            draw.ellipse([cx - 40, cy - 20, cx + 40, cy + 20], fill=(255, 255, 255, 25))
    elif anim_pattern == "dance_party" or theme_category == "party":
        # Moving colorful stage spotlight beams
        spot_x = int(w // 2 + math.sin(t * 3.0) * (w // 3))
        draw.polygon([(w // 2, 0), (spot_x - 140, h), (spot_x + 140, h)], fill=(255, 240, 100, 18))

# -----------------------------------------------------------------------------
# DYNAMIC CHARACTER & SCENE-SPECIFIC ANIMATIONS
# -----------------------------------------------------------------------------
def _render_storyboard_character(draw: ImageDraw.ImageDraw, scene_meta: dict, w: int, h: int, t: float, font: ImageFont.ImageFont):
    """Renders characters, costumes, and props tailored to the specific scene."""
    scene_name = scene_meta.get("scene_name", "").lower()
    prompt = scene_meta.get("visual_prompt", "").lower()
    cat = scene_meta.get("theme_category", "").lower()
    action = scene_meta.get("action", "").lower()
    anim_pattern = scene_meta.get("animation_pattern", "").lower()
    combined = f"{scene_name} {prompt} {cat} {action} {anim_pattern}"

    # Bounce dynamics depend on the animation pattern!
    if "bedtime" in combined:
        bounce = int(math.sin(t * 3.0) * 12)
    elif "vehicle" in combined:
        bounce = int(math.sin(t * 14.0) * 8)
    elif "dino" in combined or "stomp" in action:
        bounce = int(abs(math.sin(t * 6.0)) * 32)
    else:
        bounce = int(math.sin(t * 8.0) * 24)

    mouth_open = (math.sin(t * 14.0) > 0.0)

    # 1. Classroom / ABCs / Learning
    if any(k in combined for k in ["classroom", "abc", "alphabet", "letter", "school", "reading", "educational"]):
        _draw_abc_learning_jj(draw, center_x=w // 2, center_y=int(h * 0.65) + bounce, scale=1.3, mouth_open=mouth_open, t=t, font=font)
    # 2. Bath Time / Bubbles
    elif any(k in combined for k in ["bath", "bubble", "wash", "soap", "tub", "clean"]):
        _draw_bath_tub_jj(draw, center_x=w // 2, center_y=int(h * 0.65) + bounce // 2, scale=1.3, mouth_open=mouth_open, t=t)
    # 3. Bedtime / Night / Stars / Moon
    elif any(k in combined for k in ["bedtime", "night", "moon", "star", "lullaby", "dream", "sleep", "teddy", "pajama"]):
        _draw_bedtime_sleepy_jj(draw, center_x=w // 2, center_y=int(h * 0.64) + bounce, scale=1.3, mouth_open=mouth_open, t=t)
    # 4. Ocean / Shark / Swimming
    elif any(k in combined for k in ["shark", "ocean", "sea", "fish", "underwater", "beach", "swim"]):
        _draw_baby_shark_and_jj(draw, center_x=w // 2, center_y=int(h * 0.62) + bounce, scale=1.3, mouth_open=mouth_open, t=t)
    # 5. Bus / Vehicles / Town
    elif any(k in combined for k in ["bus", "drive", "vehicle", "street", "car"]):
        _draw_yellow_school_bus(draw, center_x=w // 2, center_y=int(h * 0.66) + bounce // 3, scale=1.3, t=t)
    # 6. Tractor / Country Road / Train
    elif any(k in combined for k in ["tractor", "train", "road", "chug"]):
        _draw_moving_tractor(draw, center_x=w // 2, center_y=int(h * 0.68) + bounce // 2, scale=1.3, t=t)
    # 7. Food / Eating / Kitchen
    elif any(k in combined for k in ["eat", "fruit", "food", "apple", "banana", "yummy", "snack"]):
        _draw_eating_fruits_jj(draw, center_x=w // 2, center_y=int(h * 0.63) + bounce, scale=1.3, mouth_open=mouth_open, t=t)
    # 8. Dinosaur / Prehistoric
    elif any(k in combined for k in ["dino", "dinosaur", "rex", "prehistoric", "jungle"]):
        _draw_baby_dino_and_jj(draw, center_x=w // 2, center_y=int(h * 0.64) + bounce, scale=1.3, mouth_open=mouth_open, t=t)
    # 9. Doctor / Clinic
    elif any(k in combined for k in ["doctor", "clinic", "hospital", "checkup", "nurse"]):
        _draw_doctor_jj(draw, center_x=w // 2, center_y=int(h * 0.63) + bounce, scale=1.3, mouth_open=mouth_open, t=t)
    # 10. Farm Animals / Pond
    elif any(k in combined for k in ["pond", "duck", "pig", "mud"]):
        _draw_swimming_duck(draw, center_x=int(w * 0.74), center_y=int(h * 0.65) + int(bounce * 0.5), scale=1.3, t=t)
        _draw_happy_pig(draw, center_x=int(w * 0.28), center_y=int(h * 0.66) + bounce, scale=1.2, mouth_open=mouth_open, t=t)
    elif any(k in combined for k in ["cow", "animal", "farm", "sheep"]):
        _draw_singing_cow(draw, center_x=int(w * 0.35), center_y=int(h * 0.64) + bounce, scale=1.3, mouth_open=mouth_open, t=t)
        _draw_dancing_jj(draw, center_x=int(w * 0.70), center_y=int(h * 0.62) + bounce, scale=1.2, mouth_open=mouth_open, t=t)
    else:
        # Default Dancing JJ
        _draw_dancing_jj(draw, center_x=w // 2, center_y=int(h * 0.62) + bounce, scale=1.4, mouth_open=mouth_open, t=t)

# -----------------------------------------------------------------------------
# 1. ABC / LEARNING JJ WITH BOUNCING 3D BLOCKS
# -----------------------------------------------------------------------------
def _draw_abc_learning_jj(draw: ImageDraw.ImageDraw, center_x: int, center_y: int, scale: float, mouth_open: bool, t: float, font: ImageFont.ImageFont):
    """Draws JJ holding and building glowing colorful ABC letter blocks."""
    _draw_dancing_jj(draw, center_x=center_x, center_y=center_y, scale=scale, mouth_open=mouth_open, t=t)

    # 3D Letter Blocks Floating and Bouncing on Left & Right
    block_offset = int(math.sin(t * 6.0) * 18)
    # Left Block 'A'
    b1_x, b1_y = center_x - int(240 * scale), center_y + block_offset - 20
    draw.rounded_rectangle([b1_x - 55, b1_y - 55, b1_x + 55, b1_y + 55], radius=14, fill=(255, 65, 95), outline=(255, 255, 255), width=4)
    draw.text((b1_x, b1_y), "A", font=font, fill=(255, 255, 255), anchor="mm")

    # Right Block 'B'
    b2_x, b2_y = center_x + int(240 * scale), center_y - block_offset - 20
    draw.rounded_rectangle([b2_x - 55, b2_y - 55, b2_x + 55, b2_y + 55], radius=14, fill=(45, 185, 255), outline=(255, 255, 255), width=4)
    draw.text((b2_x, b2_y), "B", font=font, fill=(255, 255, 255), anchor="mm")

    # Center Top Block 'C'
    b3_x, b3_y = center_x, center_y - int(190 * scale) + block_offset // 2
    draw.rounded_rectangle([b3_x - 45, b3_y - 45, b3_x + 45, b3_y + 45], radius=12, fill=(255, 215, 30), outline=(255, 255, 255), width=4)
    draw.text((b3_x, b3_y), "C", font=font, fill=(30, 30, 30), anchor="mm")

# -----------------------------------------------------------------------------
# 2. BATH TUB JJ WITH RUBBER DUCK & SHAMPOO HAT
# -----------------------------------------------------------------------------
def _draw_bath_tub_jj(draw: ImageDraw.ImageDraw, center_x: int, center_y: int, scale: float, mouth_open: bool, t: float):
    """Draws JJ in bathtub with bubbly foam shampoo crown and yellow rubber duck."""
    tw, th = int(220 * scale), int(70 * scale)
    draw.rounded_rectangle([center_x - tw, center_y, center_x + tw, center_y + th], radius=35, fill=(255, 255, 255), outline=(180, 220, 240), width=6)
    draw.ellipse([center_x - tw + 20, center_y - 15, center_x + tw - 20, center_y + 40], fill=(70, 190, 255))

    _draw_dancing_jj(draw, center_x=center_x, center_y=center_y - 35, scale=scale * 0.95, mouth_open=mouth_open, t=t)

    head_y = center_y - 35 - int(120 * scale * 0.95)
    for fx in [-40, -15, 15, 40]:
        draw.ellipse([center_x + fx - 22, head_y - 25, center_x + fx + 22, head_y + 15], fill=(255, 255, 255, 240), outline=(210, 240, 255), width=2)

    duck_bounce = int(math.sin(t * 9.0) * 12)
    _draw_swimming_duck(draw, center_x=center_x + int(150 * scale), center_y=center_y + duck_bounce, scale=scale * 0.7, t=t)

# -----------------------------------------------------------------------------
# 3. BEDTIME SLEEPY JJ WITH STARRY CAP & TEDDY BEAR
# -----------------------------------------------------------------------------
def _draw_bedtime_sleepy_jj(draw: ImageDraw.ImageDraw, center_x: int, center_y: int, scale: float, mouth_open: bool, t: float):
    """Draws JJ in cozy starry nightcap hugging a cute teddy bear."""
    _draw_dancing_jj(draw, center_x=center_x, center_y=center_y, scale=scale, mouth_open=mouth_open, t=t)

    head_top_y = center_y - int(140 * scale)
    draw.polygon([
        (center_x - 50, head_top_y + 20),
        (center_x + 50, head_top_y + 20),
        (center_x + 120, head_top_y + 70)
    ], fill=(60, 90, 180), outline=(255, 255, 255), width=3)
    draw.ellipse([center_x + 105, head_top_y + 55, center_x + 135, head_top_y + 85], fill=(255, 235, 80))

    tb_x, tb_y = center_x - int(70 * scale), center_y + int(35 * scale)
    draw.ellipse([tb_x - 35, tb_y - 35, tb_x + 35, tb_y + 35], fill=(165, 110, 65), outline=(120, 75, 40), width=4)
    draw.ellipse([tb_x - 38, tb_y - 45, tb_x - 18, tb_y - 25], fill=(165, 110, 65))
    draw.ellipse([tb_x + 18, tb_y - 45, tb_x + 38, tb_y - 25], fill=(165, 110, 65))
    draw.ellipse([tb_x - 18, tb_y - 5, tb_x + 18, tb_y + 25], fill=(235, 195, 155))
    draw.ellipse([tb_x - 8, tb_y, tb_x + 8, tb_y + 12], fill=(30, 30, 30))

# -----------------------------------------------------------------------------
# 4. BABY SHARK & OCEAN SWIMMING
# -----------------------------------------------------------------------------
def _draw_baby_shark_and_jj(draw: ImageDraw.ImageDraw, center_x: int, center_y: int, scale: float, mouth_open: bool, t: float):
    """Draws animated Baby Shark swimming with fin movements next to JJ."""
    _draw_dancing_jj(draw, center_x=center_x - int(140 * scale), center_y=center_y, scale=scale * 0.9, mouth_open=mouth_open, t=t)

    sh_x = center_x + int(140 * scale)
    sh_y = center_y + int(math.sin(t * 7.0) * 20)
    w, h = int(140 * scale), int(90 * scale)

    draw.ellipse([sh_x - w, sh_y - h, sh_x + w, sh_y + h], fill=(255, 220, 30), outline=(215, 165, 15), width=5)
    draw.ellipse([sh_x - int(w * 0.7), sh_y + 5, sh_x + int(w * 0.7), sh_y + h - 5], fill=(255, 255, 255))
    draw.polygon([(sh_x - 10, sh_y - h + 10), (sh_x + 20, sh_y - h - 45), (sh_x + 45, sh_y - h + 10)], fill=(255, 220, 30), outline=(215, 165, 15), width=4)

    tail_wave = math.sin(t * 12.0) * 15
    draw.polygon([(sh_x - w + 10, sh_y), (sh_x - w - 45, sh_y - 40 + tail_wave), (sh_x - w - 45, sh_y + 40 + tail_wave)], fill=(255, 220, 30), outline=(215, 165, 15), width=4)
    draw.ellipse([sh_x + 35, sh_y - 30, sh_x + 65, sh_y], fill=(30, 30, 30))
    draw.ellipse([sh_x + 42, sh_y - 25, sh_x + 52, sh_y - 15], fill=(255, 255, 255))
    if mouth_open:
        draw.polygon([(sh_x + 40, sh_y + 10), (sh_x + 85, sh_y + 10), (sh_x + 60, sh_y + 38)], fill=(225, 45, 65))
    else:
        draw.arc([sh_x + 40, sh_y + 5, sh_x + 85, sh_y + 30], 10, 170, fill=(30, 30, 30), width=4)

# -----------------------------------------------------------------------------
# 5. FOOD / FRUITS JJ
# -----------------------------------------------------------------------------
def _draw_eating_fruits_jj(draw: ImageDraw.ImageDraw, center_x: int, center_y: int, scale: float, mouth_open: bool, t: float):
    _draw_dancing_jj(draw, center_x=center_x, center_y=center_y, scale=scale, mouth_open=mouth_open, t=t)
    ax, ay = center_x + int(110 * scale), center_y - int(10 * scale)
    draw.ellipse([ax - 40, ay - 40, ax + 40, ay + 40], fill=(255, 45, 65), outline=(190, 20, 35), width=4)
    draw.rectangle([ax - 4, ay - 55, ax + 4, ay - 35], fill=(110, 65, 30))
    draw.ellipse([ax + 4, ay - 60, ax + 28, ay - 42], fill=(60, 185, 75))

# -----------------------------------------------------------------------------
# 6. DINOSAUR & JJ
# -----------------------------------------------------------------------------
def _draw_baby_dino_and_jj(draw: ImageDraw.ImageDraw, center_x: int, center_y: int, scale: float, mouth_open: bool, t: float):
    _draw_dancing_jj(draw, center_x=center_x - int(130 * scale), center_y=center_y, scale=scale * 0.9, mouth_open=mouth_open, t=t)
    dx, dy = center_x + int(140 * scale), center_y
    dw, dh = int(120 * scale), int(100 * scale)
    draw.ellipse([dx - dw, dy - dh, dx + dw, dy + dh], fill=(95, 205, 85), outline=(50, 140, 45), width=5)
    for px in [-40, 0, 40]:
        draw.polygon([(dx + px - 15, dy - dh + 10), (dx + px, dy - dh - 25), (dx + px + 15, dy - dh + 10)], fill=(255, 160, 40))
    draw.ellipse([dx + 30, dy - 35, dx + 60, dy - 5], fill=(30, 30, 30))
    draw.ellipse([dx + 38, dy - 30, dx + 48, dy - 20], fill=(255, 255, 255))
    draw.arc([dx + 25, dy + 5, dx + 75, dy + 35], 10, 170, fill=(30, 30, 30), width=4)

# -----------------------------------------------------------------------------
# 7. DOCTOR JJ
# -----------------------------------------------------------------------------
def _draw_doctor_jj(draw: ImageDraw.ImageDraw, center_x: int, center_y: int, scale: float, mouth_open: bool, t: float):
    _draw_dancing_jj(draw, center_x=center_x, center_y=center_y, scale=scale, mouth_open=mouth_open, t=t)
    st_y = center_y + 15
    draw.arc([center_x - 65, st_y - 20, center_x + 65, st_y + 45], 0, 180, fill=(50, 50, 60), width=6)
    draw.ellipse([center_x - 18, st_y + 35, center_x + 18, st_y + 70], fill=(210, 215, 225), outline=(50, 50, 60), width=4)

# -----------------------------------------------------------------------------
# CORE CHARACTER MASCOTS
# -----------------------------------------------------------------------------
def _draw_dancing_jj(draw: ImageDraw.ImageDraw, center_x: int, center_y: int, scale: float, mouth_open: bool, t: float):
    """Draws animated JJ Melon character with waving arms and lip-sync singing."""
    w = int(170 * scale)
    h = int(150 * scale)

    # Waving Arms
    arm_wave_l = math.sin(t * 8.0) * 35
    arm_wave_r = math.cos(t * 8.0) * 35
    draw.line([(center_x - w + 20, center_y), (center_x - w - 45, center_y - 40 + arm_wave_l)], fill=(60, 180, 70), width=16)
    draw.ellipse([center_x - w - 60, center_y - 55 + arm_wave_l, center_x - w - 30, center_y - 25 + arm_wave_l], fill=(255, 205, 175))

    draw.line([(center_x + w - 20, center_y), (center_x + w + 45, center_y - 40 + arm_wave_r)], fill=(60, 180, 70), width=16)
    draw.ellipse([center_x + w + 30, center_y - 55 + arm_wave_r, center_x + w + 60, center_y - 25 + arm_wave_r], fill=(255, 205, 175))

    # Watermelon Body
    draw.ellipse([center_x - w, center_y - h, center_x + w, center_y + h], fill=(68, 195, 80), outline=(30, 120, 40), width=7)
    for offset_x in [-w + 35, -w // 2, 0, w // 2, w - 35]:
        draw.arc([center_x + offset_x - 16, center_y - h + 12, center_x + offset_x + 16, center_y + h - 12], 0, 360, fill=(35, 145, 45), width=9)

    # Pink Face
    fw, fh = int(w * 0.78), int(h * 0.78)
    draw.ellipse([center_x - fw, center_y - fh + 12, center_x + fw, center_y + fh + 12], fill=(255, 105, 135), outline=(255, 255, 255), width=5)

    # Eyes
    eye_offset = int(48 * scale)
    eye_r = int(18 * scale)
    draw.ellipse([center_x - eye_offset - eye_r, center_y - 15 - eye_r, center_x - eye_offset + eye_r, center_y - 15 + eye_r], fill=(30, 30, 30))
    draw.ellipse([center_x - eye_offset - 6, center_y - 23, center_x - eye_offset + 8, center_y - 9], fill=(255, 255, 255))
    draw.ellipse([center_x + eye_offset - eye_r, center_y - 15 - eye_r, center_x + eye_offset + eye_r, center_y - 15 + eye_r], fill=(30, 30, 30))
    draw.ellipse([center_x + eye_offset - 6, center_y - 23, center_x + eye_offset + 8, center_y - 9], fill=(255, 255, 255))

    # Cheeks
    draw.ellipse([center_x - eye_offset - 25, center_y + 12, center_x - eye_offset + 15, center_y + 45], fill=(255, 55, 95, 200))
    draw.ellipse([center_x + eye_offset - 15, center_y + 12, center_x + eye_offset + 25, center_y + 45], fill=(255, 55, 95, 200))

    # Lip-Sync Mouth
    if mouth_open:
        draw.ellipse([center_x - 28, center_y + 8, center_x + 28, center_y + 55], fill=(190, 20, 40), outline=(40, 10, 10), width=4)
        draw.arc([center_x - 18, center_y + 30, center_x + 18, center_y + 52], 0, 180, fill=(255, 120, 150), width=8)
    else:
        draw.arc([center_x - 32, center_y + 5, center_x + 32, center_y + 42], 10, 170, fill=(40, 20, 20), width=6)

    # Antennae
    draw.line([(center_x - 25, center_y - h), (center_x - 50, center_y - h - 45)], fill=(40, 40, 40), width=6)
    draw.ellipse([center_x - 65, center_y - h - 60, center_x - 35, center_y - h - 30], fill=(255, 40, 40), outline=(20, 20, 20), width=3)
    draw.line([(center_x + 25, center_y - h), (center_x + 50, center_y - h - 45)], fill=(40, 40, 40), width=6)
    draw.ellipse([center_x + 35, center_y - h - 60, center_x + 65, center_y - h - 30], fill=(255, 40, 40), outline=(20, 20, 20), width=3)

def _draw_singing_cow(draw: ImageDraw.ImageDraw, center_x: int, center_y: int, scale: float, mouth_open: bool, t: float):
    w, h = int(160 * scale), int(130 * scale)
    draw.ellipse([center_x - w, center_y - h + 25, center_x + w, center_y + h + 25], fill=(255, 255, 255), outline=(40, 40, 40), width=6)
    draw.ellipse([center_x - 90, center_y - 20, center_x - 30, center_y + 45], fill=(40, 40, 40))
    draw.ellipse([center_x + 40, center_y - 35, center_x + 100, center_y + 25], fill=(40, 40, 40))
    draw.ellipse([center_x - 80, center_y - h - 10, center_x + 80, center_y + 20], fill=(255, 255, 255), outline=(40, 40, 40), width=5)
    draw.ellipse([center_x - 70, center_y - 30, center_x + 70, center_y + 35], fill=(255, 175, 195), outline=(40, 40, 40), width=5)
    if mouth_open:
        draw.ellipse([center_x - 22, center_y + 5, center_x + 22, center_y + 30], fill=(190, 20, 40))
    else:
        draw.arc([center_x - 25, center_y - 5, center_x + 25, center_y + 25], 10, 170, fill=(40, 40, 40), width=4)

def _draw_happy_pig(draw: ImageDraw.ImageDraw, center_x: int, center_y: int, scale: float, mouth_open: bool, t: float):
    w, h = int(150 * scale), int(130 * scale)
    draw.ellipse([center_x - w, center_y - h, center_x + w, center_y + h], fill=(255, 170, 195), outline=(40, 40, 40), width=6)
    draw.ellipse([center_x - 50, center_y - 10, center_x + 50, center_y + 50], fill=(255, 130, 165), outline=(40, 40, 40), width=5)
    if mouth_open:
        draw.ellipse([center_x - 18, center_y + 35, center_x + 18, center_y + 65], fill=(190, 20, 40))
    else:
        draw.arc([center_x - 22, center_y + 30, center_x + 22, center_y + 60], 10, 170, fill=(40, 40, 40), width=4)

def _draw_swimming_duck(draw: ImageDraw.ImageDraw, center_x: int, center_y: int, scale: float, t: float):
    w, h = int(130 * scale), int(100 * scale)
    draw.ellipse([center_x - w, center_y - h + 15, center_x + w, center_y + h + 15], fill=(255, 220, 25), outline=(210, 160, 10), width=5)
    head_x, head_y = center_x - 60, center_y - 55
    draw.ellipse([head_x - 45, head_y - 45, head_x + 45, head_y + 45], fill=(255, 225, 30), outline=(210, 160, 10), width=5)
    draw.polygon([(head_x - 35, head_y + 5), (head_x - 95, head_y + 15), (head_x - 35, head_y + 30)], fill=(255, 130, 20), outline=(180, 80, 10), width=4)

def _draw_moving_tractor(draw: ImageDraw.ImageDraw, center_x: int, center_y: int, scale: float, t: float):
    w, h = int(170 * scale), int(110 * scale)
    draw.rectangle([center_x - w + 45, center_y - h + 15, center_x + w - 35, center_y + 25], fill=(225, 45, 45), outline=(160, 20, 20), width=6)
    draw.rectangle([center_x - 35, center_y - h - 35, center_x + w - 40, center_y - h + 15], fill=(255, 255, 255), outline=(160, 20, 20), width=5)
    draw.ellipse([center_x + 35 - 70, center_y + 20 - 70, center_x + 35 + 70, center_y + 20 + 70], fill=(40, 40, 40), outline=(255, 220, 0), width=8)
    draw.ellipse([center_x - 100 - 45, center_y + 35 - 45, center_x - 100 + 45, center_y + 35 + 45], fill=(40, 40, 40), outline=(255, 220, 0), width=6)

def _draw_yellow_school_bus(draw: ImageDraw.ImageDraw, center_x: int, center_y: int, scale: float, t: float):
    w, h = int(240 * scale), int(120 * scale)
    draw.rounded_rectangle([center_x - w, center_y - h, center_x + w, center_y + h - 20], radius=24, fill=(255, 215, 0), outline=(200, 160, 0), width=6)
    for wx in range(center_x - w + 40, center_x + w - 40, int(75 * scale)):
        draw.rounded_rectangle([wx, center_y - h + 25, wx + int(55 * scale), center_y - 10], radius=8, fill=(185, 235, 255), outline=(255, 255, 255), width=3)
    draw.rectangle([center_x - w, center_y + 10, center_x + w, center_y + 30], fill=(40, 40, 40))
    draw.ellipse([center_x + w - 20, center_y + 35, center_x + w + 10, center_y + 65], fill=(255, 255, 255), outline=(255, 220, 0), width=3)
    for wheel_x in [center_x - int(130 * scale), center_x + int(130 * scale)]:
        draw.ellipse([wheel_x - 45, center_y + h - 50, wheel_x + 45, center_y + h + 40], fill=(30, 30, 30), outline=(220, 220, 220), width=7)
        draw.ellipse([wheel_x - 20, center_y + h - 25, wheel_x + 20, center_y + h + 15], fill=(255, 215, 0))

# -----------------------------------------------------------------------------
# TOPIC-ADAPTIVE PARTICLES, SFX BURSTS & KARAOKE SUBTITLES
# -----------------------------------------------------------------------------
def _draw_scene_particles(draw: ImageDraw.ImageDraw, w: int, h: int, t: float, scene_meta: dict, confetti: list, font: ImageFont.ImageFont):
    """Draws dynamic floating particles matching the active scene's theme."""
    cat = scene_meta.get("theme_category", "").lower()
    name = scene_meta.get("scene_name", "").lower()
    anim = scene_meta.get("animation_pattern", "").lower()

    if "classroom" in cat or "abc" in name or "educational" in anim:
        letters = ["A", "B", "C", "1", "2", "3", "★", "♫"]
        colors = [(255, 75, 110), (255, 220, 0), (60, 200, 255), (120, 240, 80)]
        for i, l in enumerate(letters):
            lx = int((i * 240 + math.sin(t * 1.5 + i) * 70) % w)
            ly = int(h - ((t * 80 + i * 140) % (h + 100)))
            col = colors[i % len(colors)]
            draw.text((lx, ly), l, font=font, fill=col, anchor="mm")
    elif "bedtime" in cat or "night" in name or "bedtime" in anim:
        for i in range(12):
            sx = int((i * 170 + math.sin(t * 2 + i) * 50) % w)
            sy = int((i * 90 + t * 40) % int(h * 0.7))
            sr = int(8 + math.sin(t * 8 + i) * 4)
            draw.ellipse([sx - sr, sy - sr, sx + sr, sy + sr], fill=(255, 245, 120, 200))
    elif "bath" in cat or "ocean" in cat or "aquatic" in anim:
        for i in range(10):
            bx = int((i * 200 + math.sin(t * 1.8 + i) * 60) % w)
            by = int(h - ((t * 90 + i * 120) % (h + 120)))
            r = 18 + (i % 3) * 10
            draw.ellipse([bx - r, by - r, bx + r, by + r], fill=(255, 255, 255, 80), outline=(255, 255, 255, 180), width=3)
    elif "party" in cat or "rainbow" in name or "dance" in anim:
        for orig_x, orig_y, col in confetti:
            cx = int((orig_x + math.sin(t * 2 + orig_y) * 45) % w)
            cy = int((orig_y + t * 140) % h)
            draw.rectangle([cx - 9, cy - 6, cx + 9, cy + 6], fill=col)
    else:
        for i in range(8):
            bx = int((i * 250 + math.sin(t * 1.5 + i) * 60) % w)
            by = int(h - ((t * 75 + i * 130) % (h + 150)))
            r = 16 + (i % 3) * 6
            draw.ellipse([bx - r, by - r, bx + r, by + r], fill=(255, 255, 255, 75), outline=(255, 255, 255, 150), width=3)

def _draw_sfx_badge(draw: ImageDraw.ImageDraw, sfx_text: str, w: int, h: int, t: float, font: ImageFont.ImageFont):
    """Draws comic starburst action popup (e.g. *CLAP CLAP!*)."""
    badge_scale = 1.0 + math.sin(t * 10.0) * 0.12
    bx, by = int(w * 0.82), int(h * 0.28)
    bw = int(140 * badge_scale)

    points = []
    num_spikes = 12
    for i in range(num_spikes * 2):
        r = bw if i % 2 == 0 else int(bw * 0.65)
        rad = (i * (math.pi / num_spikes)) + (t * 2.0)
        points.append((bx + math.cos(rad) * r, by + math.sin(rad) * r))

    draw.polygon(points, fill=(255, 230, 20), outline=(255, 45, 90), width=6)
    draw.text((bx + 3, by + 3), sfx_text, font=font, fill=(0, 0, 0, 255), anchor="mm")
    draw.text((bx, by), sfx_text, font=font, fill=(225, 20, 60), anchor="mm")

def _draw_karaoke_pill(draw: ImageDraw.ImageDraw, text: str, w: int, h: int, t: float, font: ImageFont.ImageFont, anim_pattern: str = ""):
    """Draws bold karaoke pill banner with topic-matched glowing highlight colors."""
    card_y1, card_y2 = h - 180, h - 45
    margin = 120
    draw.rounded_rectangle([margin, card_y1, w - margin, card_y2], radius=28, fill=(15, 25, 50, 220), outline=(255, 255, 255, 240), width=4)

    text_x = w // 2
    text_y = (card_y1 + card_y2) // 2 + int(math.sin(t * 8.0) * 4)

    # Highlight color adapts to animation pattern
    if "bedtime" in anim_pattern:
        highlight_color = (175, 235, 255) # Soft Starlight Cyan
    elif "aquatic" in anim_pattern:
        highlight_color = (100, 245, 220) # Aqua Mint
    elif "dino" in anim_pattern:
        highlight_color = (255, 170, 40) # Amber Orange
    else:
        highlight_color = (255, 235, 40) # Bright Yellow

    draw.text((text_x + 4, text_y + 4), text, font=font, fill=(0, 0, 0, 255), anchor="mm")
    draw.text((text_x, text_y), text, font=font, fill=highlight_color, anchor="mm")

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    sample_script = "JJ: Hello friends! [clap, clap]\nLet's learn our ABCs today!\nA is for Apple, B is for Ball!\nSee you next time on Cocolemon! [bye bye]"
    create_video_animation(sample_script, title="Learn Your ABCs with JJ")
