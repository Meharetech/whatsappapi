import os
import sys
import json
import logging
import argparse
from datetime import datetime
from typing import Dict, Any

# Ensure UTF-8 output on Windows terminals
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

import config
from trend_scraper import get_latest_cocomelon_trend
from script_generator import generate_nursery_rhyme_script
from audio_generator import generate_voiceover_audio
from thumbnail_generator import create_thumbnail
from video_generator import create_video_animation
from youtube_uploader import upload_video_to_youtube

def setup_logger() -> logging.Logger:
    """Configures multi-handler logging to both file and stdout."""
    logger = logging.getLogger("cocolemon_pipeline")
    logger.setLevel(logging.INFO)

    if logger.hasHandlers():
        logger.handlers.clear()

    formatter = logging.Formatter(
        fmt="[%(asctime)s] [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    file_handler = logging.FileHandler(config.LOG_OUTPUT_FILE, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    return logger

def run_pipeline(
    custom_topic: str = None,
    force_fallback: bool = False,
    api_key: str = None,
    elevenlabs_key: str = None,
    voice_id: str = None,
    skip_audio: bool = False,
    render_video: bool = True,
    upload: bool = False,
    privacy: str = config.DEFAULT_YOUTUBE_PRIVACY,
    dry_run: bool = False,
    use_ai_scenes: bool = config.USE_POLLINATIONS_AI,
    tts_engine: str = "auto",
    edge_voice: str = None
) -> Dict[str, Any]:
    """
    Executes the complete end-to-end autonomous video production pipeline:
    1. Trend Scraper & Transcript Extraction (YouTube)
    2. Script Generation (Groq LPU Comedic Storyboard)
    3. Voiceover Synthesis (100% Free edge-tts or ElevenLabs)
    4. Thumbnail Creation (1280x720 PNG with Pollinations AI or Procedural)
    5. Video Rendering (1080p MP4 with MoviePy combining scenes, characters & audio)
    6. YouTube Video & Thumbnail Upload
    """
    logger = setup_logger()
    start_time = datetime.now()
    logger.info("==================================================================")
    logger.info("  🎬 NOT YOUR TYPE - AUTONOMOUS VIDEO PRODUCTION STUDIO 🎬  ")
    logger.info("==================================================================")

    if api_key:
        os.environ["GROQ_API_KEY"] = api_key
    if elevenlabs_key:
        os.environ["ELEVENLABS_API_KEY"] = elevenlabs_key

    # Step 1: RSS Ingestion / Topic Acquisition
    if custom_topic:
        logger.info(f"[Step 1/6] Using custom topic provided via CLI: '{custom_topic}'")
        trend_data = {
            "status": "custom_override",
            "title": custom_topic,
            "theme": f"Animated story inspired by '{custom_topic}' with relatable comedy and narrative beats",
            "video_url": "N/A (Custom Override)",
            "published_at": datetime.now().isoformat(),
            "channel_title": "NOT YOUR TYPE Studio",
            "source": "CLI Manual Override"
        }
    else:
        logger.info("[Step 1/6] Ingesting channel releases & extracting dynamic transcripts...")
        trend_data = get_latest_cocomelon_trend(force_fallback=force_fallback)

    logger.info(f"Target Title : {trend_data.get('title')}")
    logger.info(f"Target Theme : {trend_data.get('theme')}")
    logger.info(f"Data Source  : {trend_data.get('source')}")

    # Step 2: Script Generation (Groq)
    logger.info("[Step 2/6] Generating 2-minute dynamic animated storytelling script with sound cues...")
    script_res = generate_nursery_rhyme_script(
        title=trend_data["title"],
        theme=trend_data["theme"],
        raw_summary=trend_data.get("raw_summary", ""),
        custom_keywords=trend_data.get("keywords", None),
        narrative_context=trend_data.get("narrative_context", None)
    )
    if isinstance(script_res, tuple):
        script_content, gen_metadata = script_res
    elif isinstance(script_res, dict):
        script_content = script_res.get("full_script", "")
        gen_metadata = script_res
    else:
        script_content = str(script_res)
        gen_metadata = {}

    # Save Script
    config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    with open(config.SCRIPT_OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write(script_content)
    logger.info(f"-> Script saved to: {config.SCRIPT_OUTPUT_FILE}")

    # Step 3: Audio Synthesis (edge-tts / ElevenLabs TTS)
    audio_metadata = {}
    if not skip_audio:
        logger.info(f"[Step 3/6] Synthesizing voiceover audio track (TTS Engine: {tts_engine})...")
        chosen_voice = voice_id or config.ELEVENLABS_VOICE_ID
        audio_success, audio_meta = generate_voiceover_audio(
            script_text=script_content,
            output_path=config.AUDIO_OUTPUT_FILE,
            voice_id=chosen_voice,
            api_key=elevenlabs_key,
            engine=tts_engine,
            edge_voice=edge_voice
        )
        audio_metadata = audio_meta
    else:
        logger.info("[Step 3/6] Audio generation skipped per --skip-audio flag.")
        audio_metadata = {"status": "skipped_by_user"}

    # Step 4: Thumbnail Creation
    logger.info(f"[Step 4/6] Generating high-CTR YouTube thumbnail (1280x720, AI: {use_ai_scenes})...")
    thumb_success, thumb_meta = create_thumbnail(
        title=trend_data["title"],
        theme=trend_data.get("theme", ""),
        keywords=trend_data.get("keywords", None),
        output_path=config.THUMBNAIL_OUTPUT_FILE,
        use_ai=use_ai_scenes
    )

    # Step 5: Video Animation Rendering
    video_metadata = {}
    if render_video:
        logger.info(f"[Step 5/6] Rendering 1080p animated MP4 video with synced lyrics & storyboard (AI: {use_ai_scenes})...")
        vid_success, vid_meta = create_video_animation(
            script_text=script_content,
            storyboard=gen_metadata.get("storyboard"),
            audio_path=config.AUDIO_OUTPUT_FILE,
            output_video_path=config.VIDEO_OUTPUT_FILE,
            title=trend_data.get("title", "Cocolemon Song"),
            theme=trend_data.get("theme", "Nursery Rhymes"),
            use_ai_scenes=use_ai_scenes
        )
        video_metadata = vid_meta
    else:
        logger.info("[Step 5/6] Video rendering skipped per flag.")
        video_metadata = {"status": "skipped"}

    # Step 6: YouTube Upload
    upload_metadata = {}
    if upload:
        logger.info("[Step 6/6] Uploading video & thumbnail to YouTube Channel...")
        upload_success, upload_meta = upload_video_to_youtube(
            video_path=config.VIDEO_OUTPUT_FILE,
            thumbnail_path=config.THUMBNAIL_OUTPUT_FILE,
            title=f"Cocolemon - {trend_data['title'][:70]}",
            privacy_status=privacy,
            dry_run=dry_run
        )
        upload_metadata = upload_meta
    else:
        logger.info("[Step 6/6] Auto-upload not triggered. (Use --upload or run.bat option 1 to upload to YouTube).")
        upload_metadata = {"status": "ready_for_upload"}

    # Assemble comprehensive metadata payload
    end_time = datetime.now()
    duration_secs = (end_time - start_time).total_seconds()

    full_payload = {
        "channel_name": "Cocolemon",
        "generated_at": end_time.isoformat(),
        "total_pipeline_duration_seconds": round(duration_secs, 2),
        "source_trend": trend_data,
        "generation_metadata": gen_metadata,
        "audio_metadata": audio_metadata,
        "thumbnail_metadata": thumb_meta,
        "video_metadata": video_metadata,
        "upload_metadata": upload_metadata,
        "output_files": {
            "script_file": str(config.SCRIPT_OUTPUT_FILE),
            "audio_file": str(config.AUDIO_OUTPUT_FILE) if audio_metadata.get("status") == "success" else None,
            "thumbnail_file": str(config.THUMBNAIL_OUTPUT_FILE) if thumb_meta.get("status") == "success" else None,
            "video_file": str(config.VIDEO_OUTPUT_FILE) if video_metadata.get("status") == "success" else None,
            "metadata_file": str(config.METADATA_OUTPUT_FILE),
            "log_file": str(config.LOG_OUTPUT_FILE)
        }
    }

    with open(config.METADATA_OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(full_payload, f, indent=2, ensure_ascii=False)
    logger.info(f"-> Metadata payload saved to: {config.METADATA_OUTPUT_FILE}")

    logger.info("Pipeline execution completed successfully!")
    return full_payload

def main():
    parser = argparse.ArgumentParser(
        description="Autonomous Video Production & MoviePy Combining Studio",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument("--python-movie", "--pyhon-movy", action="store_true", help="Run Python Movie pipeline: Groq Script -> Free edge-tts Audio -> MoviePy 1080p Video Export.")
    parser.add_argument("--tts-engine", type=str, default="auto", choices=["auto", "edge-tts", "elevenlabs"], help="TTS voiceover engine.")
    parser.add_argument("--edge-voice", type=str, default=None, help="Custom voice name for edge-tts (e.g. hi-IN-MadhurNeural, en-US-ChristopherNeural).")
    parser.add_argument("--topic", type=str, default=None, help="Custom topic to bypass channel scraping.")
    parser.add_argument("--force-fallback", action="store_true", help="Force curated toddler fallback topic bank.")
    parser.add_argument("--api-key", type=str, default=None, help="Provide GROQ_API_KEY directly.")
    parser.add_argument("--elevenlabs-key", type=str, default=None, help="Provide ELEVENLABS_API_KEY directly.")
    parser.add_argument("--voice-id", type=str, default=None, help="Override ElevenLabs voice ID.")
    parser.add_argument("--skip-audio", action="store_true", help="Skip ElevenLabs audio generation.")
    parser.add_argument("--no-video", action="store_true", help="Skip MP4 video rendering.")
    parser.add_argument("--upload", action="store_true", help="Upload generated video & thumbnail to YouTube.")
    parser.add_argument("--upload-existing", action="store_true", help="Upload existing video.mp4 & thumbnail.png in output folder without re-rendering.")
    parser.add_argument("--render-existing", action="store_true", help="Render video.mp4 using existing script.txt and voiceover.mp3 in output folder.")
    parser.add_argument("--ai-scenes", action="store_true", default=False, help="Force enable Pollinations AI 3D scene & thumbnail generation.")
    parser.add_argument("--no-ai-scenes", action="store_true", default=False, help="Disable AI scene generation and use offline procedural engine.")
    parser.add_argument("--privacy", type=str, default=config.DEFAULT_YOUTUBE_PRIVACY, choices=["private", "unlisted", "public"], help="YouTube video privacy status.")
    parser.add_argument("--dry-run", action="store_true", help="Simulate YouTube upload without contacting Google servers.")

    args = parser.parse_args()

    use_ai_scenes = False if args.no_ai_scenes else (True if args.ai_scenes else config.USE_POLLINATIONS_AI)

    # Manual Recovery Mode 1: Upload Existing Video Directly
    if args.upload_existing:
        logger = setup_logger()
        logger.info("=== MANUAL ACTION: Uploading Existing Video Assets ===")
        if not config.VIDEO_OUTPUT_FILE.exists():
            logger.error(f"No video found at: {config.VIDEO_OUTPUT_FILE}. Please render video first.")
            return

        title = "Cocolemon Nursery Rhymes & Kids Songs"
        if config.METADATA_OUTPUT_FILE.exists():
            try:
                with open(config.METADATA_OUTPUT_FILE, "r", encoding="utf-8") as f:
                    meta_data = json.load(f)
                    title = f"Cocolemon - {meta_data.get('source_trend', {}).get('title', title)}"
            except Exception:
                pass

        success, res = upload_video_to_youtube(
            video_path=config.VIDEO_OUTPUT_FILE,
            thumbnail_path=config.THUMBNAIL_OUTPUT_FILE if config.THUMBNAIL_OUTPUT_FILE.exists() else None,
            title=title,
            privacy_status=args.privacy,
            dry_run=args.dry_run
        )
        if success:
            print(f"\n[+] Video uploaded successfully: {res.get('video_url')}")
        else:
            print(f"\n[-] Upload status: {res.get('error') or res.get('status')}")
        return

    # Manual Recovery Mode 2: Re-render Video from existing local files
    if args.render_existing:
        logger = setup_logger()
        logger.info(f"=== MANUAL ACTION: Rendering Video From Local Files (AI: {use_ai_scenes}) ===")
        if not config.SCRIPT_OUTPUT_FILE.exists():
            logger.error(f"No script found at: {config.SCRIPT_OUTPUT_FILE}")
            return
        with open(config.SCRIPT_OUTPUT_FILE, "r", encoding="utf-8") as f:
            script_text = f.read()

        title = "Cocolemon Kids Adventure"
        theme = "Nursery Rhymes"
        storyboard = None
        if config.METADATA_OUTPUT_FILE.exists():
            try:
                with open(config.METADATA_OUTPUT_FILE, "r", encoding="utf-8") as f:
                    meta_data = json.load(f)
                    title = meta_data.get("source_trend", {}).get("title", title)
                    theme = meta_data.get("source_trend", {}).get("theme", theme)
                    storyboard = meta_data.get("generation_metadata", {}).get("storyboard")
            except Exception:
                pass

        create_thumbnail(title=title, theme=theme, use_ai=use_ai_scenes)
        create_video_animation(script_text=script_text, storyboard=storyboard, title=title, theme=theme, use_ai_scenes=use_ai_scenes)
        print(f"\n[+] Video rendered successfully: {config.VIDEO_OUTPUT_FILE}")
        return

    tts_engine = "edge-tts" if getattr(args, "python_movie", False) else args.tts_engine

    result = run_pipeline(
        custom_topic=args.topic,
        force_fallback=args.force_fallback,
        api_key=args.api_key,
        elevenlabs_key=args.elevenlabs_key,
        voice_id=args.voice_id,
        skip_audio=args.skip_audio,
        render_video=not args.no_video,
        upload=args.upload,
        privacy=args.privacy,
        dry_run=args.dry_run,
        use_ai_scenes=use_ai_scenes,
        tts_engine=tts_engine,
        edge_voice=args.edge_voice
    )

    # Print clean summary banner
    print("\n" + "=" * 65)
    print("      🍉 COCOLEMON COMPLETE STUDIO RUN SUMMARY 🍉")
    print("=" * 65)
    print(f" Source Title   : {result['source_trend']['title']}")
    print(f" LLM Generator  : {result['generation_metadata'].get('generator')} ({result['generation_metadata'].get('model')})")
    print(f" Audio Status   : {result['audio_metadata'].get('status')}")
    print(f" Thumbnail File : {result['output_files'].get('thumbnail_file')}")
    print(f" Video File     : {result['output_files'].get('video_file')}")
    if result['upload_metadata'].get('video_url'):
        print(f" YouTube Link   : {result['upload_metadata'].get('video_url')}")
    print(f" Output Folder  : {config.OUTPUT_DIR}")
    print("=" * 65 + "\n")

if __name__ == "__main__":
    main()
