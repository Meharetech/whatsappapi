import math
import logging
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageEnhance
from typing import Tuple, Dict, Any, List
import config

logger = logging.getLogger("cocolemon_pipeline")

from scene_generator import fetch_pollinations_scene_image

def create_thumbnail(
    title: str,
    output_path: Path = None,
    width: int = 1280,
    height: int = 720,
    theme: str = "",
    keywords: list = None,
    use_ai: bool = config.USE_POLLINATIONS_AI
) -> Tuple[bool, Dict[str, Any]]:
    """
    Generates a high-CTR kids YouTube thumbnail (1280x720) dynamically tailored
    to the scraped video topic with optional Pollinations AI 3D background generation.
    """
    try:
        if output_path is None or not (isinstance(output_path, Path) or (isinstance(output_path, str) and (str(output_path).endswith(".png") or str(output_path).endswith(".jpg")))):
            if isinstance(output_path, str) and not theme:
                theme = output_path
            output_path = config.THUMBNAIL_OUTPUT_FILE
        else:
            output_path = Path(output_path)

        clean_title = _clean_thumbnail_title(title)
        topic_info = _detect_thumbnail_theme(title, theme, keywords)
        theme_type = topic_info["theme_type"]

        img = None
        if use_ai:
            ai_thumb_prompt = (
                f"3D stylized cartoon YouTube thumbnail, vibrant cinematic lighting, expressive animated characters, "
                f"high contrast, dramatic action scene of {clean_title}, colorful 8k render"
            )
            img = fetch_pollinations_scene_image(ai_thumb_prompt, width=width, height=height)

        # 1. Fallback to procedural background if AI is disabled or fails
        if img is None:
            img = Image.new("RGBA", (width, height), (255, 255, 255, 255))
            draw = ImageDraw.Draw(img)
            # Base Gradient matching Theme Palette
            _draw_theme_gradient(draw, width, height, theme_type)
            # Sunburst / Starburst Background Rays
            _draw_sunburst_overlay(draw, width, height, theme_type)
            # Dynamic Background Theme Elements
            _draw_theme_background_props(draw, width, height, theme_type)
            # Draw Theme Mascot in procedural mode
            _draw_themed_mascot(draw, center_x=310, center_y=420, scale=1.35, theme_type=theme_type)
        else:
            draw = ImageDraw.Draw(img)

        # 2. Dynamic Badges
        channel_label = getattr(config, "TARGET_CHANNEL_NAME", "STUDIO")
        badge_w = max(240, len(channel_label) * 20 + 40)
        _draw_badge(draw, 50, 40, 50 + badge_w, 100, channel_label, bg_color=(255, 55, 115), text_color=(255, 255, 255))
        _draw_badge(draw, 1010, 40, 1230, 100, topic_info["badge_label"], bg_color=topic_info["badge_color"], text_color=(255, 255, 255))

        # 3. Render Bold 3D Main Title Banner on Right
        _draw_3d_text_banner(
            img=img,
            draw=draw,
            text=clean_title,
            x_start=550,
            y_center=390,
            max_width=680,
            theme_type=theme_type
        )

        # 4. Save Final Thumbnail
        output_path.parent.mkdir(parents=True, exist_ok=True)
        img_rgb = img.convert("RGB")
        img_rgb.save(output_path, "PNG", quality=95)
        logger.info(f"-> Topic-matched thumbnail successfully generated for '{theme_type}' (AI: {use_ai}): {output_path}")

        return True, {
            "status": "success",
            "theme_detected": theme_type,
            "file_path": str(output_path),
            "width": width,
            "height": height
        }
    except Exception as e:
        logger.error(f"Error generating dynamic thumbnail: {e}")
        return False, {"status": "error", "error": str(e)}

def _clean_thumbnail_title(title: str) -> str:
    cleaned = title.replace("| NOT YOUR TYPE", "").replace("| CoComelon", "").strip()
    if "|" in cleaned:
        cleaned = cleaned.split("|")[0].strip()
    if "-" in cleaned:
        cleaned = cleaned.split("-")[0].strip()
    # Remove emoji symbols for clean typography
    import re
    cleaned = re.sub(r"[^\w\s\',!&]", "", cleaned).strip()
    return cleaned.upper()

def _detect_thumbnail_theme(title: str, theme: str, keywords: list) -> Dict[str, Any]:
    text = (title + " " + (theme or "") + " " + " ".join(keywords or [])).lower()

    if any(k in text for k in ["cricket", "gully", "match", "sixer", "sport", "game"]):
        return {"theme_type": "sports", "badge_label": "GULLY CRICKET", "badge_color": (255, 60, 40)}
    elif any(k in text for k in ["school", "college", "exam", "teacher", "hostel", "class", "holidays", "summer"]):
        return {"theme_type": "school", "badge_label": "SCHOOL LIFE", "badge_color": (0, 165, 240)}
    elif any(k in text for k in ["kolkata", "mumbai", "delhi", "trip", "travel", "city", "tour", "train"]):
        return {"theme_type": "travel", "badge_label": "CITY TRIP", "badge_color": (255, 140, 0)}
    elif any(k in text for k in ["horror", "ghost", "bhoot", "spooky", "haunted"]):
        return {"theme_type": "horror", "badge_label": "HORROR VLOG", "badge_color": (150, 40, 220)}
    elif any(k in text for k in ["abc", "letter", "alphabet", "learn", "reading"]):
        return {"theme_type": "classroom", "badge_label": "ABC & 123", "badge_color": (255, 180, 0)}
    elif any(k in text for k in ["bus", "car", "vehicle", "truck", "tractor", "drive", "road", "vroom"]):
        return {"theme_type": "vehicles", "badge_label": "VROOM VROOM", "badge_color": (255, 140, 0)}
    elif any(k in text for k in ["bath", "bubble", "wash", "splash", "soap", "clean", "water"]):
        return {"theme_type": "bath", "badge_label": "BATH TIME", "badge_color": (0, 195, 255)}
    elif any(k in text for k in ["bedtime", "sleep", "star", "night", "moon", "lullaby", "dream"]):
        return {"theme_type": "bedtime", "badge_label": "LULLABY", "badge_color": (150, 80, 240)}
    elif any(k in text for k in ["shark", "ocean", "sea", "fish", "underwater"]):
        return {"theme_type": "ocean", "badge_label": "BABY SHARK", "badge_color": (0, 180, 220)}
    elif any(k in text for k in ["eat", "fruit", "veggie", "yummy", "food", "kitchen", "cook"]):
        return {"theme_type": "food", "badge_label": "YUMMY FOOD", "badge_color": (255, 95, 30)}
    elif any(k in text for k in ["dino", "dinosaur", "rex", "prehistoric", "jungle"]):
        return {"theme_type": "dino", "badge_label": "DINO ROAR", "badge_color": (80, 200, 60)}
    elif any(k in text for k in ["doctor", "checkup", "hospital", "boo boo", "bandaid"]):
        return {"theme_type": "doctor", "badge_label": "BE HEALTHY", "badge_color": (255, 60, 90)}
    else:
        return {"theme_type": "party", "badge_label": "STORY TIME", "badge_color": (255, 195, 0)}

# -----------------------------------------------------------------------------
# DYNAMIC BACKGROUND GRADIENTS & RAYS
# -----------------------------------------------------------------------------
def _draw_theme_gradient(draw: ImageDraw.ImageDraw, w: int, h: int, theme: str):
    if theme == "bedtime": # Deep indigo/purple to night sky
        for y in range(h):
            ratio = y / h
            r = int(25 + ratio * 35)
            g = int(20 + ratio * 30)
            b = int(80 + ratio * 80)
            draw.line([(0, y), (w, y)], fill=(r, g, b, 255))
    elif theme == "ocean": # Deep aqua to bright turquoise
        for y in range(h):
            ratio = y / h
            r = int(10 + ratio * 30)
            g = int(120 + ratio * 70)
            b = int(230 - ratio * 40)
            draw.line([(0, y), (w, y)], fill=(r, g, b, 255))
    elif theme == "bath": # Fresh cyan and mint
        for y in range(h):
            ratio = y / h
            r = int(80 + ratio * 100)
            g = int(210 - ratio * 30)
            b = int(255 - ratio * 20)
            draw.line([(0, y), (w, y)], fill=(r, g, b, 255))
    elif theme == "classroom" or theme == "vehicles": # Bright sunny cyan/yellow
        for y in range(h):
            ratio = y / h
            r = int(70 + ratio * 185)
            g = int(190 - ratio * 60)
            b = int(240 - ratio * 90)
            draw.line([(0, y), (w, y)], fill=(r, g, b, 255))
    elif theme == "dino" or theme == "animals": # Sunny lime and amber
        for y in range(h):
            ratio = y / h
            r = int(80 + ratio * 140)
            g = int(200 - ratio * 30)
            b = int(220 - ratio * 140)
            draw.line([(0, y), (w, y)], fill=(r, g, b, 255))
    else: # Radiant sunset magenta/gold
        for y in range(h):
            ratio = y / h
            r = int(255 - ratio * 40)
            g = int(130 + ratio * 80)
            b = int(190 - ratio * 120)
            draw.line([(0, y), (w, y)], fill=(r, g, b, 255))

def _draw_sunburst_overlay(draw: ImageDraw.ImageDraw, width: int, height: int, theme: str):
    center_x, center_y = width // 2, height // 2
    ray_count = 18
    alpha = 30 if theme != "bedtime" else 15
    for i in range(ray_count):
        angle1 = (i * (360 / ray_count)) * (math.pi / 180)
        angle2 = ((i + 0.5) * (360 / ray_count)) * (math.pi / 180)
        p1 = (center_x, center_y)
        p2 = (center_x + math.cos(angle1) * 1500, center_y + math.sin(angle1) * 1500)
        p3 = (center_x + math.cos(angle2) * 1500, center_y + math.sin(angle2) * 1500)
        draw.polygon([p1, p2, p3], fill=(255, 255, 255, alpha))

# -----------------------------------------------------------------------------
# DYNAMIC BACKGROUND PROPS MATCHING THEME
# -----------------------------------------------------------------------------
def _draw_theme_background_props(draw: ImageDraw.ImageDraw, w: int, h: int, theme: str):
    try:
        font_lg = ImageFont.truetype("arialbd.ttf", 72)
    except Exception:
        font_lg = ImageFont.load_default()

    if theme == "classroom": # Floating 3D ABC Blocks & Chalkboard Element
        # Block 'A'
        draw.rounded_rectangle([70, 130, 180, 240], radius=16, fill=(255, 65, 95), outline=(255, 255, 255), width=5)
        draw.text((125, 185), "A", font=font_lg, fill=(255, 255, 255), anchor="mm")
        # Block 'B'
        draw.rounded_rectangle([490, 110, 590, 210], radius=14, fill=(45, 185, 255), outline=(255, 255, 255), width=4)
        draw.text((540, 160), "B", font=font_lg, fill=(255, 255, 255), anchor="mm")
        # Block 'C'
        draw.rounded_rectangle([1120, 140, 1220, 240], radius=14, fill=(255, 215, 30), outline=(255, 255, 255), width=4)
        draw.text((1170, 190), "C", font=font_lg, fill=(30, 30, 30), anchor="mm")
        # 123 Block on bottom
        draw.rounded_rectangle([1100, 560, 1210, 670], radius=14, fill=(120, 230, 80), outline=(255, 255, 255), width=4)
        draw.text((1155, 615), "1", font=font_lg, fill=(255, 255, 255), anchor="mm")

    elif theme == "vehicles": # Cartoon City Skyline & Yellow School Bus
        # Yellow Bus on Left Background
        draw.rounded_rectangle([40, 160, 240, 290], radius=18, fill=(255, 215, 0), outline=(210, 160, 0), width=5)
        draw.rounded_rectangle([70, 185, 140, 230], radius=6, fill=(185, 235, 255), outline=(255, 255, 255), width=3)
        draw.rounded_rectangle([155, 185, 215, 230], radius=6, fill=(185, 235, 255), outline=(255, 255, 255), width=3)
        draw.ellipse([65, 270, 105, 310], fill=(30, 30, 30), outline=(255, 255, 255), width=3)
        draw.ellipse([175, 270, 215, 310], fill=(30, 30, 30), outline=(255, 255, 255), width=3)

    elif theme == "bath": # Giant Shimmering Soap Bubbles & Rubber Duck
        # Rubber Duck on Top Right
        _draw_mini_rubber_duck(draw, 1140, 200, scale=1.4)
        # Giant Soap Bubbles
        for bx, by, br in [(120, 200, 55), (510, 140, 45), (1070, 600, 60), (220, 620, 50)]:
            draw.ellipse([bx - br, by - br, bx + br, by + br], fill=(255, 255, 255, 100), outline=(255, 255, 255, 220), width=4)
            draw.ellipse([bx - br // 2, by - br // 2, bx - br // 4, by - br // 4], fill=(255, 255, 255, 240))

    elif theme == "bedtime": # Huge Glowing Crescent Moon & Twinkling Golden Stars
        # Crescent Moon
        moon_x, moon_y = 1140, 190
        draw.ellipse([moon_x - 65, moon_y - 65, moon_x + 65, moon_y + 65], fill=(255, 235, 60))
        draw.ellipse([moon_x - 35, moon_y - 75, moon_x + 75, moon_y + 45], fill=(35, 30, 90)) # Cutout
        # Glowing Stars
        for sx, sy, sr in [(110, 170, 26), (510, 130, 30), (1050, 580, 24), (200, 610, 22)]:
            draw.polygon([
                (sx, sy - sr), (sx + sr // 3, sy - sr // 3),
                (sx + sr, sy), (sx + sr // 3, sy + sr // 3),
                (sx, sy + sr), (sx - sr // 3, sy + sr // 3),
                (sx - sr, sy), (sx - sr // 3, sy - sr // 3)
            ], fill=(255, 240, 110))

    elif theme == "ocean": # Baby Shark & Sea Bubbles
        for bx, by, br in [(110, 180, 40), (520, 130, 45), (1140, 200, 50), (1080, 600, 55)]:
            draw.ellipse([bx - br, by - br, bx + br, by + br], fill=(255, 255, 255, 110), outline=(255, 255, 255, 220), width=4)

    elif theme == "food": # Giant Shiny Apples & Fruits
        ax, ay = 1140, 200
        draw.ellipse([ax - 45, ay - 45, ax + 45, ay + 45], fill=(255, 45, 65), outline=(255, 255, 255), width=4)
        draw.rectangle([ax - 4, ay - 60, ax + 4, ay - 40], fill=(110, 65, 30))
        draw.ellipse([ax + 4, ay - 65, ax + 28, ay - 47], fill=(60, 185, 75))

    elif theme == "animals": # Red Barn Hill
        draw.ellipse([980, 130, 1220, 270], fill=(225, 45, 45), outline=(255, 255, 255), width=4)
        draw.polygon([(970, 140), (1100, 80), (1230, 140)], fill=(255, 255, 255), outline=(200, 200, 200), width=4)

    else: # Floating Shiny Bubbles & Sparkles
        decorations = [
            (100, 200, 28, (255, 220, 0)),
            (500, 130, 32, (255, 100, 200)),
            (1150, 220, 38, (255, 230, 50)),
            (1050, 590, 40, (100, 230, 255)),
            (190, 610, 30, (255, 180, 50)),
        ]
        for x, y, r, color in decorations:
            draw.ellipse([x - r, y - r, x + r, y + r], fill=color, outline=(255, 255, 255), width=3)
            draw.ellipse([x - r // 2, y - r // 2, x - r // 4, y - r // 4], fill=(255, 255, 255, 220))

# -----------------------------------------------------------------------------
# THEMED MASCOT & COSTUMES
# -----------------------------------------------------------------------------
def _draw_themed_mascot(draw: ImageDraw.ImageDraw, center_x: int, center_y: int, scale: float, theme_type: str):
    """Draws JJ Watermelon Mascot customized with topic-specific hats, costumes, and props."""
    w = int(180 * scale)
    h = int(170 * scale)

    # Outer Green Rind
    draw.ellipse([center_x - w, center_y - h, center_x + w, center_y + h], fill=(68, 190, 78), outline=(30, 120, 40), width=7)

    # Green stripes
    for offset_x in [-w + 30, -w // 2, 0, w // 2, w - 30]:
        draw.arc([center_x + offset_x - 15, center_y - h + 10, center_x + offset_x + 15, center_y + h - 10], 0, 360, fill=(38, 140, 48), width=9)

    # Pink Face Circle
    fw, fh = int(w * 0.78), int(h * 0.78)
    draw.ellipse([center_x - fw, center_y - fh + 10, center_x + fw, center_y + fh + 10], fill=(255, 105, 135), outline=(255, 255, 255), width=5)

    # Big Shiny Cartoon Eyes
    eye_offset = int(45 * scale)
    eye_r = int(18 * scale)
    draw.ellipse([center_x - eye_offset - eye_r, center_y - 20 - eye_r, center_x - eye_offset + eye_r, center_y - 20 + eye_r], fill=(30, 30, 30))
    draw.ellipse([center_x - eye_offset - 6, center_y - 28, center_x - eye_offset + 8, center_y - 14], fill=(255, 255, 255))
    draw.ellipse([center_x + eye_offset - eye_r, center_y - 20 - eye_r, center_x + eye_offset + eye_r, center_y - 20 + eye_r], fill=(30, 30, 30))
    draw.ellipse([center_x + eye_offset - 6, center_y - 28, center_x + eye_offset + 8, center_y - 14], fill=(255, 255, 255))

    # Rosy Cheeks
    draw.ellipse([center_x - eye_offset - 25, center_y + 10, center_x - eye_offset + 15, center_y + 40], fill=(255, 60, 100, 180))
    draw.ellipse([center_x + eye_offset - 15, center_y + 10, center_x + eye_offset + 25, center_y + 40], fill=(255, 60, 100, 180))

    # Big Happy Smile
    draw.arc([center_x - 40, center_y - 5, center_x + 40, center_y + 55], 10, 170, fill=(40, 20, 20), width=6)

    # Antennae
    draw.line([(center_x - 20, center_y - h), (center_x - 45, center_y - h - 45)], fill=(40, 40, 40), width=5)
    draw.ellipse([center_x - 55, center_y - h - 55, center_x - 35, center_y - h - 35], fill=(255, 40, 40), outline=(20, 20, 20), width=2)
    draw.line([(center_x + 20, center_y - h), (center_x + 45, center_y - h - 45)], fill=(40, 40, 40), width=5)
    draw.ellipse([center_x + 35, center_y - h - 55, center_x + 55, center_y - h - 35], fill=(255, 40, 40), outline=(20, 20, 20), width=2)

    # --- TOPIC SPECIFIC ACCESSORIES & HATS ---
    if theme_type == "bedtime": # Starry Nightcap
        draw.polygon([(center_x - 60, center_y - h + 25), (center_x + 60, center_y - h + 25), (center_x + 130, center_y - h + 90)], fill=(55, 85, 175), outline=(255, 255, 255), width=4)
        draw.ellipse([center_x + 115, center_y - h + 75, center_x + 145, center_y - h + 105], fill=(255, 235, 80))
    elif theme_type == "bath": # Soap Foam Shampoo Hat & Rubber Duck
        for fx in [-50, -20, 20, 50]:
            draw.ellipse([center_x + fx - 25, center_y - h - 15, center_x + fx + 25, center_y - h + 25], fill=(255, 255, 255, 240), outline=(210, 240, 255), width=3)
        _draw_mini_rubber_duck(draw, center_x + 130, center_y + 80, scale=1.1)
    elif theme_type == "classroom": # Big Colorful ABC Pencil in Hand
        px, py = center_x + 130, center_y - 20
        draw.rectangle([px - 14, py - 60, px + 14, py + 60], fill=(255, 215, 30), outline=(30, 30, 30), width=3)
        draw.polygon([(px - 14, py - 60), (px + 14, py - 60), (px, py - 95)], fill=(255, 180, 140), outline=(30, 30, 30), width=3)
        draw.polygon([(px - 6, py - 80), (px + 6, py - 80), (px, py - 95)], fill=(30, 30, 30))
    elif theme_type == "food": # Holding Big Juicy Apple
        ax, ay = center_x + 120, center_y + 30
        draw.ellipse([ax - 40, ay - 40, ax + 40, ay + 40], fill=(255, 45, 65), outline=(255, 255, 255), width=4)

def _draw_mini_rubber_duck(draw: ImageDraw.ImageDraw, cx: int, cy: int, scale: float = 1.0):
    w, h = int(50 * scale), int(40 * scale)
    draw.ellipse([cx - w, cy - h, cx + w, cy + h], fill=(255, 220, 25), outline=(210, 160, 10), width=4)
    head_x, head_y = cx - int(25 * scale), cy - int(25 * scale)
    draw.ellipse([head_x - 20, head_y - 20, head_x + 20, head_y + 20], fill=(255, 225, 30), outline=(210, 160, 10), width=3)
    draw.polygon([(head_x - 15, head_y), (head_x - 38, head_y + 5), (head_x - 15, head_y + 12)], fill=(255, 130, 20))

def _get_unicode_font(sz: int, bold: bool = True) -> ImageFont.ImageFont:
    for fn in (["NirmalaB.ttf", "segoeuib.ttf", "arialbd.ttf"] if bold else ["Nirmala.ttf", "segoeui.ttf", "arial.ttf"]):
        try:
            return ImageFont.truetype(fn, sz)
        except Exception:
            continue
    return ImageFont.load_default()

def _draw_badge(draw: ImageDraw.ImageDraw, x1: int, y1: int, x2: int, y2: int, text: str, bg_color, text_color):
    draw.rounded_rectangle([x1, y1, x2, y2], radius=18, fill=bg_color, outline=(255, 255, 255), width=4)
    font = _get_unicode_font(26, bold=True)
    draw.text(((x1 + x2) // 2, (y1 + y2) // 2), text, font=font, fill=text_color, anchor="mm")

# -----------------------------------------------------------------------------
# 3D HIGH-CTR TYPOGRAPHY BANNER
# -----------------------------------------------------------------------------
def _draw_3d_text_banner(img: Image.Image, draw: ImageDraw.ImageDraw, text: str, x_start: int, y_center: int, max_width: int, theme_type: str):
    words = text.split()
    lines = []
    curr = []
    for word in words:
        curr.append(word)
        if len(" ".join(curr)) > 14:
            lines.append(" ".join(curr))
            curr = []
    if curr:
        lines.append(" ".join(curr))

    if not lines:
        lines = [text]

    font_size = 64 if len(lines) <= 2 else 52
    font = _get_unicode_font(font_size, bold=True)

    line_spacing = font_size + 24
    start_y = y_center - (len(lines) * line_spacing) // 2

    # Theme colors for typography
    primary_color = (255, 235, 30) # Golden Yellow
    if theme_type == "bedtime":
        secondary_color = (160, 220, 255) # Soft Starlight Blue
    elif theme_type == "bath" or theme_type == "ocean":
        secondary_color = (255, 130, 210) # Bright Bubble Pink
    elif theme_type == "dino" or theme_type == "animals":
        secondary_color = (255, 140, 50) # Vibrant Orange
    else:
        secondary_color = (255, 100, 180) # Magenta Pink

    for idx, line in enumerate(lines):
        y = start_y + idx * line_spacing
        x = x_start + (max_width // 2)

        # 3D Deep Extrusion Shadows
        for shadow_offset in range(12, 0, -2):
            draw.text((x + shadow_offset, y + shadow_offset), line, font=font, fill=(15, 15, 45, 255), anchor="mm")

        # Crisp High-Contrast White Outlines
        for ox in [-5, -3, 0, 3, 5]:
            for oy in [-5, -3, 0, 3, 5]:
                draw.text((x + ox, y + oy), line, font=font, fill=(255, 255, 255), anchor="mm")

        # Main Vibrant Text Fill
        fill_color = primary_color if idx % 2 == 0 else secondary_color
        draw.text((x, y), line, font=font, fill=fill_color, anchor="mm")

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    create_thumbnail(
        title="Learn Your ABCs with JJ and Bella! | CoComelon Nursery Rhymes",
        theme="Toddler ABC learning and letter signs",
        keywords=["abc", "learn", "letters"]
    )
