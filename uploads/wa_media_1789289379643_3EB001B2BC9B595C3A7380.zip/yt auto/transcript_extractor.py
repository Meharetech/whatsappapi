import sys
import logging
import re
from typing import Dict, Any, List, Optional
import requests

# Ensure UTF-8 output
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

logger = logging.getLogger("cocolemon_pipeline")

def extract_video_transcript(video_id: str, languages: List[str] = None) -> Dict[str, Any]:
    """
    Extracts timestamped captions and dialogue from a YouTube video ID.
    Supports Hindi ('hi'), English ('en', 'en-IN'), Hinglish, and auto-generated transcripts.
    Returns structured data with full text, chronological scene chunks, and key dialogues.
    """
    if not languages:
        languages = ["hi", "en", "en-IN", "hi-Latn"]

    raw_snippets = []
    language_used = None

    try:
        from youtube_transcript_api import YouTubeTranscriptApi
        ytt = YouTubeTranscriptApi()

        # Try direct fetch with language preferences
        try:
            ts = ytt.fetch(video_id, languages=languages)
            raw_snippets = ts.snippets if hasattr(ts, "snippets") else list(ts)
            language_used = "preferred_languages"
        except Exception:
            # Fallback to listing all available transcripts (including auto-generated)
            try:
                transcript_list = ytt.list(video_id)
                for tr in transcript_list:
                    raw_snippets = tr.fetch()
                    language_used = getattr(tr, "language_code", "auto")
                    break
            except Exception as e_list:
                logger.warning(f"Could not fetch transcript via YouTubeTranscriptApi for video {video_id}: {e_list}")

    except ImportError:
        logger.warning("youtube-transcript-api is not installed. Will use watch page metadata fallback.")

    # Process and structure snippets if available
    if raw_snippets:
        structured_transcript = _process_transcript_snippets(raw_snippets)
        structured_transcript["status"] = "success"
        structured_transcript["language"] = language_used
        logger.info(f"Successfully extracted {len(raw_snippets)} transcript snippets ({len(structured_transcript['scene_chunks'])} scene chunks) for video: {video_id}")
        return structured_transcript
    else:
        logger.info(f"No direct transcript found for {video_id}. Generating fallback narrative cues from metadata.")
        return {
            "status": "unavailable",
            "full_text": "",
            "key_dialogues": [],
            "scene_chunks": [],
            "total_snippets": 0
        }

def _process_transcript_snippets(snippets: list) -> Dict[str, Any]:
    """Groups raw transcript entries into chronological scene intervals and cleans text."""
    clean_lines = []
    all_words = []

    for s in snippets:
        text = getattr(s, "text", "") if hasattr(s, "text") else s.get("text", "")
        start = getattr(s, "start", 0.0) if hasattr(s, "start") else s.get("start", 0.0)
        dur = getattr(s, "duration", 0.0) if hasattr(s, "duration") else s.get("duration", 0.0)

        # Clean music brackets like [Music], [Applause] but preserve real text
        cleaned_text = re.sub(r'\[.*?\]', '', text).strip()
        if cleaned_text:
            clean_lines.append({
                "start": round(float(start), 1),
                "duration": round(float(dur), 1),
                "end": round(float(start + dur), 1),
                "text": cleaned_text
            })
            all_words.extend(cleaned_text.split())

    if not clean_lines:
        return {"full_text": "", "key_dialogues": [], "scene_chunks": [], "total_snippets": 0}

    total_duration = clean_lines[-1]["end"]
    num_chunks = 6
    chunk_time = max(10.0, total_duration / num_chunks)

    scene_chunks = []
    for i in range(num_chunks):
        chunk_start = i * chunk_time
        chunk_end = (i + 1) * chunk_time
        lines_in_chunk = [
            l["text"] for l in clean_lines
            if (l["start"] >= chunk_start and l["start"] < chunk_end)
        ]
        chunk_summary = " ".join(lines_in_chunk[:6]) if lines_in_chunk else "Action and dialogue progression"
        scene_chunks.append({
            "beat_index": i + 1,
            "time_window": f"{int(chunk_start)}s - {int(chunk_end)}s",
            "dialogue_snippet": chunk_summary[:350]
        })

    full_text = " ".join(l["text"] for l in clean_lines)
    # Pick distinct key dialogue lines across the timeline
    sample_interval = max(1, len(clean_lines) // 8)
    key_dialogues = [clean_lines[i]["text"] for i in range(0, len(clean_lines), sample_interval)][:8]

    return {
        "full_text": full_text[:4000], # Cap for prompt safety
        "total_words": len(all_words),
        "total_snippets": len(clean_lines),
        "total_duration_seconds": round(total_duration, 1),
        "key_dialogues": key_dialogues,
        "scene_chunks": scene_chunks
    }

def extract_video_narrative_context(
    video_id: str,
    title: str,
    raw_summary: str = "",
    tags: List[str] = None
) -> Dict[str, Any]:
    """
    Constructs rich dynamic context combining video transcript, tags, and multi-segment cues
    for direct injection into LLM prompts.
    """
    transcript_data = extract_video_transcript(video_id)

    # If transcript is unavailable, generate chronological cues from title segments and tags
    if transcript_data["status"] != "success" or not transcript_data.get("scene_chunks"):
        from trend_scraper import _extract_keywords_from_title
        keywords = tags or _extract_keywords_from_title(title)
        scene_chunks = []
        for i in range(6):
            topic_hint = keywords[i % len(keywords)] if keywords else title
            scene_chunks.append({
                "beat_index": i + 1,
                "time_window": f"Scene Beat {i + 1}",
                "dialogue_snippet": f"Humorous situations and story progression around '{topic_hint}'"
            })
        transcript_data["scene_chunks"] = scene_chunks
        transcript_data["key_dialogues"] = keywords

    # Format structured text block for prompt injection
    chunks_formatted = "\n".join([
        f"- Scene {c['beat_index']} ({c['time_window']}): {c['dialogue_snippet']}"
        for c in transcript_data["scene_chunks"]
    ])

    return {
        "video_id": video_id,
        "title": title,
        "tags": tags or [],
        "transcript_status": transcript_data["status"],
        "total_duration": transcript_data.get("total_duration_seconds", 120),
        "key_dialogues": transcript_data.get("key_dialogues", []),
        "scene_chunks": transcript_data.get("scene_chunks", []),
        "formatted_scene_cues": chunks_formatted,
        "full_transcript_summary": transcript_data.get("full_text", raw_summary)[:1500]
    }

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    context = extract_video_narrative_context(
        video_id="Znzy-1S7Ufw",
        title="Indian Schools , Gully Cricket & Summer Holidays"
    )
    print("\n=== Extracted Narrative Context ===")
    print(f"Status: {context['transcript_status']}")
    print(f"Key Dialogues: {context['key_dialogues'][:3]}")
    print("\nFormatted Scene Cues:")
    print(context["formatted_scene_cues"])
