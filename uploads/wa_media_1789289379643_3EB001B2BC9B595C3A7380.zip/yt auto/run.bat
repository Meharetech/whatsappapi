@echo off
title NOT YOUR TYPE - Autonomous Video Production Studio
color 0B

:menu
cls
echo =======================================================================
echo     🎬 NOT YOUR TYPE - AUTONOMOUS YOUTUBE PRODUCTION STUDIO 🎬
echo =======================================================================
echo.
echo  --- GRAPHICAL USER INTERFACES ---
echo  [0] LAUNCH DESKTOP STUDIO GUI (CustomTkinter Modern Dark UI)
echo  [W] LAUNCH WEB STUDIO DASHBOARD (Browser-based Studio Control)
echo.
echo  --- 🚀 PYTHON MOVIE (NEW 100%% FREE AUTOMATION) ---
echo  [P] PYTHON MOVIE: Grok/Groq Script -^> Free edge-tts -^> MoviePy 1080p Video Export
echo      (100%% Free Pipeline: Groq Storyboard + Free Neural Audio + 1080p Video Export)
echo.
echo  --- AI AUTOMATED WORKFLOWS ---
echo  [1] FULL STUDIO + AUTO-UPLOAD TO YOUTUBE (Pollinations AI Scenes)
echo      (Scrape Channel -^> Groq Script -^> ElevenLabs/edge-tts -^> Render -^> Upload)
echo.
echo  [2] FULL STUDIO WITH POLLINATIONS AI (Local 1080p MP4 + 3D Thumbnail)
echo      (Renders 1080p dynamic scenes locally - Ready to review)
echo.
echo  [3] PROCEDURAL FAST STUDIO (Offline / Fast Mode - No AI downloads)
echo      (Uses ultra-fast procedural vector animations and lighting)
echo.
echo  [4] CUSTOM TOPIC PRODUCTION (with Pollinations AI Scenes)
echo      (Enter any topic e.g. "College Canteen Drama", "Board Exam Panic")
echo.
echo  [5] FAST MODE: Script + Voiceover Audio Only (Skip video render)
echo.
echo  --- MANUAL TOOLS ^& RECOVERY ---
echo  [6] UPLOAD EXISTING VIDEO (Uploads existing video.mp4 ^& thumbnail.png)
echo.
echo  [7] RE-RENDER VIDEO FROM LOCAL FILES (Uses existing script.txt ^& voiceover.mp3)
echo.
echo  [8] 1-TIME YOUTUBE CHANNEL LOGIN (Authorize channel in browser)
echo.
echo  [9] OPEN OUTPUT FOLDER (cocolemon_output)
echo.
echo  [10] EXIT
echo.
echo =======================================================================
set /p choice="Select an option [0-10, P, W] (default is P): "

if "%choice%"=="" set choice=P
if /i "%choice%"=="P" goto run_python_movie
if "%choice%"=="0" goto run_desktop_gui
if /i "%choice%"=="W" goto run_web_gui
if "%choice%"=="1" goto run_upload_ai
if "%choice%"=="2" goto run_local_studio_ai
if "%choice%"=="3" goto run_procedural_fast
if "%choice%"=="4" goto run_custom_ai
if "%choice%"=="5" goto run_audio_only
if "%choice%"=="6" goto run_upload_existing
if "%choice%"=="7" goto run_render_existing
if "%choice%"=="8" goto auth_youtube
if "%choice%"=="9" goto open_folder
if "%choice%"=="10" goto end

:run_python_movie
echo.
echo =======================================================================
echo [*] LAUNCHING PYTHON MOVIE PIPELINE
echo     1. Scrape Channel / Topic
echo     2. Groq LPU Script ^& 6-Scene Storyboard
echo     3. 100%% Free Microsoft edge-tts Voiceover Synthesis
echo     4. MoviePy / FFmpeg 1080p Video ^& Subtitle Export
echo =======================================================================
echo.
set /p custom_topic="Enter custom topic or press ENTER to scrape latest channel trend: "
if "%custom_topic%"=="" (
    python main.py --python-movie --ai-scenes
) else (
    python main.py --python-movie --topic "%custom_topic%" --ai-scenes
)
goto finish

:run_desktop_gui
echo.
echo [*] Launching Desktop Studio GUI...
start "" "launch_gui.bat"
goto finish

:run_web_gui
echo.
echo [*] Starting Web Studio Dashboard on http://localhost:5000...
start "" "http://localhost:5000"
python web_gui.py
goto finish

:run_upload_ai
echo.
echo [*] Launching Full Pipeline with Pollinations AI and YouTube Upload...
python main.py --ai-scenes --upload
goto finish

:run_local_studio_ai
echo.
echo [*] Launching Local Studio with Pollinations AI Scenes + Thumbnail...
python main.py --ai-scenes
goto finish

:run_procedural_fast
echo.
echo [*] Launching Fast Procedural Studio (Offline / Fast Mode)...
python main.py --no-ai-scenes
goto finish

:run_custom_ai
echo.
echo.
set /p custom_topic="Enter your custom topic or video title: "
echo [*] Running Pollinations AI production for: "%custom_topic%"...
python main.py --topic "%custom_topic%" --ai-scenes --upload
goto finish

:run_audio_only
echo.
echo [*] Running fast mode (Script + Audio only, skipping video render)...
python main.py --no-video
goto finish

:run_upload_existing
echo.
echo [*] Uploading existing video.mp4 and thumbnail.png to YouTube...
python main.py --upload-existing
goto finish

:run_render_existing
echo.
echo [*] Re-rendering 1080p video from existing script.txt and voiceover.mp3...
python main.py --render-existing
goto finish

:auth_youtube
echo.
echo [*] Launching 1-Time YouTube Authorization in your web browser...
python youtube_uploader.py
goto finish

:open_folder
echo.
echo [*] Opening cocolemon_output folder...
if not exist "cocolemon_output" mkdir cocolemon_output
start "" "cocolemon_output"
goto finish

:finish
echo.
echo =======================================================================
echo Studio action finished.
echo =======================================================================
echo.
pause
goto menu

:end
