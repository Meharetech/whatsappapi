import os
import sys
import json
import logging
import threading
import queue
import time
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
from PIL import Image, ImageTk

# Ensure UTF-8 output
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

import customtkinter as ctk

# Workspace imports
import config
from trend_scraper import get_latest_channel_trend
from transcript_extractor import extract_video_narrative_context
from script_generator import generate_animated_video_script
from audio_generator import generate_voiceover_audio
from scene_generator import generate_scene_artworks
from thumbnail_generator import create_thumbnail
from video_generator import create_video_animation
from youtube_uploader import upload_video_to_youtube

# Set Theme
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

class QueueLogHandler(logging.Handler):
    """Directs logging records to a thread-safe queue for the GUI console."""
    def __init__(self, log_queue: queue.Queue):
        super().__init__()
        self.log_queue = log_queue

    def emit(self, record):
        msg = self.format(record)
        self.log_queue.put(msg)

class AutonomousStudioApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("NOT YOUR TYPE - Autonomous Video Production Studio")
        self.geometry("1280x820")
        self.minsize(1080, 700)

        # State Variables
        self.current_trend: Optional[Dict[str, Any]] = None
        self.current_storyboard: Optional[List[Dict[str, Any]]] = None
        self.current_script: str = ""
        self.log_queue = queue.Queue()
        self.is_running = False

        # Configure Logging to GUI
        self._setup_logging()

        # Build UI Layout
        self._build_sidebar()
        self._build_main_panel()

        # Start Log Poller
        self.after(100, self._poll_log_queue)

        # Initial Load of existing assets if present
        self.after(300, self._load_existing_output_assets)

    def _setup_logging(self):
        logger = logging.getLogger("cocolemon_pipeline")
        logger.setLevel(logging.INFO)
        gui_handler = QueueLogHandler(self.log_queue)
        gui_handler.setFormatter(logging.Formatter("[%(asctime)s] %(message)s", "%H:%M:%S"))
        logger.addHandler(gui_handler)

    def _build_sidebar(self):
        # Sidebar Frame
        self.sidebar = ctk.CTkFrame(self, width=280, corner_radius=0)
        self.sidebar.pack(side="left", fill="y", padx=0, pady=0)
        self.sidebar.pack_propagate(False)

        # Header Title
        title_lbl = ctk.CTkLabel(
            self.sidebar,
            text="🎬 STUDIO CONTROL",
            font=ctk.CTkFont(size=20, weight="bold"),
            text_color="#FF4B72"
        )
        title_lbl.pack(padx=20, pady=(20, 10))

        subtitle_lbl = ctk.CTkLabel(
            self.sidebar,
            text="Autonomous AI Video Production",
            font=ctk.CTkFont(size=12),
            text_color="#9AA0A6"
        )
        subtitle_lbl.pack(padx=20, pady=(0, 20))

        # Channel & Topic Inputs
        ctk.CTkLabel(self.sidebar, text="Target YouTube Handle:", font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w", padx=20, pady=(5, 2))
        self.channel_entry = ctk.CTkEntry(self.sidebar, placeholder_text="@NOTYOURTYPE")
        self.channel_entry.insert(0, getattr(config, "TARGET_CHANNEL_HANDLE", "@NOTYOURTYPE"))
        self.channel_entry.pack(fill="x", padx=20, pady=(0, 10))

        ctk.CTkLabel(self.sidebar, text="Custom Topic Override (Optional):", font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w", padx=20, pady=(5, 2))
        self.topic_entry = ctk.CTkEntry(self.sidebar, placeholder_text="Leave blank to auto-scrape channel")
        self.topic_entry.pack(fill="x", padx=20, pady=(0, 15))

        # AI Toggle
        self.ai_scenes_var = ctk.BooleanVar(value=config.USE_POLLINATIONS_AI)
        self.ai_scenes_switch = ctk.CTkSwitch(
            self.sidebar,
            text="Pollinations AI (3D Scenes)",
            variable=self.ai_scenes_var,
            onvalue=True,
            offvalue=False,
            progress_color="#FF4B72"
        )
        self.ai_scenes_switch.pack(anchor="w", padx=20, pady=(0, 15))

        # TTS Engine Selector
        ctk.CTkLabel(self.sidebar, text="Voiceover TTS Engine:", font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w", padx=20, pady=(5, 2))
        self.tts_engine_var = ctk.StringVar(value="edge-tts")
        self.tts_engine_menu = ctk.CTkOptionMenu(
            self.sidebar,
            values=["edge-tts (100% Free / Neural)", "ElevenLabs (API Key)"],
            command=self._on_tts_engine_changed,
            fg_color="#2A2E39",
            button_color="#3A4050"
        )
        self.tts_engine_menu.pack(fill="x", padx=20, pady=(0, 15))

        # Action Buttons
        btn_font = ctk.CTkFont(size=13, weight="bold")

        self.btn_py_movie = ctk.CTkButton(
            self.sidebar,
            text="🎬 PYTHON MOVIE (100% Free)",
            command=self._start_python_movie_run,
            font=btn_font,
            fg_color="#0072FF",
            hover_color="#0056C7",
            height=38
        )
        self.btn_py_movie.pack(fill="x", padx=20, pady=(0, 8))

        self.btn_full_run = ctk.CTkButton(
            self.sidebar,
            text="⚡ FULL STUDIO + YOUTUBE UPLOAD",
            command=self._start_full_run,
            font=btn_font,
            fg_color="#FF4B72",
            hover_color="#E03A60",
            height=38
        )
        self.btn_full_run.pack(fill="x", padx=20, pady=(0, 10))

        self.btn_scrape = ctk.CTkButton(
            self.sidebar,
            text="1. 🔍 Scrape Latest Video",
            command=self._start_scrape_only,
            font=btn_font,
            fg_color="#2A2E39",
            hover_color="#3A4050"
        )
        self.btn_scrape.pack(fill="x", padx=20, pady=(0, 8))

        self.btn_gen_script = ctk.CTkButton(
            self.sidebar,
            text="2. 📝 Generate Script & Storyboard",
            command=self._start_script_only,
            font=btn_font,
            fg_color="#2A2E39",
            hover_color="#3A4050"
        )
        self.btn_gen_script.pack(fill="x", padx=20, pady=(0, 8))

        self.btn_gen_scenes = ctk.CTkButton(
            self.sidebar,
            text="3. 🎨 Render 6 Scene Artworks",
            command=self._start_scenes_only,
            font=btn_font,
            fg_color="#2A2E39",
            hover_color="#3A4050"
        )
        self.btn_gen_scenes.pack(fill="x", padx=20, pady=(0, 8))

        self.btn_gen_audio = ctk.CTkButton(
            self.sidebar,
            text="4. 🎙️ Synthesize Voiceover (TTS)",
            command=self._start_audio_only,
            font=btn_font,
            fg_color="#2A2E39",
            hover_color="#3A4050"
        )
        self.btn_gen_audio.pack(fill="x", padx=20, pady=(0, 8))

        self.btn_gen_video = ctk.CTkButton(
            self.sidebar,
            text="5. 🎥 Render 1080p MP4 Video",
            command=self._start_video_only,
            font=btn_font,
            fg_color="#2A2E39",
            hover_color="#3A4050"
        )
        self.btn_gen_video.pack(fill="x", padx=20, pady=(0, 8))

        self.btn_upload = ctk.CTkButton(
            self.sidebar,
            text="6. 🚀 Upload Video to YouTube",
            command=self._start_upload_only,
            font=btn_font,
            fg_color="#1E7E34",
            hover_color="#28A745"
        )
        self.btn_upload.pack(fill="x", padx=20, pady=(0, 15))

        # Status Label
        self.status_badge = ctk.CTkLabel(
            self.sidebar,
            text="● Ready",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#28A745"
        )
        self.status_badge.pack(side="bottom", pady=15)

    def _build_main_panel(self):
        self.main_frame = ctk.CTkFrame(self, corner_radius=0, fg_color="#13151B")
        self.main_frame.pack(side="right", fill="both", expand=True)

        # Tabview
        self.tabview = ctk.CTkTabview(self.main_frame, corner_radius=12)
        self.tabview.pack(fill="both", expand=True, padx=15, pady=(15, 10))

        self.tab_scraper = self.tabview.add("🔍 Scraper & Transcripts")
        self.tab_storyboard = self.tabview.add("📝 Storyboard & Script")
        self.tab_gallery = self.tabview.add("🖼️ Scene & Thumbnail Gallery")
        self.tab_settings = self.tabview.add("⚙️ Settings & API Keys")

        self._build_tab_scraper()
        self._build_tab_storyboard()
        self._build_tab_gallery()
        self._build_tab_settings()

        # Bottom Live Terminal Console
        console_frame = ctk.CTkFrame(self.main_frame, height=180, corner_radius=8, fg_color="#0D0E12")
        console_frame.pack(fill="x", padx=15, pady=(0, 15))
        console_frame.pack_propagate(False)

        console_hdr = ctk.CTkLabel(console_frame, text="💻 LIVE EXECUTION CONSOLE", font=ctk.CTkFont(size=11, weight="bold"), text_color="#00D2FF")
        console_hdr.pack(anchor="w", padx=12, pady=(6, 2))

        self.console_text = ctk.CTkTextbox(console_frame, font=ctk.CTkFont(family="Consolas", size=11), fg_color="#07080A", text_color="#E0E0E0")
        self.console_text.pack(fill="both", expand=True, padx=10, pady=(0, 8))

    def _build_tab_scraper(self):
        # Scraper Details
        self.scr_info_frame = ctk.CTkScrollableFrame(self.tab_scraper, corner_radius=8)
        self.scr_info_frame.pack(fill="both", expand=True, padx=10, pady=10)

        self.lbl_scraped_title = ctk.CTkLabel(
            self.scr_info_frame,
            text="No Video Scraped Yet. Click 'Scrape Latest Video' or 'Full Auto Run'.",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color="#FFD700",
            wraplength=850,
            justify="left"
        )
        self.lbl_scraped_title.pack(anchor="w", padx=10, pady=(10, 5))

        self.lbl_scraped_meta = ctk.CTkLabel(
            self.scr_info_frame,
            text="Channel: N/A | Video URL: N/A | Tags: N/A",
            font=ctk.CTkFont(size=12),
            text_color="#9AA0A6",
            wraplength=850,
            justify="left"
        )
        self.lbl_scraped_meta.pack(anchor="w", padx=10, pady=(0, 15))

        # Transcript Scene Chunks Container
        ctk.CTkLabel(
            self.scr_info_frame,
            text="📊 Chronological Transcript Scene Beats Extracted:",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color="#00E5FF"
        ).pack(anchor="w", padx=10, pady=(5, 5))

        self.transcript_box = ctk.CTkTextbox(
            self.scr_info_frame,
            height=260,
            font=ctk.CTkFont(family="Nirmala UI", size=12),
            fg_color="#1E222D"
        )
        self.transcript_box.pack(fill="x", padx=10, pady=(0, 10))

    def _build_tab_storyboard(self):
        # Storyboard & Script Tab
        self.st_split = ctk.CTkFrame(self.tab_storyboard, fg_color="transparent")
        self.st_split.pack(fill="both", expand=True, padx=5, pady=5)

        # Left: Full Script
        left_box = ctk.CTkFrame(self.st_split, corner_radius=8)
        left_box.pack(side="left", fill="both", expand=True, padx=(0, 8), pady=0)

        ctk.CTkLabel(left_box, text="📜 Generated Story Script & Dialogue", font=ctk.CTkFont(size=13, weight="bold"), text_color="#FF80AB").pack(anchor="w", padx=10, pady=8)
        self.script_box = ctk.CTkTextbox(left_box, font=ctk.CTkFont(family="Nirmala UI", size=12), fg_color="#181B24")
        self.script_box.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        # Right: 6 Storyboard Scene Cards
        right_box = ctk.CTkScrollableFrame(self.st_split, width=420, corner_radius=8)
        right_box.pack(side="right", fill="both", expand=False, padx=(0, 0), pady=0)

        ctk.CTkLabel(right_box, text="🎬 6-Scene Storyboard Breakdown", font=ctk.CTkFont(size=13, weight="bold"), text_color="#00E5FF").pack(anchor="w", padx=5, pady=8)
        self.scene_card_container = right_box

    def _build_tab_gallery(self):
        self.gallery_scroll = ctk.CTkScrollableFrame(self.tab_gallery, corner_radius=8)
        self.gallery_scroll.pack(fill="both", expand=True, padx=10, pady=10)

        # Thumbnail Section
        ctk.CTkLabel(self.gallery_scroll, text="🖼️ Generated High-CTR Thumbnail (1280x720):", font=ctk.CTkFont(size=14, weight="bold"), text_color="#FFD700").pack(anchor="w", padx=10, pady=(10, 5))
        self.thumb_preview_lbl = ctk.CTkLabel(self.gallery_scroll, text="No Thumbnail Generated Yet", fg_color="#1A1D26", height=240, corner_radius=8)
        self.thumb_preview_lbl.pack(fill="x", padx=10, pady=(0, 20))

        # 6 Scenes Grid
        ctk.CTkLabel(self.gallery_scroll, text="🎨 6 Storyboard Scene Backgrounds (1080p):", font=ctk.CTkFont(size=14, weight="bold"), text_color="#00E5FF").pack(anchor="w", padx=10, pady=(5, 5))
        self.scenes_grid_frame = ctk.CTkFrame(self.gallery_scroll, fg_color="transparent")
        self.scenes_grid_frame.pack(fill="both", expand=True, padx=10, pady=5)
        self.scene_image_labels = []

    def _build_tab_settings(self):
        scroll_settings = ctk.CTkScrollableFrame(self.tab_settings, corner_radius=8)
        scroll_settings.pack(fill="both", expand=True, padx=10, pady=10)

        ctk.CTkLabel(scroll_settings, text="⚙️ Production & API Configuration", font=ctk.CTkFont(size=16, weight="bold"), text_color="#FF4B72").pack(anchor="w", padx=15, pady=(10, 15))

        # Groq API Key
        ctk.CTkLabel(scroll_settings, text="Groq API Key (Free LPU):", font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w", padx=15, pady=(5, 2))
        self.entry_groq_key = ctk.CTkEntry(scroll_settings, width=500, placeholder_text="gsk_...")
        self.entry_groq_key.insert(0, os.getenv("GROQ_API_KEY") or config.GROQ_API_KEY)
        self.entry_groq_key.pack(anchor="w", padx=15, pady=(0, 12))

        # ElevenLabs API Key
        ctk.CTkLabel(scroll_settings, text="ElevenLabs API Key (TTS):", font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w", padx=15, pady=(5, 2))
        self.entry_el_key = ctk.CTkEntry(scroll_settings, width=500, placeholder_text="sk_...")
        self.entry_el_key.insert(0, os.getenv("ELEVENLABS_API_KEY") or config.ELEVENLABS_API_KEY)
        self.entry_el_key.pack(anchor="w", padx=15, pady=(0, 12))

        # Voice ID
        ctk.CTkLabel(scroll_settings, text="ElevenLabs Voice ID:", font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w", padx=15, pady=(5, 2))
        self.entry_voice_id = ctk.CTkEntry(scroll_settings, width=350)
        self.entry_voice_id.insert(0, config.ELEVENLABS_VOICE_ID)
        self.entry_voice_id.pack(anchor="w", padx=15, pady=(0, 12))

        # YouTube Privacy
        ctk.CTkLabel(scroll_settings, text="YouTube Upload Privacy Status:", font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w", padx=15, pady=(5, 2))
        self.combo_privacy = ctk.CTkComboBox(scroll_settings, values=["private", "unlisted", "public"])
        self.combo_privacy.set(config.DEFAULT_YOUTUBE_PRIVACY)
        self.combo_privacy.pack(anchor="w", padx=15, pady=(0, 20))

        btn_save = ctk.CTkButton(
            scroll_settings,
            text="💾 Save Configuration",
            command=self._save_settings,
            fg_color="#1E7E34",
            hover_color="#28A745",
            width=200
        )
        btn_save.pack(anchor="w", padx=15, pady=(5, 20))

    # -------------------------------------------------------------------------
    # Thread-Safe Pipeline Runners
    # -------------------------------------------------------------------------
    def _run_threaded(self, target_func, name: str):
        if self.is_running:
            self._log_msg(f"⚠️ A production task is already running. Please wait.")
            return
        self.is_running = True
        self.status_badge.configure(text=f"● Running: {name}...", text_color="#FFC107")
        self._toggle_buttons(False)

        def worker():
            try:
                target_func()
            except Exception as e:
                self._log_msg(f"❌ Error during {name}: {e}")
            finally:
                self.is_running = False
                self.after(0, lambda: self.status_badge.configure(text="● Ready", text_color="#28A745"))
                self.after(0, lambda: self._toggle_buttons(True))
                self.after(0, self._load_existing_output_assets)

        threading.Thread(target=worker, daemon=True).name = name
        threading.Thread(target=worker, daemon=True).start()

    def _toggle_buttons(self, state: bool):
        s = "normal" if state else "disabled"
        self.btn_full_run.configure(state=s)
        self.btn_scrape.configure(state=s)
        self.btn_gen_script.configure(state=s)
        self.btn_gen_scenes.configure(state=s)
        self.btn_gen_audio.configure(state=s)
        self.btn_gen_video.configure(state=s)
        self.btn_upload.configure(state=s)

    # -------------------------------------------------------------------------
    # Pipeline Step Implementations
    # -------------------------------------------------------------------------
    def _on_tts_engine_changed(self, choice):
        if "edge-tts" in choice.lower():
            self.tts_engine_var.set("edge-tts")
            self._log_msg("🎙️ TTS Engine set to: Microsoft edge-tts (100% Free / Neural)")
        else:
            self.tts_engine_var.set("elevenlabs")
            self._log_msg("⭐ TTS Engine set to: ElevenLabs (API Key required)")

    def _start_python_movie_run(self):
        """Runs 100% Free Python Movie pipeline: Groq Script -> edge-tts -> MoviePy Export."""
        def task():
            self._log_msg("🎬 Starting PYTHON MOVIE Pipeline (Groq + Free edge-tts + MoviePy)...")
            # 1. Scrape
            trend = self._execute_scrape()
            # 2. Script
            script_text, gen_meta = self._execute_script(trend)
            storyboard = gen_meta.get("storyboard", [])
            # 3. Scenes
            self._execute_scenes(storyboard)
            # 4. Audio (Free edge-tts)
            self._execute_audio(script_text, engine="edge-tts")
            # 5. Thumbnail
            self._execute_thumbnail(trend)
            # 6. Video (MoviePy 1080p Export)
            self._execute_video(script_text, storyboard, trend)
            self._log_msg("🎉 PYTHON MOVIE 1080p Video Generated & Exported Successfully!")
        self._run_threaded(task, "Python Movie")

    def _start_full_run(self):
        def task():
            self._log_msg("=== Starting Full Autonomous Production Run ===")
            # 1. Scrape
            trend = self._execute_scrape()
            if not trend:
                return
            # 2. Script
            script_text, gen_meta = self._execute_script(trend)
            # 3. Scenes
            storyboard = gen_meta.get("storyboard", [])
            self._execute_scenes(storyboard)
            # 4. Audio
            self._execute_audio(script_text)
            # 5. Thumbnail
            self._execute_thumbnail(trend)
            # 6. Video
            self._execute_video(script_text, storyboard, trend)
            self._log_msg("🎉 Full Autonomous Pipeline Completed Successfully!")
        self._run_threaded(task, "Full Pipeline")

    def _start_scrape_only(self):
        def task():
            self._execute_scrape()
        self._run_threaded(task, "Scraping")

    def _start_script_only(self):
        def task():
            if not self.current_trend:
                self._execute_scrape()
            if self.current_trend:
                self._execute_script(self.current_trend)
        self._run_threaded(task, "Script Generation")

    def _start_scenes_only(self):
        def task():
            if not self.current_storyboard:
                if not self.current_trend:
                    self._execute_scrape()
                if self.current_trend:
                    _, meta = self._execute_script(self.current_trend)
                    self.current_storyboard = meta.get("storyboard")
            if self.current_storyboard:
                self._execute_scenes(self.current_storyboard)
        self._run_threaded(task, "Scene Rendering")

    def _start_audio_only(self):
        def task():
            if not self.current_script:
                if config.SCRIPT_OUTPUT_FILE.exists():
                    with open(config.SCRIPT_OUTPUT_FILE, "r", encoding="utf-8") as f:
                        self.current_script = f.read()
                else:
                    if not self.current_trend:
                        self._execute_scrape()
                    if self.current_trend:
                        self.current_script, _ = self._execute_script(self.current_trend)
            if self.current_script:
                self._execute_audio(self.current_script)
        self._run_threaded(task, "Audio Synthesis")

    def _start_video_only(self):
        def task():
            if not self.current_script and config.SCRIPT_OUTPUT_FILE.exists():
                with open(config.SCRIPT_OUTPUT_FILE, "r", encoding="utf-8") as f:
                    self.current_script = f.read()
            if not self.current_trend:
                self._execute_scrape()
            if self.current_trend and self.current_script:
                self._execute_video(self.current_script, self.current_storyboard, self.current_trend)
        self._run_threaded(task, "Video Rendering")

    def _start_upload_only(self):
        def task():
            if not config.VIDEO_OUTPUT_FILE.exists():
                self._log_msg("❌ No video.mp4 found in output folder to upload!")
                return
            title = self.current_trend["title"] if self.current_trend else "Animated Video"
            privacy = self.combo_privacy.get()
            self._log_msg(f"Uploading to YouTube: '{title}' ({privacy})...")
            ok, res = upload_video_to_youtube(
                video_path=config.VIDEO_OUTPUT_FILE,
                thumbnail_path=config.THUMBNAIL_OUTPUT_FILE if config.THUMBNAIL_OUTPUT_FILE.exists() else None,
                title=f"NOT YOUR TYPE - {title[:70]}",
                privacy_status=privacy
            )
            if ok:
                self._log_msg(f"🚀 Uploaded successfully! Link: {res.get('video_url')}")
            else:
                self._log_msg(f"❌ Upload status: {res.get('error') or res.get('status')}")
        self._run_threaded(task, "YouTube Upload")

    # -------------------------------------------------------------------------
    # Core Step Logic
    # -------------------------------------------------------------------------
    def _execute_scrape(self) -> Optional[Dict[str, Any]]:
        custom_topic = self.topic_entry.get().strip()
        channel_handle = self.channel_entry.get().strip() or "@NOTYOURTYPE"
        config.TARGET_CHANNEL_HANDLE = channel_handle

        if custom_topic:
            self._log_msg(f"Using manual topic override: '{custom_topic}'")
            trend = {
                "status": "custom_override",
                "title": custom_topic,
                "theme": f"Animated comedy storytelling inspired by '{custom_topic}'",
                "video_url": "N/A (Custom Override)",
                "channel_title": config.TARGET_CHANNEL_NAME,
                "raw_summary": custom_topic
            }
        else:
            self._log_msg(f"Scraping latest video releases from {channel_handle}...")
            trend = get_latest_channel_trend()

        self.current_trend = trend
        self.after(0, lambda: self._update_scraper_ui(trend))
        return trend

    def _execute_script(self, trend: dict) -> Tuple[str, dict]:
        self._log_msg(f"Generating dynamic script & 6-scene storyboard for: '{trend['title']}'...")
        script_text, gen_meta = generate_animated_video_script(
            title=trend["title"],
            theme=trend["theme"],
            raw_summary=trend.get("raw_summary", ""),
            custom_keywords=trend.get("keywords", None),
            narrative_context=trend.get("narrative_context", None)
        )
        self.current_script = script_text
        self.current_storyboard = gen_meta.get("storyboard", [])

        # Save script file
        config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        with open(config.SCRIPT_OUTPUT_FILE, "w", encoding="utf-8") as f:
            f.write(script_text)

        self.after(0, lambda: self._update_storyboard_ui(script_text, self.current_storyboard))
        self._log_msg(f"✅ Generated {len(self.current_storyboard)} storyboard scenes successfully.")
        return script_text, gen_meta

    def _execute_scenes(self, storyboard: list):
        use_ai = self.ai_scenes_var.get()
        self._log_msg(f"Rendering 6 scene artworks (Pollinations AI: {use_ai})...")
        paths = generate_scene_artworks(storyboard, use_ai=use_ai)
        self._log_msg(f"✅ Cached {len(paths)} scene backgrounds to: {config.OUTPUT_DIR / 'scenes'}")
        self.after(0, self._load_existing_output_assets)

    def _execute_audio(self, script_text: str, engine: str = None):
        tts_eng = engine or self.tts_engine_var.get()
        self._log_msg(f"Synthesizing voiceover audio track via {tts_eng}...")
        voice_id = self.entry_voice_id.get().strip() or config.ELEVENLABS_VOICE_ID
        key = self.entry_el_key.get().strip() or None
        ok, meta = generate_voiceover_audio(
            script_text=script_text,
            output_path=config.AUDIO_OUTPUT_FILE,
            voice_id=voice_id,
            api_key=key,
            engine=tts_eng
        )
        if ok:
            self._log_msg(f"✅ Audio generated successfully ({meta.get('engine', 'TTS')} - {meta.get('file_size_kb', 0)} KB)")
        else:
            self._log_msg(f"⚠️ Audio generation notice: {meta.get('status')} {meta.get('error', '')}")

    def _execute_thumbnail(self, trend: dict):
        use_ai = self.ai_scenes_var.get()
        self._log_msg(f"Creating YouTube thumbnail (AI: {use_ai})...")
        create_thumbnail(
            title=trend["title"],
            theme=trend.get("theme", ""),
            keywords=trend.get("keywords", None),
            output_path=config.THUMBNAIL_OUTPUT_FILE,
            use_ai=use_ai
        )
        self.after(0, self._load_existing_output_assets)

    def _execute_video(self, script_text: str, storyboard: list, trend: dict):
        use_ai = self.ai_scenes_var.get()
        self._log_msg(f"Rendering 1080p animated MP4 video (AI: {use_ai})...")
        create_video_animation(
            script_text=script_text,
            storyboard=storyboard,
            audio_path=config.AUDIO_OUTPUT_FILE,
            output_video_path=config.VIDEO_OUTPUT_FILE,
            title=trend.get("title", "Video Story"),
            theme=trend.get("theme", "Animation"),
            use_ai_scenes=use_ai
        )
        self.after(0, self._load_existing_output_assets)

    # -------------------------------------------------------------------------
    # UI Updaters
    # -------------------------------------------------------------------------
    def _update_scraper_ui(self, trend: dict):
        self.lbl_scraped_title.configure(text=f"📌 {trend.get('title')}")
        tags_str = ", ".join(trend.get("tags", [])) if trend.get("tags") else "N/A"
        self.lbl_scraped_meta.configure(text=f"Channel: {trend.get('channel_title')} | URL: {trend.get('video_url')}\nTags: {tags_str}")

        ctx = trend.get("narrative_context", {})
        chunks = ctx.get("scene_chunks", [])
        if chunks:
            lines = [f"Beat {c['beat_index']} ({c['time_window']}):\n{c['dialogue_snippet']}\n" for c in chunks]
            self.transcript_box.delete("1.0", "end")
            self.transcript_box.insert("1.0", "\n".join(lines))
        else:
            self.transcript_box.delete("1.0", "end")
            self.transcript_box.insert("1.0", trend.get("raw_summary", "No transcript available."))

    def _update_storyboard_ui(self, script_text: str, storyboard: list):
        self.script_box.delete("1.0", "end")
        self.script_box.insert("1.0", script_text)

        # Clear existing cards
        for widget in self.scene_card_container.winfo_children():
            if widget != self.scene_card_container.winfo_children()[0]: # keep header
                widget.destroy()

        if storyboard:
            for idx, scene in enumerate(storyboard):
                card = ctk.CTkFrame(self.scene_card_container, corner_radius=6, fg_color="#181B24")
                card.pack(fill="x", padx=4, pady=4)

                sec = scene.get("section", f"SCENE_{idx+1}")
                name = scene.get("scene_name", f"Beat {idx+1}")
                prompt = scene.get("visual_prompt", "")
                sfx = scene.get("sfx", "")
                anim = scene.get("animation_pattern", "")

                hdr = ctk.CTkLabel(card, text=f"[{sec}] {name} ({anim})", font=ctk.CTkFont(size=11, weight="bold"), text_color="#FFD700")
                hdr.pack(anchor="w", padx=8, pady=(6, 2))

                p_lbl = ctk.CTkLabel(card, text=prompt, font=ctk.CTkFont(size=10), text_color="#C0C0C0", wraplength=380, justify="left")
                p_lbl.pack(anchor="w", padx=8, pady=(0, 6))

    def _load_existing_output_assets(self):
        """Loads and updates image previews for thumbnail and scenes in the Gallery tab."""
        # 1. Thumbnail Preview
        if config.THUMBNAIL_OUTPUT_FILE.exists():
            try:
                img = Image.open(config.THUMBNAIL_OUTPUT_FILE)
                # Resize for preview aspect ratio (480x270)
                img_preview = img.resize((480, 270), Image.Resampling.LANCZOS)
                ctk_img = ctk.CTkImage(light_image=img_preview, dark_image=img_preview, size=(480, 270))
                self.thumb_preview_lbl.configure(image=ctk_img, text="")
            except Exception as e:
                self.thumb_preview_lbl.configure(text=f"Thumbnail found ({config.THUMBNAIL_OUTPUT_FILE.name})")

        # 2. Scene Previews Grid
        scenes_dir = config.OUTPUT_DIR / "scenes"
        if scenes_dir.exists():
            scene_files = sorted(list(scenes_dir.glob("scene_*.png")))
            if scene_files:
                for w in self.scenes_grid_frame.winfo_children():
                    w.destroy()

                for idx, sf in enumerate(scene_files[:6]):
                    row = idx // 3
                    col = idx % 3
                    card = ctk.CTkFrame(self.scenes_grid_frame, corner_radius=6, fg_color="#181B24")
                    card.grid(row=row, column=col, padx=6, pady=6, sticky="nsew")

                    try:
                        sc_img = Image.open(sf).resize((260, 146), Image.Resampling.LANCZOS)
                        ctk_sc = ctk.CTkImage(light_image=sc_img, dark_image=sc_img, size=(260, 146))
                        lbl_img = ctk.CTkLabel(card, image=ctk_sc, text="")
                        lbl_img.pack(padx=4, pady=4)
                    except Exception:
                        ctk.CTkLabel(card, text=sf.name).pack(padx=4, pady=4)

                    ctk.CTkLabel(card, text=sf.name, font=ctk.CTkFont(size=9, weight="bold"), text_color="#9AA0A6").pack(pady=(0, 4))

    def _save_settings(self):
        groq_k = self.entry_groq_key.get().strip()
        el_k = self.entry_el_key.get().strip()
        v_id = self.entry_voice_id.get().strip()
        priv = self.combo_privacy.get().strip()

        os.environ["GROQ_API_KEY"] = groq_k
        os.environ["ELEVENLABS_API_KEY"] = el_k
        config.GROQ_API_KEY = groq_k
        config.ELEVENLABS_API_KEY = el_k
        config.ELEVENLABS_VOICE_ID = v_id
        config.DEFAULT_YOUTUBE_PRIVACY = priv

        self._log_msg("💾 Production settings and API keys updated successfully!")

    def _log_msg(self, msg: str):
        timestamp = time.strftime("%H:%M:%S")
        self.log_queue.put(f"[{timestamp}] {msg}")

    def _poll_log_queue(self):
        while not self.log_queue.empty():
            try:
                msg = self.log_queue.get_nowait()
                self.console_text.insert("end", msg + "\n")
                self.console_text.see("end")
            except queue.Empty:
                break
        self.after(100, self._poll_log_queue)

def main():
    app = AutonomousStudioApp()
    app.mainloop()

if __name__ == "__main__":
    main()
